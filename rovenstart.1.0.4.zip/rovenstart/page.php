<?php
/**
 * The template for displaying all pages by default
 *
 * @package Rovenstart
 */

get_header();

if ( have_posts() ) {
	// There is content, start the Loop.
	while ( have_posts() ) {
		the_post();

		if ( class_exists( 'WooCommerce' ) ) {
			if ( is_cart() || is_checkout() || is_account_page() ) {
				// Disable header and sidebar on cart, checkout and account pages.
				$header  = false;
				$sidebar = false;
			} else {
				$header = get_theme_mod( 'rovenstart_show_page_header', true );
			}
		} else {
			$header = get_theme_mod( 'rovenstart_show_page_header', true );
		}

		if ( true === $header ) {
			// Page specific header template.
			get_template_part( 'template-parts/headers/header', 'page' );
		}
		?>
		<div id="rs-content" class="rs-section">

			<div class="rs-section-content">

				<div id="rs-main-content">
					<?php
					the_content();

					// Page content pagination arguments.
					$args = array(
						'before'         => '<div class="page-links">' . esc_html__( 'Pages:', 'rovenstart' ),
						'after'          => '</div>',
						'link_before'    => '<span class="page-number">',
						'link_after'     => '</span>',
						'next_or_number' => 'number',
						'separator'      => '',
					);

					wp_link_pages( $args );
					?>
				</div><!-- end #rs-main-content -->

			</div><!-- end .rs-section-content -->

		</div><!-- end #rs-content -->
		<?php
		if ( comments_open() || get_comments_number() ) {
			comments_template( '', true );
		}
	}
} else {
	// There is no content, use content-none template.
	get_template_part( 'template-parts/content', 'none' );
}

get_footer();
