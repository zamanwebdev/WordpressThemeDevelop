<?php
/**
 * Template part for displaying the single post author info section
 *
 * @package rovenstart
 */

?>
<div id="rs-author-info" class="rs-section">

	<div class="rs-section-content">

		<?php
		$authors[] = get_the_author_meta( 'ID' );
		foreach ( $authors as $author_id ) {
			?>
			<div class="rs-author-box">

				<?php if ( true === get_theme_mod( 'rovenstart_post_show_avatar', true ) ) { ?>
					<div class="rs-author-avatar">
						<?php echo get_avatar( $author_id, 90 ); ?>
					</div><!-- end .rs-author-avatar -->
				<?php } ?>

				<div class="rs-author-details">
					<?php
					// Post author name and link.
					if ( true === get_theme_mod( 'rovenstart_post_show_author_name', true ) ) {
						$author_name = get_the_author_meta( 'display_name', $author_id );
						?>
						<h4>
							<a href="<?php echo esc_url( get_author_posts_url( $author_id ) ); ?>" title="<?php echo esc_attr( $author_name ); ?>"><?php echo esc_html( $author_name ); ?></a>
						</h4>
						<?php
					}

					if ( true === get_theme_mod( 'rovenstart_post_show_author_info', true ) ) {
						// Post author info.
						?>
						<p><?php the_author_meta( 'description', $author_id ); ?></p>
					<?php } ?>

				</div><!-- end .rs-author-details -->

			</div><!-- end .rs-author-box -->
		<?php } ?>

	</div><!-- end .rs-section-content -->	

</div><!-- end #rs-author-info -->
