<?php
/**
 * Template part for displaying single post contents
 *
 * @package rovenstart
 */

?>
<div id="rs-content" class="rs-section">

	<div class="rs-section-content">

		<div id="rs-main-content">

			<div id="post-<?php the_ID(); ?>" <?php post_class( 'single-post' ); ?>>
				<?php
				the_content();

				// Post content pagination arguments.
				$args = array(
					'before'         => '<div class="page-links">' . esc_html__( 'Pages:', 'rovenstart' ),
					'after'          => '</div>',
					'link_before'    => '<span class="page-number">',
					'link_after'     => '</span>',
					'next_or_number' => 'number',
					'separator'      => '',
				);

				wp_link_pages( $args );

				if ( has_tag() ) {
					// Post Tags list.
					?>
					<div class="tags-links">
						<?php the_tags( '', '' ); ?>
					</div>
				<?php } ?>

			</div><!-- end .single-post -->

		</div><!-- end #rs-main-content -->

	</div><!-- end .rs-section-content -->

</div><!-- end #rs-content -->

<?php
if ( true === get_theme_mod( 'rovenstart_post_show_author_bio', true ) ) {
	// Template for post author info section.
	get_template_part( 'template-parts/post', 'author' );
}
