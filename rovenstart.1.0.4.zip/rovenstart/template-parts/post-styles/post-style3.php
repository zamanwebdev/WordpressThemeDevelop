<?php
/**
 * Template for non-single posts - Style 3
 *
 * @package rovenstart
 */

$postid     = get_the_ID();
$thumbnail  = has_post_thumbnail();
$card_class = $args['thumbnail_type'];

if ( $thumbnail ) {
	$card_class .= ' rs-card-has-thumbnail';
} else {
	$card_class .= ' rs-card-no-thumbnail';
}

if ( has_post_format( 'audio' ) ) {
	$p_format = 'audio';
} elseif ( has_post_format( 'video' ) ) {
	$p_format = 'video';
} elseif ( has_post_format( 'gallery' ) ) {
	$p_format = 'gallery';
} else {
	$p_format = 'standard';
}
?>
<div class="rs-card-3<?php echo esc_attr( $card_class ); ?>">

	<?php
	if ( $thumbnail ) {
		// Get post thumbnail class, srcset and sizes arguments.
		$thumb_data = rovenstart_thumb_size_args( $args['thumbnail_size'], 1, $args['thumbnail_limit'] );
		?>
		<div class="rs-card-background">

			<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail( $thumb_data['size'], $thumb_data['args'] ); ?></a>

		</div>
	<?php } ?>

	<div class="rs-card-content">

		<?php
		if ( true === $args['category_enable'] ) {
			if ( has_category() ) {
				// Begin fetching categories and listing them.

				$post_categories = get_the_terms( $postid, 'category' );
				?>
				<div class="rs-card-meta">

					<span class="rs-card-categories">
						<?php
						$sep_categ   = 0;
						$categ_count = 0;
						foreach ( $post_categories as $category ) {
							if ( 0 !== $sep_categ ) {
								echo ' ';
							} else {
								$sep_categ = 1;
							}
							?>
							<a href="<?php echo esc_url( get_term_link( $category->term_id, 'category' ) ); ?>"><?php echo esc_html( $category->name ); ?></a>
							<?php
							$categ_count ++;
							if ( $categ_count >= 2 ) {
								break;
							}
						}
						?>
					</span>

				</div><!-- end .rs-card-meta -->
				<?php
			}
		}
		?>

		<?php if ( ! empty( trim( get_the_title() ) ) ) { ?>
			<h3 class="rs-card-title">
				<a class="rs-text-animation-2" href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			</h3>
		<?php } ?>

		<?php if ( true === $args['author_enable'] || true === $args['date_enable'] || true === $args['comments_enable'] ) { ?>
			<div class="rs-card-meta">
				<?php
				if ( true === $args['author_enable'] ) {
					// Post author.
					?>
					<span class="rs-card-author">
						<?php
						$coauthors = false;
						if ( $coauthors ) {
							// Mutiple post authors based on Co-authors plus plugin.
							$co_authors = get_coauthors();
							if ( 1 < count( $co_authors ) ) {
								echo '<i class="rovenstart-icon-users"></i> ';
							} else {
								echo '<i class="rovenstart-icon-user"></i> ';
							}
							coauthors_posts_links();
						} else {
							// Regular single post author.
							echo '<i class="rovenstart-icon-user"></i> ';
							the_author_posts_link();
						}
						?>
					</span>
					<?php
				}

				if ( true === $args['date_enable'] ) {
					// Post date.
					?>
					<span class="rs-card-date"><i class="rovenstart-icon-calendar"></i> <?php echo get_the_date(); ?></span>
					<?php
				}

				if ( true === $args['comments_enable'] ) {
					// Post comments count.
					?>
					<span class="rs-card-comments"><i class="rovenstart-icon-message-square"></i> <?php comments_number( esc_html__( '0', 'rovenstart' ), esc_html__( '1', 'rovenstart' ), '%' ); ?></span>
				<?php } ?>
			</div><!-- end .rs-card-meta -->
		<?php } ?>

	</div><!-- end .rs-card-content -->

</div><!-- end .rs-card-3 -->

<?php
if ( true === $args['excerpt_enable'] ) {
	// Post excerpt.
	?>
	<div class="rs-card-excerpt"><?php the_excerpt(); ?></div>
	<?php
}
