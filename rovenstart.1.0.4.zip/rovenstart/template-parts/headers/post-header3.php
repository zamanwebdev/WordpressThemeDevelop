<?php
/**
 * Template for Post Header Style 3
 *
 * @package rovenstart
 */

$postid          = get_the_ID();
$thumbnail       = has_post_thumbnail();
$category_enable = false;
$author_enable   = false;
$date_enable     = false;
$comments_enable = false;
$thumbnail_type  = get_theme_mod( 'rovenstart_post_settings_aspect', 'hero' );
$card_class      = '';
$thumbnail_size  = '';

if ( $thumbnail ) {
	$card_class = ' rs-card-has-thumbnail';
} else {
	$card_class = ' rs-card-no-thumbnail';
}

// Prepare the post thumbnail class and ratio variables.
if ( 'landscape' === $thumbnail_type ) {
	$card_class    .= ' rs-card-aspect-ratio-landscape';
	$thumbnail_size = 'rovenstart-landscape-max';
} elseif ( 'portrait' === $thumbnail_type ) {
	$card_class    .= ' rs-card-aspect-ratio-portrait';
	$thumbnail_size = 'rovenstart-portrait-max';
} elseif ( 'square' === $thumbnail_type ) {
	$card_class    .= ' rs-card-aspect-ratio-square';
	$thumbnail_size = 'rovenstart-square-max';
} else {
	$card_class    .= ' rs-card-aspect-ratio-hero';
	$thumbnail_size = 'rovenstart-hero-max';
}
?>
<div id="rs-post-header" class="rs-section">

	<div class="rs-section-content">

		<div class="rs-card-3<?php echo esc_attr( $card_class ); ?>">

			<?php
			if ( $thumbnail ) {
				// Get post thumbnail class, srcset and sizes arguments.
				$thumb_data = rovenstart_thumb_size_args( $thumbnail_type );
				?>
				<div class="rs-card-background">

					<span><?php the_post_thumbnail( $thumb_data['size'], $thumb_data['args'] ); ?></span>

				</div>
			<?php } ?>

			<div class="rs-card-content">

				<?php
				if ( true === $category_enable ) {
					if ( has_category() ) {
						// Begin fetching categories and listing them.

						$post_categories = get_the_terms( $postid, 'category' );
						?>
						<div class="rs-card-meta">

							<span class="rs-card-categories">
								<?php
								$sep_categ   = 0;
								$categ_count = 0;
								foreach ( $post_categories as $category ) {
									if ( 0 !== $sep_categ ) {
										echo ' ';
									} else {
										$sep_categ = 1;
									}
									?>
									<a href="<?php echo esc_url( get_term_link( $category->term_id, 'category' ) ); ?>"><?php echo esc_html( $category->name ); ?></a>
									<?php
									$categ_count ++;
									if ( $categ_count >= 2 ) {
										break;
									}
								}
								?>
							</span>

						</div><!-- end .rs-card-meta -->
						<?php
					}
				}
				?>

				<?php if ( ! empty( trim( get_the_title() ) ) ) { ?>
					<h3 class="rs-card-title">
						<?php the_title(); ?>
					</h3>
				<?php } ?>

				<?php if ( true === $author_enable || true === $date_enable || true === $comments_enable ) { ?>
					<div class="rs-card-meta">
						<?php
						if ( true === $author_enable ) {
							// Post author.
							?>
							<span class="rs-card-author">
								<?php
								$coauthors = false;
								if ( $coauthors ) {
									// Mutiple post authors based on Co-authors plus plugin.
									$co_authors = get_coauthors();
									if ( 1 < count( $co_authors ) ) {
										echo '<i class="rovenstart-icon-users"></i> ';
									} else {
										echo '<i class="rovenstart-icon-user"></i> ';
									}
									coauthors_posts_links();
								} else {
									// Regular single post author.
									echo '<i class="rovenstart-icon-user"></i> ';
									the_author_posts_link();
								}
								?>
							</span>
							<?php
						}

						if ( true === $date_enable ) {
							// Post date.
							?>
							<span class="rs-card-date"><i class="rovenstart-icon-calendar"></i> <?php echo get_the_date(); ?></span>
							<?php
						}

						if ( true === $comments_enable ) {
							// Post comments count.
							?>
							<span class="rs-card-comments"><i class="rovenstart-icon-message-square"></i> <?php comments_number( esc_html__( '0', 'rovenstart' ), esc_html__( '1', 'rovenstart' ), '%' ); ?></span>
						<?php } ?>
					</div><!-- end .rs-card-meta -->
				<?php } ?>

			</div><!-- end .rs-card-content -->

		</div><!-- end .rs-card-3 -->

	</div><!-- end .rs-section-content -->

</div><!-- end #rs-post-header -->
