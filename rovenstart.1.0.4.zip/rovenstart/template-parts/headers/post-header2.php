<?php
/**
 * Template for Post Header Style 2
 *
 * @package rovenstart
 */

$postid          = get_the_ID();
$thumbnail       = has_post_thumbnail();
$category_enable = get_theme_mod( 'rovenstart_post_category', true );
$thumbnail_type  = get_theme_mod( 'rovenstart_post_settings_aspect', 'hero' );
$card_class      = '';
$thumbnail_size  = '';

if ( $thumbnail ) {
	$card_class = ' rs-card-has-thumbnail';
} else {
	$card_class = ' rs-card-no-thumbnail';
}

// Prepare the post thumbnail class and ratio variables.
if ( 'landscape' === $thumbnail_type ) {
	$card_class .= ' rs-card-aspect-ratio-landscape';
} elseif ( 'portrait' === $thumbnail_type ) {
	$card_class .= ' rs-card-aspect-ratio-portrait';
} elseif ( 'square' === $thumbnail_type ) {
	$card_class .= ' rs-card-aspect-ratio-square';
} else {
	$card_class .= ' rs-card-aspect-ratio-hero';
}
?>
<div id="rs-post-header" class="rs-section">

	<div class="rs-section-content">

		<div class="rs-card-2<?php echo esc_attr( $card_class ); ?>">

			<?php
			if ( $thumbnail ) {
				// Get post thumbnail class, srcset and sizes arguments.
				$thumb_data = rovenstart_thumb_size_args( $thumbnail_type );
				?>
				<div class="rs-card-background">

					<span><?php the_post_thumbnail( $thumb_data['size'], $thumb_data['args'] ); ?></span>

				</div>
			<?php } ?>

			<div class="rs-card-content">

				<?php
				if ( true === $category_enable ) {
					if ( has_category() ) {
						// Begin fetching categories and listing them.

						$post_categories = get_the_terms( $postid, 'category' );
						?>
						<div class="rs-card-meta">

							<span class="rs-card-categories">
								<?php
								$sep_categ   = 0;
								$categ_count = 0;
								foreach ( $post_categories as $category ) {
									if ( 0 !== $sep_categ ) {
										echo ' ';
									} else {
										$sep_categ = 1;
									}
									?>
									<a href="<?php echo esc_url( get_term_link( $category->term_id, 'category' ) ); ?>"><?php echo esc_html( $category->name ); ?></a>
									<?php
									$categ_count ++;
									if ( $categ_count >= 2 ) {
										break;
									}
								}
								?>
							</span>

						</div><!-- end .rs-card-meta -->
						<?php
					}
				}
				?>

				<?php if ( ! empty( trim( get_the_title() ) ) ) { ?>
					<h3 class="rs-card-title">
						<?php the_title(); ?>
					</h3>
				<?php } ?>

			</div><!-- end .rs-card-content -->

		</div><!-- end .rs-card-2 -->

	</div><!-- end .rs-section-content -->

</div><!-- end #rs-post-header -->
