<?php
/**
 * Template for page header styles
 *
 * @package rovenstart
 */

$thumb_type = get_theme_mod( 'rovenstart_page_featured_aspect', 'hero' );
$thumbnail  = has_post_thumbnail();
$card_style = get_theme_mod( 'rovenstart_page_header_style', 'style1' );
$pageheader = '';

// Page Header card style.
if ( 'style2' === $card_style ) {
	$pageheader = 'rs-card-2';
} else {
	$pageheader = 'rs-card-1';
}

if ( $thumbnail ) {
	$pageheader .= ' rs-card-has-thumbnail rs-card-aspect-ratio-' . $thumb_type;
} else {
	$pageheader .= ' rs-card-no-thumbnail rs-card-aspect-ratio-' . $thumb_type;
}
?>
<div id="rs-page-header" class="rs-section">

	<div class="rs-section-content">

		<div class="<?php echo esc_attr( $pageheader ); ?>">

			<?php
			if ( $thumbnail ) {
				// Get post thumbnail class, srcset and sizes arguments.
				$thumb_data = rovenstart_thumb_size_args( $card_style );
				?>
				<div class="rs-card-background">

					<span><?php the_post_thumbnail( $thumb_data['size'], $thumb_data['args'] ); ?></span>

				</div>
			<?php } ?>

			<?php if ( ! empty( trim( get_the_title() ) ) ) { ?>
				<div class="rs-card-content">

					<h3 class="rs-card-title">
						<?php
						if ( 'style1' === $card_style ) {
							echo '<span>';
						}
						the_title();
						if ( 'style1' === $card_style ) {
							echo '</span>';
						}
						?>
					</h3><!-- end .rs-card-title -->

				</div><!-- end .rs-card-content -->
			<?php } ?>

		</div><!-- end .rs-card-2 -->

	</div><!-- end .rs-section-content -->

</div><!-- end #rs-page-header -->
