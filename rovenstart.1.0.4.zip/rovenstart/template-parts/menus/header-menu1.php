<?php
/**
 * Template part for displaying header with logo on top and menu below
 *
 * @package rovenstart
 */

// Header Menu Customizer arguments.
$show_search      = get_theme_mod( 'rovenstart_show_search_box', true );
$darkmode_toggler = get_theme_mod( 'rovenstart_show_darkmode_toggler', true );
$logo_source      = get_theme_mod( 'rovenstart_logo_source', 'text-logo' );

if ( 'image-logo' === $logo_source ) {
	$logo_id         = get_theme_mod( 'rovenstart_logo_id', false );
	$logo_dark_id    = get_theme_mod( 'rovenstart_darkmode_logo_id', false );
	$logo2_id        = get_theme_mod( 'rovenstart_logo_retina_id', false );
	$logo2_dark_id   = get_theme_mod( 'rovenstart_darkmode_logo_retina_id', false );
	$logo_default    = false;
	$logo_dark       = false;
	$logo_default_2x = false;
	$logo_dark_2x    = false;

	// Check if an image for logo was provided and save the src of that image.
	if ( false !== $logo2_id ) {
		$logo_data2 = wp_get_attachment_image_src( $logo2_id, 'full' );

		if ( false !== $logo_data2 ) {
			$logo_default_2x = $logo_data2[0];
			$logo_dark_2x    = $logo_data2[0];
			$logo_default    = $logo_data2[0];
			$logo_dark       = $logo_data2[0];
		}
	}

	if ( false !== $logo_id ) {
		$logo_data = wp_get_attachment_image_src( $logo_id, 'full' );

		if ( false !== $logo_data ) {
			$logo_default = $logo_data[0];
			$logo_dark    = $logo_data[0];
		}
	}

	if ( false !== $logo2_dark_id ) {
		$logo_dark_data2 = wp_get_attachment_image_src( $logo2_dark_id, 'full' );

		if ( false !== $logo_dark_data2 ) {
			$logo_dark_2x = $logo_dark_data2[0];
			$logo_dark    = $logo_dark_data2[0];
		}
	}

	if ( false !== $logo_dark_id ) {
		$logo_dark_data = wp_get_attachment_image_src( $logo_dark_id, 'full' );

		if ( false !== $logo_dark_data ) {
			$logo_dark = $logo_dark_data[0];
		}
	}
} else {
	$text_logo = get_theme_mod( 'rovenstart_text_logo', 'rovenstart' );
}
?>
<div id="rs-header" class="rs-section rs-logo-top">

	<div class="rs-section-content">

		<div class="rs-header-navbar rs-hide-on-desktop">

			<div class="rs-header-navbar-col">

				<a class="rs-mobile-menu-trigger" href="#">
					<i class="rovenstart-icon-menu"></i>
				</a>

			</div><!-- end .rs-header-navbar-col -->

			<div class="rs-header-navbar-col">

				<a class="rs-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<?php
					if ( 'image-logo' === $logo_source ) {
						// Dark mode Logo image.
						if ( false !== $logo_dark && false !== $logo_dark_2x ) {
							?>
							<img loading="lazy" class="rs-logo-image-dark-mode lozad" src="<?php echo esc_url( $logo_dark ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" srcset="<?php echo esc_url( $logo_dark ); ?> 1x, <?php echo esc_url( $logo_dark_2x ); ?> 2x">
							<?php
						} elseif ( false !== $logo_dark ) {
							?>
							<img loading="lazy" class="rs-logo-image-dark-mode lozad" src="<?php echo esc_url( $logo_dark ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
							<?php
						}

						// Standard Logo image.
						if ( false !== $logo_default && false !== $logo_default_2x ) {
							?>
							<img loading="lazy" class="rs-logo-image-light-mode lozad" src="<?php echo esc_url( $logo_default ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>" srcset="<?php echo esc_url( $logo_default ); ?> 1x, <?php echo esc_url( $logo_default_2x ); ?> 2x">
							<?php
						} elseif ( false !== $logo_default ) {
							?>
							<img loading="lazy" class="rs-logo-image-light-mode lozad" src="<?php echo esc_url( $logo_default ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
							<?php
						}
					} else {
						// Text Logo.
						echo esc_html( $text_logo );
					}
					?>
				</a>

			</div><!-- end .rs-header-navbar-col -->

			<div class="rs-header-navbar-col">

				<?php
				if ( true === $darkmode_toggler ) {
					// Darkmode toggle icon.
					?>
					<a class="rs-color-scheme-toggler" href="#">
						<i class="rovenstart-icon-moon"></i>
					</a>
					<?php
				}

				if ( true === $show_search ) {
					// Search icon.
					?>
					<a class="rs-search-toggler" href="#">
						<i class="rovenstart-icon-search"></i>
					</a>
				<?php } ?>

			</div><!-- end .rs-header-navbar-col -->

		</div><!-- end .rs-header-navbar -->

		<?php if ( 'image-logo' === $logo_source || '' !== $text_logo ) { ?>
			<div class="rs-header-navbar rs-hide-on-mobile rs-hide-on-tablet rs-hide-on-sticky">

				<div class="rs-header-navbar-col"></div>

				<div class="rs-header-navbar-col">

					<a class="rs-logo" href="<?php echo esc_url( home_url( '/' ) ); ?>">
						<?php
						if ( 'image-logo' === $logo_source ) {
							// Dark mode Logo image.
							if ( false !== $logo_dark ) {
								?>
								<img loading="lazy" class="rs-logo-image-dark-mode lozad" src="<?php echo esc_url( $logo_dark ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
								<?php
							}
							// Standard Logo image.
							if ( false !== $logo_default ) {
								?>
								<img loading="lazy" class="rs-logo-image-light-mode lozad" src="<?php echo esc_url( $logo_default ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
								<?php
							}
						} else {
							// Text Logo.
							echo esc_html( $text_logo );
						}
						?>
					</a>

				</div><!-- end .rs-header-navbar-col -->

				<div class="rs-header-navbar-col"></div>

			</div><!-- end .rs-header-navbar -->
		<?php } ?>

		<div class="rs-header-navbar rs-hide-on-mobile rs-hide-on-tablet">

			<div class="rs-header-navbar-col">

				<a class="rs-logo rs-display-on-sticky" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<?php
					if ( 'image-logo' === $logo_source ) {
						// Dark mode Logo image.
						if ( false !== $logo_dark ) {
							?>
							<img loading="lazy" class="rs-logo-image-dark-mode lozad" src="<?php echo esc_url( $logo_dark ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
							<?php
						}
						// Standard Logo image.
						if ( false !== $logo_default ) {
							?>
							<img loading="lazy" class="rs-logo-image-light-mode lozad" src="<?php echo esc_url( $logo_default ); ?>" alt="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
							<?php
						}
					} else {
						// Text Logo.
						echo esc_html( $text_logo );
					}
					?>
				</a>

				<?php
				if ( true === $darkmode_toggler ) {
					// Darkmode toggle icon.
					?>
					<a class="rs-color-scheme-toggler rs-hide-on-sticky" href="#">
						<i class="rovenstart-icon-moon"></i>
					</a>
				<?php } ?>

			</div><!-- end .rs-header-navbar-col -->

			<div class="rs-header-navbar-col">

				<div id="primary-menu" class="menu">
					<?php
					// Theme Main navigation menu.
					if ( has_nav_menu( 'rovenstart-nav-menu1' ) ) {
						wp_nav_menu(
							array(
								'theme_location' => 'rovenstart-nav-menu1',
								'menu_id'        => 'rovenstart-menu1',
								'container'      => false,
							)
						);
					} elseif ( current_user_can( 'edit_theme_options' ) ) {
						// No menu was assigned, notify via message only the users who can assign nav menus.
						?>
						<div class="rs-navmenu-notice">
							<p><?php esc_html_e( 'No menu assigned to this display location. Assign a menu', 'rovenstart' ); ?> 
							<a href="<?php echo esc_url( admin_url( 'nav-menus.php' ) ); ?>"><?php esc_html_e( 'visit Menus edit page', 'rovenstart' ); ?></a> 
							<?php esc_html_e( '(this notice is visible only for logged in users that can assign menus)', 'rovenstart' ); ?></p>
						</div>
						<?php
					}
					?>
				</div>

			</div><!-- end .rs-header-navbar-col -->

			<div class="rs-header-navbar-col">
				<?php
				if ( true === $darkmode_toggler ) {
					// Darkmode toggle icon.
					?>
					<a class="rs-color-scheme-toggler rs-display-on-sticky" href="<?php echo esc_url( home_url( '/' ) ); ?>">
						<i class="rovenstart-icon-moon"></i>
					</a>
					<?php
				}

				if ( true === $show_search ) {
					// Search icon.
					?>
					<a class="rs-search-toggler" href="#">
						<i class="rovenstart-icon-search"></i>
					</a>
				<?php } ?>
			</div><!-- end .rs-header-navbar-col -->

		</div><!-- end .rs-header-navbar -->

		<?php
		if ( true === $show_search ) {
			// Diplay an alternative search form for the header.
			$args['header_search'] = true;
			get_template_part( 'searchform', null, $args );
		}
		?>

	</div><!-- end .rs-section-content -->

</div><!-- end #rs-header -->
