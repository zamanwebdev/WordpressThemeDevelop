<?php
/**
 * Template part for displaying mobile navigation menu
 *
 * @package rovenstart
 */

?>
<div id="rs-mobile-menu-wrap">

	<div id="rs-mobile-menu-content">

		<div id="rs-mobile-menu-content-inner">

			<div id="rs-mobile-menu" class="menu">
				<?php
				if ( has_nav_menu( 'rovenstart-nav-menu4' ) ) {
					// Mobile navigation menu.
					wp_nav_menu(
						array(
							'theme_location' => 'rovenstart-nav-menu4',
							'container'      => false,
						)
					);
				} elseif ( current_user_can( 'edit_theme_options' ) ) {
					// No menu was assigned, notify via message only the users who can assign nav menus.
					?>
					<div class="rs-navmenu-notice">
						<p><?php esc_html_e( 'No menu assigned to this display location. Assign a menu', 'rovenstart' ); ?> 
						<a href="<?php echo esc_url( admin_url( 'nav-menus.php' ) ); ?>"><?php esc_html_e( 'visit Menus edit page', 'rovenstart' ); ?></a> 
						<?php esc_html_e( '(this notice is visible only for logged in users that can assign menus)', 'rovenstart' ); ?></p>
					</div>
					<?php
				}
				?>
			</div><!-- end .menu -->

			<?php
			if ( true === get_theme_mod( 'rovenstart_mobile_show_sidebar', true ) ) {
				get_sidebar( 'mobilemenu' );
			}
			?>

		</div><!-- end #rs-mobile-menu-content-inner -->

	</div><!-- end #rs-mobile-menu-content -->

	<div id="rs-mobile-menu-header">

		<a id="rs-mobile-menu-close" href="#"><i class="rovenstart-icon-x"></i></a>

	</div><!-- end #rs-mobile-menu-header -->

</div><!-- end #rs-mobile-menu-wrap -->
