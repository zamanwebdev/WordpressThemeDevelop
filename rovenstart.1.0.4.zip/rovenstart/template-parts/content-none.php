<?php
/**
 * Template part for displaying suitable messages when no content is found
 *
 * @package rovenstart
 */

?>
<div id="rs-none-header" class="rs-section">

	<div class="rs-section-title">

		<h3><?php esc_html_e( 'Nothing Found', 'rovenstart' ); ?></h3>

	</div>

</div><!-- end #rs-none-header -->

<div id="rs-content" class="rs-section">

	<div class="rs-section-content">

		<div id="rs-main-content">

			<?php
			if ( is_home() && current_user_can( 'publish_posts' ) ) {
				// No posts created or published.

				printf(
					'<p>' . wp_kses(
						/* translators: 1: link to WP admin new post page. */
						__( 'Ready to publish your first post? <a href="%1$s">Get started here</a>.', 'rovenstart' ),
						array(
							'a' => array(
								'href' => array(),
							),
						)
					) . '</p>',
					esc_url( admin_url( 'post-new.php' ) )
				);
			} elseif ( is_search() ) {
				// There were no search results.
				?>

				<p><?php esc_html_e( 'Sorry, but nothing matched your search terms.', 'rovenstart' ); ?></p>

				<div class="rs-none-search widget widget_search">
					<?php get_search_form(); ?>
				</div>
				<?php
			} else {
				// General situation where no content is found.
				?>

				<p><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'rovenstart' ); ?></p>
				<?php
				get_search_form();

			}
			?>

		</div><!-- end #rs-main-content -->

		<?php
		if ( true === get_theme_mod( 'rovenstart_archive_show_sidebar', true ) ) {
			get_sidebar( 'archive' );
		}
		?>

	</div><!-- end .rs-section-content -->

</div><!-- end #rs-content -->
