<?php
/**
 * Template part for displaying Header Hero Posts section
 *
 * @package rovenstart
 */

$count_h    = get_theme_mod( 'rovenstart_home_header_hero_posts_nr', 3 );
$posts_type = get_theme_mod( 'rovenstart_home_header_hero_content', 'recent-posts' );
$args_hero  = rovenstart_posts_args( $posts_type, $count_h, 'rovenstart_home_header_hero', false );

if ( true === get_theme_mod( 'rovenstart_home_header_hero_exclude', true ) && 'specific-posts' !== $posts_type ) {
	$exclude = rovenstart_exclusion_list( 'hero' );

	$args_hero['post__not_in'] = $exclude;
}

$query_posts = new WP_Query( $args_hero );

if ( $query_posts->have_posts() ) {
	// Header hero posts Customizer arguments.
	$style_type      = 'style1';
	$thumbnail_type  = get_theme_mod( 'rovenstart_home_header_hero_aspect', 'hero' );
	$category_enable = false;
	$structure_type  = 'slider';
	$excerpt_enable  = false;

	$grid_width = intval( get_theme_mod( 'rovenstart_max_width_content', 1230 ) );

	// Determine the most suitable image size for the selected image aspect based on the number of columns and grid width.
	if ( 'grid' === $structure_type ) {
		$nr_cols = intval( get_theme_mod( 'rovenstart_home_header_hero_cols_nr', 1 ) );
		if ( 1 === $nr_cols ) {
			$thumbnail_size = '-max';
		} elseif ( 2 === $nr_cols && 1400 < $grid_width ) {
			$thumbnail_size = '-mid';
		} else {
			$thumbnail_size = '-min';
		}
	} else {
		$nr_cols = intval( get_theme_mod( 'rovenstart_home_header_hero_slide_nr', 1 ) );
		if ( 1 === $nr_cols ) {
			$thumbnail_size = '-max';
		} else {
			$thumbnail_size = '-mid';
		}
	}

	// Prepare post template arguments.
	if ( 'style1' === $style_type || 'style2' === $style_type ) {

		$args = array(
			'category_enable' => $category_enable,
			'thumbnail_type'  => ' rs-card-aspect-ratio-' . $thumbnail_type,
			'thumbnail_size'  => $thumbnail_type,
			'thumbnail_limit' => $thumbnail_size,
			'excerpt_enable'  => $excerpt_enable,
		);

	} else {
		// Post style 3, 4, 5, 6 and 7 specific arguments.
		$icons_enable    = false;
		$author_enable   = get_theme_mod( 'rovenstart_home_header_hero_author', true );
		$date_enable     = get_theme_mod( 'rovenstart_home_header_hero_date', true );
		$comments_enable = get_theme_mod( 'rovenstart_home_header_hero_comments', true );

		$args = array(
			'category_enable' => $category_enable,
			'thumbnail_type'  => ' rs-card-aspect-ratio-' . $thumbnail_type,
			'thumbnail_size'  => $thumbnail_type,
			'thumbnail_limit' => $thumbnail_size,
			'icons_enable'    => $icons_enable,
			'author_enable'   => $author_enable,
			'date_enable'     => $date_enable,
			'comments_enable' => $comments_enable,
			'excerpt_enable'  => $excerpt_enable,
		);
	}
	?>
	<div id="rs-header-hero" class="rs-section">

		<div class="rs-section-content">

			<?php
			if ( 'grid' === $structure_type ) {
				// Header hero section grid mode.
				?>
				<div class="rs-grid cols-<?php echo $nr_cols; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">

					<?php while ( $query_posts->have_posts() ) { ?>
						<div class="rs-grid-item">
							<?php
							$query_posts->the_post();
							// Post template based on style.
							get_template_part( 'template-parts/post-styles/post', $style_type, $args );
							?>
						</div>
					<?php } ?>

				</div><!-- end .rs-grid -->
				<?php
			} else {
				// Header hero section slider mode.
				?>
				<div class="rs-slider cols-<?php echo $nr_cols; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">	

					<div class="rs-slider-content">

						<ul class="rs-slider-slides" data-slick='{"autoplay": false, "infinite": true }'>
							<?php while ( $query_posts->have_posts() ) { ?>
								<li>
									<?php
									$query_posts->the_post();
									// Post template based on style.
									get_template_part( 'template-parts/post-styles/post', $style_type, $args );
									?>
								</li>
							<?php } ?>
						</ul>

						<div class="rs-slider-arrows"></div>

					</div><!-- end .rs-slider-content -->

					<div class="rs-slider-pager"></div>

				</div><!-- end .rs-slider -->
			<?php } ?>		
		</div><!-- end .rs-section-content -->

	</div><!-- end #rs-header-hero -->
	<?php
	wp_reset_postdata();
}
