(function($){
	
	'use strict';

	// ...
	
})(jQuery);	

