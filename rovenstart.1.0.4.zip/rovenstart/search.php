<?php
/**
 * The template for displaying search results pages
 *
 * @package Rovenstart
 */

get_header();

?>
<div id="rs-search-header" class="rs-section">

	<div class="rs-section-title">

		<p class="rs-color-mute">
			<strong>
				<?php
				global $wp_query;
				/* translators: %s: search query. */
				printf( esc_html__( '%s Posts Matching', 'rovenstart' ), intval( $wp_query->found_posts ) );
				?>
			</strong>
		</p>

		<h1><?php the_search_query(); ?></h1>

	</div>

</div><!-- end #rs-search-header -->
<?php

if ( have_posts() ) {
	// Search page Customizer arguments.
	$nr_cols   = intval( get_theme_mod( 'rovenstart_search_grid_columns', 2 ) );
	$grid_type = 'grid';

	// Search posts Customizer arguments.
	$style_type      = 'style4';
	$category_enable = get_theme_mod( 'rovenstart_search_category', true );
	$thumbnail_type  = get_theme_mod( 'rovenstart_search_aspect', 'landscape' );
	$excerpt_enable  = get_theme_mod( 'rovenstart_search_excerpt', true );

	$sidebar    = get_theme_mod( 'rovenstart_search_show_sidebar', true );
	$grid_width = intval( get_theme_mod( 'rovenstart_max_width_content', 1230 ) );

	// Determine the most suitable image size for the selected image aspect based on the number of columns and grid width.
	if ( 1 === $nr_cols ) {
		if ( true === $sidebar && 1400 >= $grid_width ) {
			$thumbnail_size = '-mid';
		} else {
			$thumbnail_size = '-max';
		}
	} elseif ( 2 === $nr_cols ) {
		if ( true !== $sidebar && 1400 < $grid_width ) {
			$thumbnail_size = '-mid';
		} else {
			$thumbnail_size = '-min';
		}
	} else {
		$thumbnail_size = '-min';
	}

	if ( 'masonry' === $grid_type ) {
		$thumbnail_type = 'masonry';
	}

	// Prepare post template arguments.
	if ( 'style1' === $style_type || 'style2' === $style_type ) {
		$args = array(
			'category_enable' => $category_enable,
			'thumbnail_type'  => ' rs-card-aspect-ratio-' . $thumbnail_type,
			'thumbnail_size'  => $thumbnail_type,
			'thumbnail_limit' => $thumbnail_size,
			'excerpt_enable'  => $excerpt_enable,
		);
	} else {
		// Post style 3, 4, 5, 6 and 7 specific arguments.
		$icons_enable    = false;
		$author_enable   = get_theme_mod( 'rovenstart_search_author', true );
		$date_enable     = get_theme_mod( 'rovenstart_search_date', true );
		$comments_enable = get_theme_mod( 'rovenstart_search_comments', true );

		$args = array(
			'category_enable' => $category_enable,
			'thumbnail_type'  => ' rs-card-aspect-ratio-' . $thumbnail_type,
			'thumbnail_size'  => $thumbnail_type,
			'thumbnail_limit' => $thumbnail_size,
			'icons_enable'    => $icons_enable,
			'author_enable'   => $author_enable,
			'date_enable'     => $date_enable,
			'comments_enable' => $comments_enable,
			'excerpt_enable'  => $excerpt_enable,
		);
	}
	?>
	<div id="rs-content" class="rs-section">

		<div class="rs-section-content">

			<div id="rs-main-content">

				<?php
				if ( 'masonry' === $grid_type ) {
					// Posts masonry layout.
					?>
					<div id="rs-posts-list" class="rs-masonry-grid cols-<?php echo $nr_cols; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">

						<?php while ( have_posts() ) { ?>
							<div class="rs-masonry-grid-item">
								<?php
								the_post();
								// Post template based on style.
								get_template_part( 'template-parts/post-styles/post', $style_type, $args );
								?>
							</div>
						<?php } ?>

					</div><!-- end .rs-masonry-grid -->
					<?php
				} else {
					// Posts grid layout.
					?>
					<div id="rs-posts-list" class="rs-grid cols-<?php echo $nr_cols; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">

						<?php while ( have_posts() ) { ?>
							<div class="rs-grid-item">
								<?php
								the_post();
								// Post template based on style.
								get_template_part( 'template-parts/post-styles/post', $style_type, $args );
								?>
							</div>
						<?php } ?>

					</div><!-- end .rs-grid -->
					<?php
				}

				// Uses WordPress pagination with some arguments.
				rovenstart_pagination();
				?>

			</div><!-- end #rs-main-content -->

			<?php
			if ( true === $sidebar ) {
				get_sidebar( 'search' );
			}
			?>

		</div><!-- end .rs-section-content -->

	</div><!-- end #rs-content -->
	<?php
} else {
	// There is no content, use content-none template.
	get_template_part( 'template-parts/content', 'none' );
}

get_footer();
