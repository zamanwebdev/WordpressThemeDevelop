<?php
/**
 * The sidebar used for the mobile menu
 * 
 * @package Rovenstart
 */

?>
<div id="rs-mobile-menu-widgets">
	<?php
	// Check if the sidebar has widgets to display and the current user can add widgets.
	if ( ! is_active_sidebar( 'rovenstart-sidebar-mobilemenu' ) && current_user_can( 'edit_theme_options' ) ) {
		?>
		<div class="rs-sidebar-notice">

			<p><?php esc_html_e( "The Mobile Menu Sidebar doesn't have any widgets to display. Add widgets", 'rovenstart' ); ?> <a href="<?php echo esc_url( admin_url( 'widgets.php' ) ); ?>"><?php esc_html_e( 'visit Widgets Area', 'rovenstart' ); ?></a></p>

		</div><!-- end .rs-sidebar-notice -->
		<?php
	} else {
		dynamic_sidebar( 'rovenstart-sidebar-mobilemenu' ); 
	}
	?>
</div><!-- end #rs-sidebar-content -->
