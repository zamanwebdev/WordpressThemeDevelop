=== Rovenstart ===
Contributors: roventhemes, freemius
Tags: custom-logo, custom-menu, featured-images, threaded-comments, translation-ready
Requires at least: 6.0
Tested up to: 6.1
Requires PHP: 7.4
Stable tag: 1.0.4
License: GPL-2.0-or-later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Modern and easy to use Gutenberg Blog Theme

== Installation ==

1. In your admin panel, go to Appearance > Themes and click the Add New button.
2. Click Upload Theme and Choose File, then select the theme's .zip file. Click Install Now.
3. Click Activate to use your new theme right away.

== Frequently Asked Questions ==

= Does this theme support any plugins? =

RovenStart includes support for:
1. Page Builders: WPBakery, Elementor, Beaver Builder
2. Seo: Yoast SEO, Seo Framework, Rank Math Seo
3. Caching: WP Super Cache
4. Multilinguistic websites: WPML
5. Other: Contact Form 7

== Changelog ==

= 1.0.1 - December 2022 =
* Initial release

= 1.0.2 - December 2022 =
* replaced theme uri
* added images license for the theme Screenshot
* fixed the prefix of the freemius related function

= 1.0.3 - December 2022 =
* changed screenshot
* Changed license for images

= 1.0.4 - December 2022 =
* changed to public license for images
* changed screenshot

== Credits ==

RovenStart WordPress Theme, Copyright 2022 roventhemes.com
RovenStart is distributed under the terms of the GNU GPL and is based on Underscores https://underscores.me/, (C) 2012-2020 Automattic, Inc., [GPLv2 or later]

RovenStart bundles the following third-party resources:

- FlexMasonry
Author: Gilbert Pellegrom <gilbert@pellegrom.me>
License: The MIT License (MIT)
Source: https://github.com/gilbitron/flexmasonry

- stickybits 
Author: Jeff Wainwright <yowainwright@gmail.com> (https://jeffry.in)
License: The MIT License (MIT)
Source: https://github.com/yowainwright/stickybits

- lozad.js 
Author: Apoorv Saxena
License: The MIT License (MIT)
Source: https://github.com/ApoorvSaxena/lozad.js

- slick
Author: Ken Wheeler
License: The MIT License (MIT)
Source: https://github.com/kenwheeler/slick

== Screenshot Licenses ==

Screenshot images are all licensed under CC0 Public Domain

https://www.pexels.com/photo/clear-blue-sea-164041/
https://www.pexels.com/photo/beach-bungalow-caribbean-jetty-237272/
https://www.pexels.com/photo/brown-wooden-dock-462024/
