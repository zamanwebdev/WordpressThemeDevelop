<?php
/**
 * RovenStart: Tag Cloud widget template
 *
 * @package rovenstart
 */

/**
 * Adds RovenStart: Social Networks List widget.
 */
class RS_Widget_Tag_Cloud extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	public function __construct() {
		parent::__construct(
			'rs_widget_tag_cloud', // Widget base ID.
			esc_html__( 'RovenStart: Tag Cloud', 'rovenstart' ), // Widget name.
			array(
				'description' => esc_html__( 'Displays a custom tag cloud', 'rovenstart' ),
				'classname'   => 'rs-widget-tag-cloud',
			) // Widget description and class args.
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		$title = apply_filters( 'widget_title', $instance['title'] );
		$tags  = apply_filters( 'widget_tags', $instance['tags'] );

		echo wp_kses_post( $args['before_widget'] );

		if ( ! empty( $title ) ) {
			echo $args['before_title'] . $title . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		if ( 'tags' === $tags ) {
			$tags_list = get_tags( array( 'hide_empty' => false ) );
		} else {
			$tags_list = get_tags();
		}
		?>
		<div>
			<?php
			if ( ! empty( $tags_list ) ) {
				foreach ( $tags_list as $tag ) {
					?>
					<a href="<?php echo esc_url( get_tag_link( $tag->term_id ) ); ?>" title="<?php echo esc_attr( $tag->name ); ?>"><?php echo esc_html( $tag->name ); ?></a>
					<?php
				}
			} else {
				?>
				<li><?php esc_html_e( 'There are no post tags', 'rovenstart' ); ?></li>
			<?php } ?>
		</div>
		<?php
		echo wp_kses_post( $args['after_widget'] );
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		if ( isset( $instance['title'] ) ) {
			$title = $instance['title'];
		} else {
			$title = '';
		}

		if ( isset( $instance['tags'] ) ) {
			$tags = $instance['tags'];
		} else {
			$tags = '';
		}
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'rovenstart' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<input type="checkbox" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'tags' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'tags' ) ); ?>"<?php echo ( 'tags' === $tags ) ? ' checked' : ''; ?> value="tags"><?php esc_html_e( 'Display empty tags?', 'rovenstart' ); ?>
		</p>
		<?php
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance          = array();
		$instance['title'] = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
		$instance['tags']  = ( ! empty( $new_instance['tags'] ) ) ? esc_attr( $new_instance['tags'] ) : '';

		return $instance;
	}

}
