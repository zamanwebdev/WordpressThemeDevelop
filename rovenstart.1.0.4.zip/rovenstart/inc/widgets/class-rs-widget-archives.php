<?php
/**
 * RovenStart: Archives widget template
 *
 * @package rovenstart
 */

/**
 * Adds RovenStart: Social Networks List widget.
 */
class RS_Widget_Archives extends WP_Widget {

	/**
	 * Register widget with WordPress.
	 */
	public function __construct() {
		parent::__construct(
			'rs_widget_archives', // Widget base ID.
			esc_html__( 'RovenStart: Archives', 'rovenstart' ), // Widget name.
			array(
				'description' => esc_html__( 'Displays a list of Archives', 'rovenstart' ),
				'classname'   => 'rs-widget-archive',
			) // Widget description and class args.
		);
	}

	/**
	 * Front-end display of widget.
	 *
	 * @see WP_Widget::widget()
	 *
	 * @param array $args     Widget arguments.
	 * @param array $instance Saved values from database.
	 */
	public function widget( $args, $instance ) {
		$title  = apply_filters( 'widget_title', $instance['title'] );
		$number = apply_filters( 'widget_number', $instance['number'] );

		echo wp_kses_post( $args['before_widget'] );

		if ( ! empty( $title ) ) {
			echo $args['before_title'] . $title . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}

		if ( 'number' === $number ) {
			$args_a = array(
				'type'            => 'monthly',
				'format'          => 'html',
				'show_post_count' => true,
				'echo'            => false,
			);
		} else {
			$args_a = array(
				'type'            => 'monthly',
				'format'          => 'html',
				'show_post_count' => false,
				'echo'            => false,
			);
		}

		$archives = wp_get_archives( $args_a );
		?>
		<ul>
			<?php
			if ( '' !== $archives ) {
				$archives = str_replace( '<a href', '<a class="rs-text-animation-2" href', $archives );
				$archives = str_replace( '&nbsp;(', '<span>', $archives );
				$archives = str_replace( ')</li>', '</span></li>', $archives );

				echo wp_kses_post( $archives );
			} else {
				?>
				<li><?php esc_html_e( 'There are no post archives', 'rovenstart' ); ?></li>
			<?php } ?>
		</ul>
		<?php
		echo wp_kses_post( $args['after_widget'] );
	}

	/**
	 * Back-end widget form.
	 *
	 * @see WP_Widget::form()
	 *
	 * @param array $instance Previously saved values from database.
	 */
	public function form( $instance ) {
		if ( isset( $instance['title'] ) ) {
			$title = $instance['title'];
		} else {
			$title = '';
		}

		if ( isset( $instance['number'] ) ) {
			$number = $instance['number'];
		} else {
			$number = 'number';
		}
		?>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title:', 'rovenstart' ); ?></label>
			<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>" />
		</p>
		<p>
			<input type="checkbox" class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>"<?php echo ( 'number' === $number ) ? ' checked' : ''; ?> value="number"><?php esc_html_e( 'Show number of posts?', 'rovenstart' ); ?>
		</p>
		<?php
	}

	/**
	 * Sanitize widget form values as they are saved.
	 *
	 * @see WP_Widget::update()
	 *
	 * @param array $new_instance Values just sent to be saved.
	 * @param array $old_instance Previously saved values from database.
	 *
	 * @return array Updated safe values to be saved.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance           = array();
		$instance['title']  = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
		$instance['number'] = ( ! empty( $new_instance['number'] ) ) ? esc_attr( $new_instance['number'] ) : '';
		return $instance;
	}

}
