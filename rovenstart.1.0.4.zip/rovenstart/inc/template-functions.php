<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package rovenstart
 */

if ( ! function_exists( 'rovenstart_body_classes' ) ) {
	/**
	 * Adds custom classes to the array of body classes.
	 *
	 * @param array $classes - contains the WordPress body.
	 */
	function rovenstart_body_classes( $classes ) {
		// Adds a class of hfeed to non-singular pages.
		if ( ! is_singular() ) {
			$classes[] = 'hfeed';
		}

		// Prepare the back to top and sticky header related body classes.
		if ( true === get_theme_mod( 'rovenstart_sticky_header_on_mobile', true ) ) {
			$classes[] = 'rs-sticky-header-mobile';
		}
		if ( true === get_theme_mod( 'rovenstart_sticky_header_on_desktop', true ) ) {
			$classes[] = 'rs-sticky-header-desktop';
		}

		$woocommerce_page = false;

		// Determine the current type of page and prepare the relevant sidebar classes.
		if ( ( is_home() && is_front_page() ) || is_front_page() ) {
			if ( true === get_theme_mod( 'rovenstart_home_show_sidebar', true ) ) {
				$classes[] = 'rs-has-sidebar';
				if ( true === get_theme_mod( 'rovenstart_enable_sticky_sidebar', true ) ) {
					$classes[] = 'rs-sticky-sidebar';
				}
			}
		} elseif ( true === $woocommerce_page ) {
			$classes[] = 'rs-woocommerce-main';
		} elseif ( is_search() ) {
			if ( true === get_theme_mod( 'rovenstart_search_show_sidebar', true ) ) {
				$classes[] = 'rs-has-sidebar';
				if ( true === get_theme_mod( 'rovenstart_enable_sticky_sidebar', true ) ) {
					$classes[] = 'rs-sticky-sidebar';
				}
			}
		} elseif ( is_author() ) {
			if ( true === get_theme_mod( 'rovenstart_author_show_sidebar', true ) ) {
				$classes[] = 'rs-has-sidebar';
				if ( true === get_theme_mod( 'rovenstart_enable_sticky_sidebar', true ) ) {
					$classes[] = 'rs-sticky-sidebar';
				}
			}
		} elseif ( is_page() ) {
			$classes[] = 'rs-page-main';
		} elseif ( is_single() ) {
			if ( true === get_theme_mod( 'rovenstart_post_show_sidebar' ) ) {
				$classes[] = 'rs-has-sidebar';
				if ( true === get_theme_mod( 'rovenstart_enable_sticky_sidebar', true ) ) {
					$classes[] = 'rs-sticky-sidebar';
				}
			}
		} elseif ( is_category() || is_tag() || is_date() ) {
			if ( true === get_theme_mod( 'rovenstart_archive_show_sidebar', true ) ) {
				$classes[] = 'rs-has-sidebar';
				if ( true === get_theme_mod( 'rovenstart_enable_sticky_sidebar', true ) ) {
					$classes[] = 'rs-sticky-sidebar';
				}
			}
		}

		return $classes;
	}

	add_filter( 'body_class', 'rovenstart_body_classes' );
}

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function rovenstart_pingback_header() {
	if ( is_singular() && pings_open() ) {
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}

add_action( 'wp_head', 'rovenstart_pingback_header' );

/**
 * This function prepares the arguments for thumbnail image size, class, srcset and sizes.
 *
 * @param string $thumb_type - indicates the thumbnail main aspect ratio.
 * @param int    $mode - indicates the thumnail is for cards with object-fit, which require diferent aspect ratio on smaller devices.
 * @param string $limit - indicates if the function is used by home header or featured posts.
 */
function rovenstart_thumb_size_args( $thumb_type, $mode = 1, $limit = '-max' ) {
	// Prepare the post thumbnail class and ratio variables.
	$thumb_id   = get_post_thumbnail_id();
	$thumb_size = 'rovenstart-' . $thumb_type . $limit;

	if ( 'masonry' === $thumb_type || 0 === $mode ) {
		if ( '-max' === $limit ) {
			$thumb_args = array(
				'class'  => 'lozad',
				'srcset' => wp_get_attachment_image_url( $thumb_id, 'rovenstart-' . $thumb_type . '-max' ) . ' 1353w, ' .
							wp_get_attachment_image_url( $thumb_id, 'rovenstart-' . $thumb_type . '-mid' ) . ' 1024w, ' .
							wp_get_attachment_image_url( $thumb_id, 'rovenstart-' . $thumb_type . '-min' ) . ' 810w',
				'sizes'  => '(max-width: 767.98px) 810px, (max-width: 991px) 1024px, 1353px',
			);
		} elseif ( '-mid' === $limit ) {
			$thumb_args = array(
				'class'  => 'lozad',
				'srcset' => wp_get_attachment_image_url( $thumb_id, 'rovenstart-' . $thumb_type . '-mid' ) . ' 1353w, ' .
							wp_get_attachment_image_url( $thumb_id, 'rovenstart-' . $thumb_type . '-min' ) . ' 810w',
				'sizes'  => '(max-width: 767.98px) 810px, 1024px',
			);
		} else {
			$thumb_args = array(
				'class'  => 'lozad',
				'srcset' => wp_get_attachment_image_url( $thumb_id, 'rovenstart-' . $thumb_type . '-min' ) . ' 810w',
				'sizes'  => '810px',
			);
		}
	} elseif ( 1 === $mode && ( 'hero' === $thumb_type || 'landscape' === $thumb_type ) ) {
		if ( '-max' === $limit ) {
			$thumb_args = array(
				'class'  => 'lozad',
				'srcset' => wp_get_attachment_image_url( $thumb_id, 'rovenstart-' . $thumb_type . '-max' ) . ' 1353w, ' .
							wp_get_attachment_image_url( $thumb_id, 'rovenstart-square-mid' ) . ' 1024w, ' .
							wp_get_attachment_image_url( $thumb_id, 'rovenstart-portrait-min' ) . ' 810w',
				'sizes'  => '(max-width: 767.98px) 810px, (max-width: 991px) 1024px, 1353px',
			);
		} elseif ( '-mid' === $limit ) {
			$thumb_args = array(
				'class'  => 'lozad',
				'srcset' => wp_get_attachment_image_url( $thumb_id, 'rovenstart-' . $thumb_type . '-mid' ) . ' 932w, ' .
							wp_get_attachment_image_url( $thumb_id, 'rovenstart-square-mid' ) . ' 1024w, ' .
							wp_get_attachment_image_url( $thumb_id, 'rovenstart-portrait-min' ) . ' 810w',
				'sizes'  => '(max-width: 767.98px) 810px, (max-width: 992px) 1024px, 932px',
			);
		} else {
			$thumb_args = array(
				'class'  => 'lozad',
				'srcset' => wp_get_attachment_image_url( $thumb_id, 'rovenstart-' . $thumb_type . '-min' ) . ' 932w, ' .
							wp_get_attachment_image_url( $thumb_id, 'rovenstart-square-min' ) . ' 1024w, ' .
							wp_get_attachment_image_url( $thumb_id, 'rovenstart-portrait-min' ) . ' 810w',
				'sizes'  => '(max-width: 767.98px) 810px, (max-width: 992px) 1024px, 932px',
			);
		}
	} else {
		if ( '-max' === $limit ) {
			$thumb_args = array(
				'class'  => 'lozad',
				'srcset' => wp_get_attachment_image_url( $thumb_id, 'rovenstart-' . $thumb_type . '-max' ) . ' 1353w, ' .
							wp_get_attachment_image_url( $thumb_id, 'rovenstart-' . $thumb_type . '-mid' ) . ' 1024w, ' .
							wp_get_attachment_image_url( $thumb_id, 'rovenstart-portrait-min' ) . ' 810w',
				'sizes'  => '(max-width: 767.98px) 810px, (max-width: 991px) 1024px, 1353px',
			);
		} elseif ( '-mid' === $limit ) {
			$thumb_args = array(
				'class'  => 'lozad',
				'srcset' => wp_get_attachment_image_url( $thumb_id, 'rovenstart-' . $thumb_type . '-mid' ) . ' 1024w, ' .
							wp_get_attachment_image_url( $thumb_id, 'rovenstart-portrait-min' ) . ' 810w',
				'sizes'  => '(max-width: 767.98px) 810px, 1024px',
			);
		} else {
			$thumb_args = array(
				'class'  => 'lozad',
				'srcset' => wp_get_attachment_image_url( $thumb_id, 'rovenstart-' . $thumb_type . '-min' ) . ' 1024w, ' .
							wp_get_attachment_image_url( $thumb_id, 'rovenstart-portrait-min' ) . ' 810w',
				'sizes'  => '(max-width: 767.98px) 810px, 1024px',
			);
		}
	}

	$thumb_data = array(
		'size' => $thumb_size,
		'args' => $thumb_args,
	);

	return $thumb_data;
}

/**
 * Function for modified pagination.
 */
function rovenstart_pagination() {
	the_posts_pagination(
		array(
			'mid_size'           => 1,
			'prev_next'          => true,
			'prev_text'          => '<span class="meta-nav screen-reader-text">' . esc_html__( 'Prev', 'rovenstart' ) . '</span>',
			'next_text'          => '<span class="meta-nav screen-reader-text">' . esc_html__( 'Next', 'rovenstart' ) . '</span>',
			'before_page_number' => '<span class="meta-nav screen-reader-text">' . esc_html__( 'Current page:', 'rovenstart' ) . ' </span>',
		)
	);
}

// Check if theme lazy loading is enabled.
if ( true === get_theme_mod( 'rovenstart_lazy_loading', true ) ) {

	// Disable WordPress default lazyload to avoid potential issues with the theme lazy load script.
	add_filter( 'wp_lazy_loading_enabled', '__return_false' );

	add_filter( 'wp_content_img_tag', 'rovenstart_content_image' );
	/**
	 * Add the lozad class to images for the theme lazy loading script.
	 *
	 * @param string $filtered_image - full img tag with attributes.
	 */
	function rovenstart_content_image( $filtered_image ) {

		$filtered_image = str_replace( 'class="', 'class="lozad ', $filtered_image );

		return $filtered_image;
	}
}

/**
 * Wrap Gutenberg video, audio and gallery blocks.
 *
 * @param string $block_content - The block content about to be appended.
 * @param array  $block - The full block, including name and attributes.
 */
function rovenstart_wrap_block( $block_content, $block ) {
	if ( ! isset( $block['blockName'] ) ) {
		$block['blockName'] = '';
	}
	if ( ! isset( $block['attrs']['type'] ) ) {
		$block['attrs']['type'] = '';
	}
	if ( ! isset( $block['attrs']['providerNameSlug'] ) ) {
		$block['attrs']['providerNameSlug'] = '';
	}

	if ( ! has_blocks() ) {
		$block_content = str_replace( array( '<iframe', '</iframe>' ), array( '<div class="rs-media-wrapper rs-media-video"><iframe', '</iframe></div>' ), $block_content );
	} elseif ( 'core/gallery' === $block['blockName'] ) {
		// Media Gallery block.
		$block_content = '<div class="rs-gallery-wrapper rs-media-gallery">' . $block_content . '</div>';
	} elseif ( ( 'core/embed' === $block['blockName'] && 'video' === $block['attrs']['type'] ) || 'core/video' === $block['blockName'] ) {
		// Video embed block.
		$block_content = '<div class="rs-media-wrapper rs-media-video">' . $block_content . '</div>';
	} elseif ( ( 'core/embed' === $block['blockName'] && 'audio' === $block['attrs']['type'] ) || 'core/audio' === $block['blockName'] ) {
		// Audio embed block.
		$block_content = '<div class="rs-media-wrapper rs-media-audio">' . $block_content . '</div>';
	} elseif ( 'core/embed' === $block['blockName'] && ( 'soundcloud' === $block['attrs']['providerNameSlug'] || 'mixcloud' === $block['attrs']['providerNameSlug'] ) ) {
		// Video embed block.
		$block_content = '<div class="rs-media-wrapper rs-media-audio">' . $block_content . '</div>';
	} elseif ( 'core/embed' === $block['blockName'] ) {
		// Video embed block.
		$block_content = '<div class="rs-media-wrapper rs-media-video">' . $block_content . '</div>';
	}

	return $block_content;
}

add_filter( 'render_block', 'rovenstart_wrap_block', 10, 2 );

/**
 * Function used for increasing the post views count.
 *
 * @param int $post_id - the views count will be increased for the post with this id.
 */
function rovenstart_view_count( $post_id = 0 ) {
	if ( 0 !== $post_id ) {
		$count = get_post_meta( $post_id, 'post_views', true );

		if ( '' === $count ) {
			// There were no views so far for the specified post, add one default view.
			update_post_meta( $post_id, 'post_views', '1' );
		} else {
			// Increase the post view count by 1 and register the new view count.
			$count++;
			update_post_meta( $post_id, 'post_views', $count );
		}
	}
}

add_action( 'wp_ajax_rovenstart_count_start', 'rovenstart_count_call_check' );
add_action( 'wp_ajax_nopriv_rovenstart_count_start', 'rovenstart_count_call_check' );

/**
 * This function is used for checking the ajax call for post view counting.
 */
function rovenstart_count_call_check() {
	if ( isset( $_POST['action'] ) && isset( $_POST['rs_nonce'] ) ) {
		// Check the ajax call provided data.
		if ( 'rovenstart_count_start' === $_POST['action'] && false !== wp_verify_nonce( sanitize_key( $_POST['rs_nonce'] ), 'rovenstart-viewcount-nonce' ) ) {
			// Check the provided post id.
			if ( ! isset( $_POST['rs_post_id'] ) ) {
				$post_id = (int) $_POST['rs_post_id'];
			} else {
				exit;
			}

			rovenstart_view_count( $post_id );
			exit;
		}
		exit;
	}
	exit;
}

/**
 * This function is used for infinite scroll posts/products loop, via Jetpack infinite scroll render parameter.
 */
function rovenstart_posts_loop() {
	if ( class_exists( 'WooCommerce' ) && ( is_shop() || is_product_taxonomy() || is_product_category() || is_product_tag() ) ) {
		// Woocommerce products loop.
		woocommerce_product_loop_start();
		while ( have_posts() ) {
			the_post();
			wc_get_template_part( 'content', 'product' );
		}
		woocommerce_product_loop_end();
	} else {
		// Theme posts loop.
		if ( ( is_home() && is_front_page() ) || is_front_page() ) {
			// Main Home Posts Customizer arguments.
			$style_type      = 'style4';
			$nr_cols         = intval( get_theme_mod( 'rovenstart_home_recent_posts_grid_cols', 2 ) );
			$grid_type       = 'grid';
			$thumbnail_type  = get_theme_mod( 'rovenstart_home_recent_posts_aspect', 'hero' );
			$category_enable = get_theme_mod( 'rovenstart_home_recent_posts_category', true );
			$excerpt_enable  = get_theme_mod( 'rovenstart_home_recent_posts_excerpt', true );

			$sidebar    = get_theme_mod( 'rovenstart_home_show_sidebar', true );
			$grid_width = intval( get_theme_mod( 'rovenstart_max_width_content', 1230 ) );

			// Determine the most suitable image size for the selected image aspect based on the number of columns and grid width.
			if ( 1 === $nr_cols ) {
				if ( true === $sidebar && 1400 >= $grid_width ) {
					$thumbnail_size = '-mid';
				} else {
					$thumbnail_size = '-max';
				}
			} elseif ( 2 === $nr_cols ) {
				if ( true !== $sidebar && 1400 < $grid_width ) {
					$thumbnail_size = '-mid';
				} else {
					$thumbnail_size = '-min';
				}
			} else {
				$thumbnail_size = '-min';
			}

			if ( 'masonry' === $grid_type ) {
				$thumbnail_type = 'masonry';
			}

			// Prepare post template arguments.
			if ( 'style1' === $style_type || 'style2' === $style_type ) {
				$args = array(
					'category_enable' => $category_enable,
					'thumbnail_type'  => ' rs-card-aspect-ratio-' . $thumbnail_type,
					'thumbnail_size'  => $thumbnail_type,
					'thumbnail_limit' => $thumbnail_size,
					'excerpt_enable'  => $excerpt_enable,
				);
			} else {
				// Post style 3, 4, 5, 6 and 7 specific arguments.
				$icons_enable    = false;
				$author_enable   = get_theme_mod( 'rovenstart_home_recent_posts_author', true );
				$date_enable     = get_theme_mod( 'rovenstart_home_recent_posts_date', true );
				$comments_enable = get_theme_mod( 'rovenstart_home_recent_posts_comments', true );

				$args = array(
					'category_enable' => $category_enable,
					'thumbnail_type'  => ' rs-card-aspect-ratio-' . $thumbnail_type,
					'thumbnail_size'  => $thumbnail_type,
					'thumbnail_limit' => $thumbnail_size,
					'icons_enable'    => $icons_enable,
					'author_enable'   => $author_enable,
					'date_enable'     => $date_enable,
					'comments_enable' => $comments_enable,
					'excerpt_enable'  => $excerpt_enable,
				);
			}
		} elseif ( is_search() ) {
			// Search posts Customizer arguments.
			$style_type      = 'style4';
			$category_enable = get_theme_mod( 'rovenstart_search_category', true );
			$thumbnail_type  = get_theme_mod( 'rovenstart_search_aspect', 'landscape' );
			$excerpt_enable  = get_theme_mod( 'rovenstart_search_excerpt', true );

			$sidebar    = get_theme_mod( 'rovenstart_search_show_sidebar', true );
			$grid_width = intval( get_theme_mod( 'rovenstart_max_width_content', 1230 ) );
			$nr_cols    = intval( get_theme_mod( 'rovenstart_search_grid_columns', 2 ) );

			// Determine the most suitable image size for the selected image aspect based on the number of columns and grid width.
			if ( 1 === $nr_cols ) {
				if ( true === $sidebar && 1400 >= $grid_width ) {
					$thumbnail_size = '-mid';
				} else {
					$thumbnail_size = '-max';
				}
			} elseif ( 2 === $nr_cols ) {
				if ( true !== $sidebar && 1400 < $grid_width ) {
					$thumbnail_size = '-mid';
				} else {
					$thumbnail_size = '-min';
				}
			} else {
				$thumbnail_size = '-min';
			}

			// Prepare post template arguments.
			if ( 'style1' === $style_type || 'style2' === $style_type ) {
				$args = array(
					'category_enable' => $category_enable,
					'thumbnail_type'  => ' rs-card-aspect-ratio-' . $thumbnail_type,
					'thumbnail_size'  => $thumbnail_type,
					'thumbnail_limit' => $thumbnail_size,
					'excerpt_enable'  => $excerpt_enable,
				);
			} else {
				// Post style 3, 4, 5, 6 and 7 specific arguments.
				$icons_enable    = false;
				$author_enable   = get_theme_mod( 'rovenstart_search_author', true );
				$date_enable     = get_theme_mod( 'rovenstart_search_date', true );
				$comments_enable = get_theme_mod( 'rovenstart_search_comments', true );

				$args = array(
					'category_enable' => $category_enable,
					'thumbnail_type'  => ' rs-card-aspect-ratio-' . $thumbnail_type,
					'thumbnail_size'  => $thumbnail_type,
					'thumbnail_limit' => $thumbnail_size,
					'icons_enable'    => $icons_enable,
					'author_enable'   => $author_enable,
					'date_enable'     => $date_enable,
					'comments_enable' => $comments_enable,
					'excerpt_enable'  => $excerpt_enable,
				);
			}
		} elseif ( is_author() ) {
			// author posts Customizer arguments.
			$style_type      = 'style4';
			$category_enable = get_theme_mod( 'rovenstart_author_category', true );
			$thumbnail_type  = get_theme_mod( 'rovenstart_author_aspect', 'landscape' );
			$excerpt_enable  = get_theme_mod( 'rovenstart_author_excerpt', true );

			$nr_cols    = intval( get_theme_mod( 'rovenstart_author_grid_columns', 2 ) );
			$sidebar    = get_theme_mod( 'rovenstart_author_show_sidebar', true );
			$grid_width = intval( get_theme_mod( 'rovenstart_max_width_content', 1230 ) );

			// Determine the most suitable image size for the selected image aspect based on the number of columns and grid width.
			if ( 1 === $nr_cols ) {
				if ( true === $sidebar && 1400 >= $grid_width ) {
					$thumbnail_size = '-mid';
				} else {
					$thumbnail_size = '-max';
				}
			} elseif ( 2 === $nr_cols ) {
				if ( true !== $sidebar && 1400 < $grid_width ) {
					$thumbnail_size = '-mid';
				} else {
					$thumbnail_size = '-min';
				}
			} else {
				$thumbnail_size = '-min';
			}

			// Prepare post template arguments.
			if ( 'style1' === $style_type || 'style2' === $style_type ) {
				$args = array(
					'category_enable' => $category_enable,
					'thumbnail_type'  => ' rs-card-aspect-ratio-' . $thumbnail_type,
					'thumbnail_size'  => $thumbnail_type,
					'thumbnail_limit' => $thumbnail_size,
					'excerpt_enable'  => $excerpt_enable,
				);
			} else {
				// Post style 3, 4, 5, 6 and 7 specific arguments.
				$icons_enable    = false;
				$author_enable   = get_theme_mod( 'rovenstart_author_author', true );
				$date_enable     = get_theme_mod( 'rovenstart_author_date', true );
				$comments_enable = get_theme_mod( 'rovenstart_author_comments', true );

				$args = array(
					'category_enable' => $category_enable,
					'thumbnail_type'  => ' rs-card-aspect-ratio-' . $thumbnail_type,
					'thumbnail_size'  => $thumbnail_type,
					'thumbnail_limit' => $thumbnail_size,
					'icons_enable'    => $icons_enable,
					'author_enable'   => $author_enable,
					'date_enable'     => $date_enable,
					'comments_enable' => $comments_enable,
					'excerpt_enable'  => $excerpt_enable,
				);
			}
		} else {
			// Archive/Category posts Customizer arguments.
			$style_type      = get_theme_mod( 'rovenstart_archive_style', 'style4' );
			$category_enable = get_theme_mod( 'rovenstart_archive_category', true );
			$thumbnail_type  = get_theme_mod( 'rovenstart_archive_aspect', 'landscape' );
			$excerpt_enable  = get_theme_mod( 'rovenstart_archive_excerpt', true );

			$nr_cols    = intval( get_theme_mod( 'rovenstart_archive_grid_columns', 2 ) );
			$sidebar    = get_theme_mod( 'rovenstart_archive_show_sidebar', true );
			$grid_width = intval( get_theme_mod( 'rovenstart_max_width_content', 1230 ) );

			// Determine the most suitable image size for the selected image aspect based on the number of columns and grid width.
			if ( 1 === $nr_cols ) {
				if ( true === $sidebar && 1400 >= $grid_width ) {
					$thumbnail_size = '-mid';
				} else {
					$thumbnail_size = '-max';
				}
			} elseif ( 2 === $nr_cols ) {
				if ( true !== $sidebar && 1400 < $grid_width ) {
					$thumbnail_size = '-mid';
				} else {
					$thumbnail_size = '-min';
				}
			} else {
				$thumbnail_size = '-min';
			}

			// Prepare post template arguments.
			if ( 'style1' === $style_type || 'style2' === $style_type ) {
				$args = array(
					'category_enable' => $category_enable,
					'thumbnail_type'  => ' rs-card-aspect-ratio-' . $thumbnail_type,
					'thumbnail_size'  => $thumbnail_type,
					'thumbnail_limit' => $thumbnail_size,
					'excerpt_enable'  => $excerpt_enable,
				);
			} else {
				// Post style 3, 4, 5, 6 and 7 specific arguments.
				$icons_enable    = false;
				$author_enable   = get_theme_mod( 'rovenstart_archive_author', true );
				$date_enable     = get_theme_mod( 'rovenstart_archive_date', true );
				$comments_enable = get_theme_mod( 'rovenstart_archive_comments', true );

				$args = array(
					'category_enable' => $category_enable,
					'thumbnail_type'  => ' rs-card-aspect-ratio-' . $thumbnail_type,
					'thumbnail_size'  => $thumbnail_type,
					'thumbnail_limit' => $thumbnail_size,
					'icons_enable'    => $icons_enable,
					'author_enable'   => $author_enable,
					'date_enable'     => $date_enable,
					'comments_enable' => $comments_enable,
					'excerpt_enable'  => $excerpt_enable,
				);
			}
		}

		if ( 'masonry' === $grid_type ) {
			while ( have_posts() ) {
				?>
				<div class="rs-masonry-grid-item">
					<?php
					the_post();
					// Post template based on style.
					get_template_part( 'template-parts/post-styles/post', $style_type, $args );
					?>
				</div>
				<?php
			}
		} else {
			while ( have_posts() ) {
				?>
				<div class="rs-grid-item">
					<?php
					the_post();
					// Post template based on style.
					get_template_part( 'template-parts/post-styles/post', $style_type, $args );
					?>
				</div>
				<?php
			}
		}
	}
}

/**
 * Register the sidebar and footer widget areas.
 */
function rovenstart_widgets_init() {

	$before_title = '<h5 class="widget-title">';
	$after_title  = '</h5>';
	$title_style  = get_theme_mod( 'rovenstart_widget_title_style', 'none' );

	// Modify Widget title structure based on the widget styling option.
	if ( 'style-1' === $title_style ) {
		$before_title = '<h5 class="widget-title widget-title-style-1">';
	} elseif ( 'style-2' === $title_style ) {
		$before_title = '<h5 class="widget-title widget-title-style-2">';
	} elseif ( 'style-3' === $title_style ) {
		$before_title = '<h5 class="widget-title widget-title-style-3">';
	} elseif ( 'style-4' === $title_style ) {
		$before_title = '<h5 class="widget-title widget-title-style-4">';
	} elseif ( 'style-5' === $title_style ) {
		$before_title = '<h5 class="widget-title widget-title-style-5">';
	} elseif ( 'style-6' === $title_style ) {
		$before_title = '<h5 class="widget-title widget-title-style-6">';
		$after_title  = '<svg width="33" height="6" xmlns="https://www.w3.org/2000/svg">
		<path d="M0,4c1.505,0,2.195-0.809,3.069-1.832C3.936,1.152,4.919,0,6.743,0c1.899,0,3.008,1.29,3.898,2.326
		C11.534,3.364,12.131,4,13.128,4c1.505,0,2.195-0.809,3.069-1.832C17.064,1.152,18.047,0,19.871,0c1.9,0,3.009,1.29,3.899,2.326
		C24.662,3.364,25.26,4,26.257,4c1.506,0,2.195-0.809,3.069-1.832C30.193,1.152,31.177,0,33,0v3.528
		c-0.859,0-1.354,0.327-2.152,0.906C29.884,5.131,28.685,6,26.257,6c-1.966,0-3.096-0.812-4.003-1.465
		c-0.869-0.624-1.448-1.007-2.383-1.007c-0.859,0-1.354,0.327-2.152,0.906C16.755,5.131,15.556,6,13.128,6
		c-1.966,0-3.096-0.812-4.004-1.465C8.256,3.91,7.677,3.528,6.743,3.528c-0.859,0-1.354,0.327-2.152,0.906C3.626,5.131,2.428,6,0,6V4
		z"/></svg></h5>';
	} elseif ( 'style-7' === $title_style ) {
		$before_title = '<h5 class="widget-title widget-title-style-7"><span>';
		$after_title  = '</span></h5>';
	} elseif ( 'style-8' === $title_style ) {
		$before_title = '<h5 class="widget-title widget-title-style-8"><span>';
		$after_title  = '</span></h5>';
	} elseif ( 'style-9' === $title_style ) {
		$before_title = '<h5 class="widget-title widget-title-style-9">';
	} elseif ( 'style-10' === $title_style ) {
		$before_title = '<h5 class="widget-title widget-title-style-10"><span>';
		$after_title  = '</span></h5>';
	}

	register_sidebar(
		array(
			'name'          => esc_html__( 'Home Page Sidebar', 'rovenstart' ),
			'id'            => 'rovenstart-sidebar-home',
			'description'   => esc_html__( 'The widgets added here will appear in the sidebar enabled for the Home page', 'rovenstart' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => $before_title,
			'after_title'   => $after_title,
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Archive/Category Sidebar', 'rovenstart' ),
			'id'            => 'rovenstart-sidebar-archive',
			'description'   => esc_html__( 'The widgets added here will appear in the sidebar enabled for archive/category', 'rovenstart' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => $before_title,
			'after_title'   => $after_title,
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Author Sidebar', 'rovenstart' ),
			'id'            => 'rovenstart-sidebar-author',
			'description'   => esc_html__( 'The widgets added here will appear in the sidebar enabled for author page', 'rovenstart' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => $before_title,
			'after_title'   => $after_title,
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Search Sidebar', 'rovenstart' ),
			'id'            => 'rovenstart-sidebar-search',
			'description'   => esc_html__( 'The widgets added here will appear in the sidebar enabled for Search', 'rovenstart' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => $before_title,
			'after_title'   => $after_title,
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Mobile Menu Sidebar', 'rovenstart' ),
			'id'            => 'rovenstart-sidebar-mobilemenu',
			'description'   => esc_html__( 'The widgets added here will appear in the sidebar enabled for the Mobile Menu', 'rovenstart' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => $before_title,
			'after_title'   => $after_title,
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Colum 1', 'rovenstart' ),
			'id'            => 'rovenstart-footer-1',
			'description'   => esc_html__( 'The widgets added here will appear in the first column of the Footer', 'rovenstart' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => $before_title,
			'after_title'   => $after_title,
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Colum 2', 'rovenstart' ),
			'id'            => 'rovenstart-footer-2',
			'description'   => esc_html__( 'The widgets added here will appear in the second column of the Footer', 'rovenstart' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => $before_title,
			'after_title'   => $after_title,
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Colum 3', 'rovenstart' ),
			'id'            => 'rovenstart-footer-3',
			'description'   => esc_html__( 'The widgets added here will appear in the third column of the Footer', 'rovenstart' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => $before_title,
			'after_title'   => $after_title,
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Bottom Colum 1', 'rovenstart' ),
			'id'            => 'rovenstart-footer-bottom1',
			'description'   => esc_html__( 'The widgets added here will appear in the first column of the Bottom Footer', 'rovenstart' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => $before_title,
			'after_title'   => $after_title,
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Bottom Colum 2', 'rovenstart' ),
			'id'            => 'rovenstart-footer-bottom2',
			'description'   => esc_html__( 'The widgets added here will appear in the second column of the Bottom Footer', 'rovenstart' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => $before_title,
			'after_title'   => $after_title,
		)
	);

	register_sidebar(
		array(
			'name'          => esc_html__( 'Footer Bottom Colum 3', 'rovenstart' ),
			'id'            => 'rovenstart-footer-bottom3',
			'description'   => esc_html__( 'The widgets added here will appear in the third column of the Bottom Footer', 'rovenstart' ),
			'before_widget' => '<div id="%1$s" class="widget %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => $before_title,
			'after_title'   => $after_title,
		)
	);

}

add_action( 'widgets_init', 'rovenstart_widgets_init' );

if ( is_customize_preview() ) {

	/**
	 * This function is used to help switch the widget tile styling in siderbar based on Customizer options.
	 *
	 * @param object $params - sidebar parameters.
	 */
	function rovenstart_widget_params( $params ) {

		$before_title = '<h5 class="widget-title">';
		$after_title  = '</h5>';
		$title_style  = get_theme_mod( 'rovenstart_widget_title_style', 'none' );

		// Modify Widget title structure based on the widget styling option.
		if ( 'style-1' === $title_style ) {
			$before_title = '<h5 class="widget-title widget-title-style-1">';
		} elseif ( 'style-2' === $title_style ) {
			$before_title = '<h5 class="widget-title widget-title-style-2">';
		} elseif ( 'style-3' === $title_style ) {
			$before_title = '<h5 class="widget-title widget-title-style-3">';
		} elseif ( 'style-4' === $title_style ) {
			$before_title = '<h5 class="widget-title widget-title-style-4">';
		} elseif ( 'style-5' === $title_style ) {
			$before_title = '<h5 class="widget-title widget-title-style-5">';
		} elseif ( 'style-6' === $title_style ) {
			$before_title = '<h5 class="widget-title widget-title-style-6">';
			$after_title  = '<svg width="33" height="6" xmlns="https://www.w3.org/2000/svg">
			<path d="M0,4c1.505,0,2.195-0.809,3.069-1.832C3.936,1.152,4.919,0,6.743,0c1.899,0,3.008,1.29,3.898,2.326
			C11.534,3.364,12.131,4,13.128,4c1.505,0,2.195-0.809,3.069-1.832C17.064,1.152,18.047,0,19.871,0c1.9,0,3.009,1.29,3.899,2.326
			C24.662,3.364,25.26,4,26.257,4c1.506,0,2.195-0.809,3.069-1.832C30.193,1.152,31.177,0,33,0v3.528
			c-0.859,0-1.354,0.327-2.152,0.906C29.884,5.131,28.685,6,26.257,6c-1.966,0-3.096-0.812-4.003-1.465
			c-0.869-0.624-1.448-1.007-2.383-1.007c-0.859,0-1.354,0.327-2.152,0.906C16.755,5.131,15.556,6,13.128,6
			c-1.966,0-3.096-0.812-4.004-1.465C8.256,3.91,7.677,3.528,6.743,3.528c-0.859,0-1.354,0.327-2.152,0.906C3.626,5.131,2.428,6,0,6V4
			z"/></svg></h5>';
		} elseif ( 'style-7' === $title_style ) {
			$before_title = '<h5 class="widget-title widget-title-style-7"><span>';
			$after_title  = '</span></h5>';
		} elseif ( 'style-8' === $title_style ) {
			$before_title = '<h5 class="widget-title widget-title-style-8"><span>';
			$after_title  = '</span></h5>';
		} elseif ( 'style-9' === $title_style ) {
			$before_title = '<h5 class="widget-title widget-title-style-9">';
		} elseif ( 'style-10' === $title_style ) {
			$before_title = '<h5 class="widget-title widget-title-style-10"><span>';
			$after_title  = '</span></h5>';
		}

		$params[0]['before_title'] = $before_title;
		$params[0]['after_title']  = $after_title;

		return $params;
	}

	add_filter( 'dynamic_sidebar_params', 'rovenstart_widget_params' );
}

/**
 * Register and load theme specific widgets.
 */
function rovenstart_load_widgets() {
	register_widget( 'RS_Widget_Archives' );
	register_widget( 'RS_Widget_Categories' );
	register_widget( 'RS_Widget_Social_Networks' );
	register_widget( 'RS_Widget_Social_Networks_List_Alt' );
	register_widget( 'RS_Widget_Posts' );
	register_widget( 'RS_Widget_Tag_Cloud' );
}

add_action( 'widgets_init', 'rovenstart_load_widgets' );
