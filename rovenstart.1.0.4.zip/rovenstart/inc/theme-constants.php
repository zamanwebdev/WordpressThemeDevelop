<?php
/**
 * Various theme specific constants are defined here.
 *
 * @package rovenstart
 */

if ( ! defined( '_ROVENSTART_VERSION' ) ) {
	define( '_ROVENSTART_VERSION', '1.0.4' );
}

if ( ! defined( 'ROVENSTART_DATA' ) ) {
	define( 'ROVENSTART_DATA', false );
}

if ( ! defined( 'ROVENSTART_NAME' ) ) {
	define( 'ROVENSTART_NAME', 'Rovenstart' );
}
