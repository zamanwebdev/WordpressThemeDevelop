<?php
/**
 * The template for displaying Footer Customizer Settings
 *
 * @package Rovenstart
 */

// Footer settings section.
new \Kirki\Section(
	'rovenstart_footer',
	array(
		'title'    => ROVENSTART_NAME . ': ' . esc_html__( 'Footer', 'rovenstart' ),
		'priority' => 155,
	)
);
// Show footer option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_show_footer',
		'label'    => esc_html__( 'Show footer', 'rovenstart' ),
		'section'  => 'rovenstart_footer',
		'default'  => '1',
	)
);
// Stretch footer fullwidth option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'toggle',
		'settings'        => 'rovenstart_footer_fullwidth',
		'label'           => esc_html__( 'Stretch footer fullwidth', 'rovenstart' ),
		'section'         => 'rovenstart_footer',
		'default'         => '1',
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_show_footer',
				'operator' => '===',
				'value'    => true,
			),
		),
	)
);
// Footer layout option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'select',
		'settings'        => 'rovenstart_footer_cols',
		'label'           => esc_html__( 'Footer layout', 'rovenstart' ),
		'section'         => 'rovenstart_footer',
		'default'         => 'cols-1',
		'choices'         => array(
			'cols-1' => esc_html__( '1 Column', 'rovenstart' ),
			'cols-2' => esc_html__( '2 Columns', 'rovenstart' ),
			'cols-3' => esc_html__( '3 Columns', 'rovenstart' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_show_footer',
				'operator' => '===',
				'value'    => true,
			),
		),
	)
);
// Show footer bottom option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_show_footer_bottom',
		'label'    => esc_html__( 'Show footer bottom', 'rovenstart' ),
		'section'  => 'rovenstart_footer',
		'default'  => '1',
	)
);
// Stretch footer bottom fullwidth option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'toggle',
		'settings'        => 'rovenstart_footer_bottom_fullwidth',
		'label'           => esc_html__( 'Stretch footer bottom fullwidth', 'rovenstart' ),
		'section'         => 'rovenstart_footer',
		'default'         => '0',
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_show_footer_bottom',
				'operator' => '===',
				'value'    => true,
			),
		),
	)
);
// Add border top to footer bottom option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'toggle',
		'settings'        => 'rovenstart_footer_bottom_border',
		'label'           => esc_html__( 'Add border top to footer bottom', 'rovenstart' ),
		'section'         => 'rovenstart_footer',
		'default'         => '0',
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_show_footer_bottom',
				'operator' => '===',
				'value'    => true,
			),
		),
	)
);
// Footer bottom layout option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'select',
		'settings'        => 'rovenstart_footer_bottom_cols',
		'label'           => esc_html__( 'Footer bottom layout', 'rovenstart' ),
		'section'         => 'rovenstart_footer',
		'default'         => 'cols-2',
		'choices'         => array(
			'cols-1' => esc_html__( '1 Column', 'rovenstart' ),
			'cols-2' => esc_html__( '2 Columns', 'rovenstart' ),
			'cols-3' => esc_html__( '3 Columns', 'rovenstart' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_show_footer_bottom',
				'operator' => '===',
				'value'    => true,
			),
		),
	)
);
