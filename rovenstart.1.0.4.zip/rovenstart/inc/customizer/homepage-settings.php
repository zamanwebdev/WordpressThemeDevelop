<?php
/**
 * The template for displaying theme Homepage Customizer Settings
 *
 * @package Rovenstart
 */

// Homepage Settings section.
new \Kirki\Section(
	'rovenstart_home_settings',
	array(
		'title'    => ROVENSTART_NAME . ': ' . esc_html__( 'Homepage Settings', 'rovenstart' ),
		'priority' => 157,
	)
);
$layout_args = array(
	'hero'     => esc_html__( 'Header Hero Posts', 'rovenstart' ),
	'featured' => esc_html__( 'Featured Posts', 'rovenstart' ),
	'main'     => esc_html__( 'Recent Posts', 'rovenstart' ),
);
// Home page layout option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'        => 'sortable',
		'settings'    => 'rovenstart_home_layout',
		'label'       => esc_html__( 'Home Page Layout', 'rovenstart' ),
		'description' => esc_html__( 'You can use this option to rearrange or disable Home Page sections.', 'rovenstart' ),
		'section'     => 'rovenstart_home_settings',
		'default'     => array( 'hero', 'featured', 'main' ),
		'choices'     => $layout_args,
	)
);
// Display Sidebar option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_home_show_sidebar',
		'label'    => esc_html__( 'Display Sidebar', 'rovenstart' ),
		'section'  => 'rovenstart_home_settings',
		'default'  => '1',
	)
);
// Homepage Header Hero section.
new \Kirki\Section(
	'rovenstart_home_header_hero',
	array(
		'title'    => ROVENSTART_NAME . ': ' . esc_html__( 'Homepage Header Hero', 'rovenstart' ),
		'priority' => 158,
	)
);
// Content to display option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'        => 'select',
		'settings'    => 'rovenstart_home_header_hero_content',
		'label'       => esc_html__( 'Content to display', 'rovenstart' ),
		'description' => esc_html__( 'Note: the Popular Posts selection requires Post Views Counting to be enabled in Advanced Settings section.', 'rovenstart' ),
		'section'     => 'rovenstart_home_header_hero',
		'default'     => 'recent-posts',
		'choices'     => array(
			'recent-posts'   => esc_html__( 'Recent Posts', 'rovenstart' ),
			'popular-posts'  => esc_html__( 'Popular Posts', 'rovenstart' ),
			'specific-posts' => esc_html__( 'Specific Posts', 'rovenstart' ),
			'category-posts' => esc_html__( 'Specific Category Posts', 'rovenstart' ),
			'tag-posts'      => esc_html__( 'Specific Tag Posts', 'rovenstart' ),
		),
	)
);
// Post category option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'select',
		'settings'        => 'rovenstart_home_header_hero_post_categ',
		'label'           => esc_html__( 'Post category', 'rovenstart' ),
		'description'     => esc_html__( 'Posts from the selected category will be shown in the header section', 'rovenstart' ),
		'section'         => 'rovenstart_home_header_hero',
		'placeholder'     => esc_html__( 'Select an option...', 'rovenstart' ),
		'choices'         => rovenstart_categories_list(),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_home_header_hero_content',
				'operator' => '===',
				'value'    => 'category-posts',
			),
		),
	)
);
// Post tag option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'select',
		'settings'        => 'rovenstart_home_header_hero_post_tag',
		'label'           => esc_html__( 'Post tag', 'rovenstart' ),
		'description'     => esc_html__( 'Posts with the selected tag will be shown in the header section', 'rovenstart' ),
		'section'         => 'rovenstart_home_header_hero',
		'placeholder'     => esc_html__( 'Select an option...', 'rovenstart' ),
		'choices'         => rovenstart_tags_list(),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_home_header_hero_content',
				'operator' => '===',
				'value'    => 'tag-posts',
			),
		),
	)
);
// Specific posts option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'select',
		'settings'        => 'rovenstart_home_header_hero_post_specific',
		'label'           => esc_html__( 'Specific Posts', 'rovenstart' ),
		'description'     => esc_html__( 'The posts selected here will be shown in the header section', 'rovenstart' ),
		'section'         => 'rovenstart_home_header_hero',
		'placeholder'     => esc_html__( 'Multiple posts can be selected', 'rovenstart' ),
		'multiple'        => 12,
		'choices'         => rovenstart_posts_list(),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_home_header_hero_content',
				'operator' => '===',
				'value'    => 'specific-posts',
			),
		),
	)
);
// Exclude posts from sections placed above Header Hero Posts option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'toggle',
		'settings'        => 'rovenstart_home_header_hero_exclude',
		'label'           => esc_html__( 'Exclude posts from sections placed above Header Hero Posts', 'rovenstart' ),
		'section'         => 'rovenstart_home_header_hero',
		'default'         => '1',
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_home_header_hero_content',
				'operator' => '!==',
				'value'    => 'specific-posts',
			),
		),
	)
);
// Total number of posts to show option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'slider',
		'settings'        => 'rovenstart_home_header_hero_posts_nr',
		'label'           => esc_html__( 'Total number of posts to show', 'rovenstart' ),
		'section'         => 'rovenstart_home_header_hero',
		'default'         => 3,
		'choices'         => array(
			'min'  => 1,
			'max'  => 12,
			'step' => 1,
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_home_header_hero_content',
				'operator' => '!==',
				'value'    => 'specific-posts',
			),
		),
	)
);
// Number of posts to show per slide option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'slider',
		'settings'        => 'rovenstart_home_header_hero_slide_nr',
		'label'           => esc_html__( 'Number of posts per slide to show', 'rovenstart' ),
		'section'         => 'rovenstart_home_header_hero',
		'default'         => 1,
		'choices'         => array(
			'min'  => 1,
			'max'  => 4,
			'step' => 1,
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_home_header_hero_type',
				'operator' => '===',
				'value'    => 'slider',
			),
		),
	)
);
// Image Aspect Ratio option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'select',
		'settings' => 'rovenstart_home_header_hero_aspect',
		'label'    => esc_html__( 'Image Aspect Ratio', 'rovenstart' ),
		'section'  => 'rovenstart_home_header_hero',
		'default'  => 'hero',
		'choices'  => array(
			'hero'      => esc_html__( 'Hero', 'rovenstart' ),
			'landscape' => esc_html__( 'Landscape', 'rovenstart' ),
			'portrait'  => esc_html__( 'Portrait', 'rovenstart' ),
			'square'    => esc_html__( 'Square', 'rovenstart' ),
		),
	)
);
// Homepage Featured Posts section.
new \Kirki\Section(
	'rovenstart_home_featured_posts',
	array(
		'title'    => ROVENSTART_NAME . ': ' . esc_html__( 'Homepage Featured Posts', 'rovenstart' ),
		'priority' => 159,
	)
);
// Section Title option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'        => 'text',
		'settings'    => 'rovenstart_home_featured_title',
		'label'       => esc_html__( 'Section Title', 'rovenstart' ),
		'description' => esc_html__( 'Leave empty if you do not want the section to have a title', 'rovenstart' ),
		'section'     => 'rovenstart_home_featured_posts',
		'default'     => esc_html__( 'Featured posts', 'rovenstart' ),
	)
);
// Content to display option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'        => 'select',
		'settings'    => 'rovenstart_home_featured_content',
		'label'       => esc_html__( 'Content to display', 'rovenstart' ),
		'description' => esc_html__( 'Note: the Popular Posts selection requires Post Views Counting to be enabled in Advanced Settings section.', 'rovenstart' ),
		'section'     => 'rovenstart_home_featured_posts',
		'default'     => 'recent-posts',
		'choices'     => array(
			'recent-posts'   => esc_html__( 'Recent Posts', 'rovenstart' ),
			'popular-posts'  => esc_html__( 'Popular Posts', 'rovenstart' ),
			'specific-posts' => esc_html__( 'Specific Posts', 'rovenstart' ),
			'category-posts' => esc_html__( 'Specific Category Posts', 'rovenstart' ),
			'tag-posts'      => esc_html__( 'Specific Tag Posts', 'rovenstart' ),
		),
	)
);
// Post category option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'select',
		'settings'        => 'rovenstart_home_featured_post_categ',
		'label'           => esc_html__( 'Post category', 'rovenstart' ),
		'description'     => esc_html__( 'Posts from the selected category will be shown in the featured section', 'rovenstart' ),
		'section'         => 'rovenstart_home_featured_posts',
		'placeholder'     => esc_html__( 'Select an option...', 'rovenstart' ),
		'choices'         => rovenstart_categories_list(),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_home_featured_content',
				'operator' => '===',
				'value'    => 'category-posts',
			),
		),
	)
);
// Post tag option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'select',
		'settings'        => 'rovenstart_home_featured_post_tag',
		'label'           => esc_html__( 'Post tag', 'rovenstart' ),
		'description'     => esc_html__( 'Posts with the selected tag will be shown in the featured section', 'rovenstart' ),
		'section'         => 'rovenstart_home_featured_posts',
		'placeholder'     => esc_html__( 'Select an option...', 'rovenstart' ),
		'choices'         => rovenstart_tags_list(),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_home_featured_content',
				'operator' => '===',
				'value'    => 'tag-posts',
			),
		),
	)
);
// Specific posts option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'select',
		'settings'        => 'rovenstart_home_featured_post_specific',
		'label'           => esc_html__( 'Specific Posts', 'rovenstart' ),
		'description'     => esc_html__( 'The posts selected here will be shown in the featured section', 'rovenstart' ),
		'section'         => 'rovenstart_home_featured_posts',
		'placeholder'     => esc_html__( 'Multiple posts can be selected', 'rovenstart' ),
		'multiple'        => 12,
		'choices'         => rovenstart_posts_list(),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_home_featured_content',
				'operator' => '===',
				'value'    => 'specific-posts',
			),
		),
	)
);
// Exclude posts from sections placed above Featured Posts option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'toggle',
		'settings'        => 'rovenstart_home_featured_posts_exclude',
		'label'           => esc_html__( 'Exclude posts from sections placed above Featured Posts', 'rovenstart' ),
		'section'         => 'rovenstart_home_featured_posts',
		'default'         => '1',
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_home_featured_content',
				'operator' => '!==',
				'value'    => 'specific-posts',
			),
		),
	)
);
// Total number of posts option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'slider',
		'settings'        => 'rovenstart_home_featured_nr',
		'label'           => esc_html__( 'Total number of posts to show', 'rovenstart' ),
		'section'         => 'rovenstart_home_featured_posts',
		'default'         => 3,
		'choices'         => array(
			'min'  => 1,
			'max'  => 12,
			'step' => 1,
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_home_featured_content',
				'operator' => '!==',
				'value'    => 'specific-posts',
			),
		),
	)
);
// Number of grid columns option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'slider',
		'settings' => 'rovenstart_home_featured_cols',
		'label'    => esc_html__( 'Number of grid columns', 'rovenstart' ),
		'section'  => 'rovenstart_home_featured_posts',
		'default'  => 3,
		'choices'  => array(
			'min'  => 1,
			'max'  => 3,
			'step' => 1,
		),
	)
);
// Image Aspect Ratio option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'select',
		'settings' => 'rovenstart_home_featured_aspect',
		'label'    => esc_html__( 'Image Aspect Ratio', 'rovenstart' ),
		'section'  => 'rovenstart_home_featured_posts',
		'default'  => 'landscape',
		'choices'  => array(
			'hero'      => esc_html__( 'Hero', 'rovenstart' ),
			'landscape' => esc_html__( 'Landscape', 'rovenstart' ),
			'portrait'  => esc_html__( 'Portrait', 'rovenstart' ),
			'square'    => esc_html__( 'Square', 'rovenstart' ),
		),
	)
);
// Show author in post meta option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_home_featured_author',
		'label'    => esc_html__( 'Show author in post meta', 'rovenstart' ),
		'section'  => 'rovenstart_home_featured_posts',
		'default'  => '1',
	)
);
// Show category in post meta option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_home_featured_category',
		'label'    => esc_html__( 'Show category in post meta', 'rovenstart' ),
		'section'  => 'rovenstart_home_featured_posts',
		'default'  => '1',
	)
);
// Show date in post meta option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_home_featured_date',
		'label'    => esc_html__( 'Show date in post meta', 'rovenstart' ),
		'section'  => 'rovenstart_home_featured_posts',
		'default'  => '1',
	)
);
// Show number of comments in post meta option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_home_featured_comments',
		'label'    => esc_html__( 'Show number of comments in post meta', 'rovenstart' ),
		'section'  => 'rovenstart_home_featured_posts',
		'default'  => '0',
	)
);
// Show post excerpt option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_home_featured_excerpt',
		'label'    => esc_html__( 'Show post excerpt', 'rovenstart' ),
		'section'  => 'rovenstart_home_featured_posts',
		'default'  => '0',
	)
);
// Homepage Recent Posts section.
new \Kirki\Section(
	'rovenstart_home_recent_posts',
	array(
		'title'    => ROVENSTART_NAME . ': ' . esc_html__( 'Homepage Recent Posts', 'rovenstart' ),
		'priority' => 160,
	)
);
// Section Title option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'        => 'text',
		'settings'    => 'rovenstart_home_recent_posts_title',
		'label'       => esc_html__( 'Section Title', 'rovenstart' ),
		'description' => esc_html__( 'Leave empty if you do not want the section to have a title', 'rovenstart' ),
		'section'     => 'rovenstart_home_recent_posts',
		'default'     => esc_html__( 'Latest posts', 'rovenstart' ),
	)
);
// Exclude posts from sections placed above Latest Posts option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_home_recent_posts_exclude',
		'label'    => esc_html__( 'Exclude posts from sections placed above Latest Posts', 'rovenstart' ),
		'section'  => 'rovenstart_home_recent_posts',
		'default'  => '1',
	)
);
// Total number of posts option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'slider',
		'settings' => 'rovenstart_home_recent_posts_nr',
		'label'    => esc_html__( 'Total number of posts to show', 'rovenstart' ),
		'section'  => 'rovenstart_home_recent_posts',
		'default'  => 6,
		'choices'  => array(
			'min'  => 1,
			'max'  => 90,
			'step' => 1,
		),
	)
);
// Number of grid columns option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'        => 'slider',
		'settings'    => 'rovenstart_home_recent_posts_grid_cols',
		'label'       => esc_html__( 'Number of grid columns', 'rovenstart' ),
		'description' => esc_html__( 'If you enable the sidebar, a maximum of 2 columns is recommended', 'rovenstart' ),
		'section'     => 'rovenstart_home_recent_posts',
		'default'     => 2,
		'choices'     => array(
			'min'  => 1,
			'max'  => 3,
			'step' => 1,
		),
	)
);
// Image Aspect Ratio option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'select',
		'settings'        => 'rovenstart_home_recent_posts_aspect',
		'label'           => esc_html__( 'Image Aspect Ratio', 'rovenstart' ),
		'section'         => 'rovenstart_home_recent_posts',
		'default'         => 'hero',
		'choices'         => array(
			'hero'      => esc_html__( 'Hero', 'rovenstart' ),
			'landscape' => esc_html__( 'Landscape', 'rovenstart' ),
			'portrait'  => esc_html__( 'Portrait', 'rovenstart' ),
			'square'    => esc_html__( 'Square', 'rovenstart' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_home_recent_posts_grid',
				'operator' => '===',
				'value'    => 'grid',
			),
		),
	)
);
// Show author in post meta option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_home_recent_posts_author',
		'label'    => esc_html__( 'Show author in post meta', 'rovenstart' ),
		'section'  => 'rovenstart_home_recent_posts',
		'default'  => '1',
	)
);
// Show category in post meta option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_home_recent_posts_category',
		'label'    => esc_html__( 'Show category in post meta', 'rovenstart' ),
		'section'  => 'rovenstart_home_recent_posts',
		'default'  => '1',
	)
);
// Show date in post meta option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_home_recent_posts_date',
		'label'    => esc_html__( 'Show date in post meta', 'rovenstart' ),
		'section'  => 'rovenstart_home_recent_posts',
		'default'  => '1',
	)
);
// Show number of comments in post meta option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_home_recent_posts_comments',
		'label'    => esc_html__( 'Show number of comments in post meta', 'rovenstart' ),
		'section'  => 'rovenstart_home_recent_posts',
		'default'  => '1',
	)
);
// Show post excerpt option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_home_recent_posts_excerpt',
		'label'    => esc_html__( 'Show post excerpt', 'rovenstart' ),
		'section'  => 'rovenstart_home_recent_posts',
		'default'  => '1',
	)
);
