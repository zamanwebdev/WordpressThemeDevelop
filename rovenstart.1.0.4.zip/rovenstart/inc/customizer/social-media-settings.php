<?php
/**
 * The template for displaying CTA Customizer Settings
 *
 * @package Rovenstart
 */

// Social Media section.
new \Kirki\Section(
	'rovenstart_social_media',
	array(
		'title'    => ROVENSTART_NAME . ': ' . esc_html__( 'Social Media', 'rovenstart' ),
		'priority' => 165,
	)
);
// Social Media Widgets Layout option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'        => 'sortable',
		'settings'    => 'rovenstart_social_widgets_layout',
		'label'       => esc_html__( 'Social Media Widgets Layout', 'rovenstart' ),
		'description' => esc_html__( 'You can use this option to rearrange or disable Social Media Widgets elements.', 'rovenstart' ),
		'section'     => 'rovenstart_social_media',
		'default'     => array(
			'facebook',
			'instagram',
			'twitter',
			'linkedin',
			'youtube',
			'tumblr',
			'pinterest',
			'dribbble',
			'medium',
			'500px',
			'xing',
			'vimeo',
			'vk',
			'github',
			'flickr',
			'bitbucket',
			'reddit',
			'steam',
			'twitch',
		),
		'choices'     => array(
			'facebook'  => esc_html__( 'facebook', 'rovenstart' ),
			'instagram' => esc_html__( 'instagram', 'rovenstart' ),
			'twitter'   => esc_html__( 'twitter', 'rovenstart' ),
			'linkedin'  => esc_html__( 'linkedin', 'rovenstart' ),
			'youtube'   => esc_html__( 'youtube', 'rovenstart' ),
			'tumblr'    => esc_html__( 'tumblr', 'rovenstart' ),
			'pinterest' => esc_html__( 'pinterest', 'rovenstart' ),
			'dribbble'  => esc_html__( 'dribbble', 'rovenstart' ),
			'medium'    => esc_html__( 'medium', 'rovenstart' ),
			'500px'     => esc_html__( '500px', 'rovenstart' ),
			'xing'      => esc_html__( 'xing', 'rovenstart' ),
			'vimeo'     => esc_html__( 'vimeo', 'rovenstart' ),
			'vk'        => esc_html__( 'vk', 'rovenstart' ),
			'github'    => esc_html__( 'github', 'rovenstart' ),
			'flickr'    => esc_html__( 'flickr', 'rovenstart' ),
			'bitbucket' => esc_html__( 'bitbucket', 'rovenstart' ),
			'reddit'    => esc_html__( 'reddit', 'rovenstart' ),
			'steam'     => esc_html__( 'steam', 'rovenstart' ),
			'twitch'    => esc_html__( 'twitch', 'rovenstart' ),
		),
	)
);
