<?php
/**
 * The template for displaying theme General Customizer Settings
 *
 * @package Rovenstart
 */

// Color Settings section.
new \Kirki\Section(
	'rovenstart_color_settings',
	array(
		'title'    => ROVENSTART_NAME . ': ' . esc_html__( 'General Color Settings', 'rovenstart' ),
		'priority' => 152,
	)
);
// Accent Color 1 option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'color',
		'settings' => 'rovenstart_accent_color_1',
		'label'    => esc_html__( 'Accent Color 1', 'rovenstart' ),
		'section'  => 'rovenstart_color_settings',
		'default'  => '#2E2D4D',
	)
);
// Accent Color 2 option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'color',
		'settings' => 'rovenstart_accent_color_2',
		'label'    => esc_html__( 'Accent Color 2', 'rovenstart' ),
		'section'  => 'rovenstart_color_settings',
		'default'  => '#D50747',
	)
);
// Link color option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'color',
		'settings' => 'rovenstart_link_color',
		'label'    => esc_html__( 'Link Color', 'rovenstart' ),
		'section'  => 'rovenstart_color_settings',
		'default'  => '#2E2D4D',
	)
);
// Link Color Hover option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'color',
		'settings' => 'rovenstart_link_color_hover',
		'label'    => esc_html__( 'Link Color Hover', 'rovenstart' ),
		'section'  => 'rovenstart_color_settings',
		'default'  => '#D50747',
	)
);
// Link Color Active option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'color',
		'settings' => 'rovenstart_link_color_active',
		'label'    => esc_html__( 'Link Color Active', 'rovenstart' ),
		'section'  => 'rovenstart_color_settings',
		'default'  => '#D50747',
	)
);
// Dark Mode: Accent Color 1 option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'color',
		'settings' => 'rovenstart_darkmode_accent_color_1',
		'label'    => esc_html__( 'Dark Mode: Accent Color 1', 'rovenstart' ),
		'section'  => 'rovenstart_color_settings',
		'default'  => '#2E2D4D',
	)
);
// Dark Mode: Accent Color 2 option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'color',
		'settings' => 'rovenstart_darkmode_accent_color_2',
		'label'    => esc_html__( 'Dark Mode: Accent Color 2', 'rovenstart' ),
		'section'  => 'rovenstart_color_settings',
		'default'  => '#D50747',
	)
);
// Dark Mode: Link color option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'color',
		'settings' => 'rovenstart_darkmode_link_color',
		'label'    => esc_html__( 'Dark Mode: Link Color', 'rovenstart' ),
		'section'  => 'rovenstart_color_settings',
		'default'  => '#ffffff',
	)
);
// Dark Mode: Link Color Hover option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'color',
		'settings' => 'rovenstart_darkmode_link_color_hover',
		'label'    => esc_html__( 'Dark Mode: Link Color Hover', 'rovenstart' ),
		'section'  => 'rovenstart_color_settings',
		'default'  => '#f8f8f8',
	)
);
// Dark Mode: Link Color Active option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'color',
		'settings' => 'rovenstart_darkmode_link_color_active',
		'label'    => esc_html__( 'Dark Mode: Link Color Active', 'rovenstart' ),
		'section'  => 'rovenstart_color_settings',
		'default'  => '#f8f8f8',
	)
);
// Fonts Settings section.
new \Kirki\Section(
	'rovenstart_font_settings',
	array(
		'title'    => ROVENSTART_NAME . ': ' . esc_html__( 'General Fonts Settings', 'rovenstart' ),
		'priority' => 153,
	)
);
// Font Base size option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'        => 'text',
		'settings'    => 'rovenstart_font_base_size',
		'label'       => esc_html__( 'Font base size', 'rovenstart' ),
		'description' => esc_html__( 'The size of body / paragraph text (px).', 'rovenstart' ),
		'section'     => 'rovenstart_font_settings',
		'default'     => '17px',
	)
);
// Font scale (mobile) option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'        => 'select',
		'settings'    => 'rovenstart_font_scale_mobile',
		'label'       => esc_html__( 'Font Scale (mobile)', 'rovenstart' ),
		'description' => esc_html__( 'Heading font sizes are calculated automatically based on the Font Base Size and this scaling value.', 'rovenstart' ),
		'section'     => 'rovenstart_font_settings',
		'default'     => '1.067',
		'choices'     => array(
			'1.067' => '1.067',
			'1.100' => '1.100',
			'1.125' => '1.125',
		),
	)
);
// Font scale option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'        => 'select',
		'settings'    => 'rovenstart_font_scale',
		'label'       => esc_html__( 'Font Scale', 'rovenstart' ),
		'description' => esc_html__( 'Heading font sizes are calculated automatically based on the Font Base Size and this scaling value.', 'rovenstart' ),
		'section'     => 'rovenstart_font_settings',
		'default'     => '1.125',
		'choices'     => array(
			'1.125' => '1.125',
			'1.150' => '1.150',
			'1.175' => '1.175',
			'1.200' => '1.200',
			'1.225' => '1.225',
			'1.250' => '1.250',
		),
	)
);
