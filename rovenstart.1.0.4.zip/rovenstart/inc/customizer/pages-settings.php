<?php
/**
 * The template for displaying Pages Customizer Settings
 *
 * @package Rovenstart
 */

// Page Settings section.
new \Kirki\Section(
	'rovenstart_page_settings',
	array(
		'title'    => ROVENSTART_NAME . ': ' . esc_html__( 'Page Settings', 'rovenstart' ),
		'priority' => 156,
	)
);
// Display page header option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_show_page_header',
		'label'    => esc_html__( 'Display page header', 'rovenstart' ),
		'section'  => 'rovenstart_page_settings',
		'default'  => '1',
	)
);
// Page header style option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'select',
		'settings'        => 'rovenstart_page_header_style',
		'label'           => esc_html__( 'Page header style', 'rovenstart' ),
		'section'         => 'rovenstart_page_settings',
		'default'         => 'style1',
		'choices'         => array(
			'style1' => esc_html__( 'Style 1', 'rovenstart' ),
			'style2' => esc_html__( 'Style 2', 'rovenstart' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_show_page_header',
				'operator' => '===',
				'value'    => true,
			),
		),
	)
);
// Featured Image Aspect Ratio option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'select',
		'settings'        => 'rovenstart_page_featured_aspect',
		'label'           => esc_html__( 'Featured Image Aspect Ratio', 'rovenstart' ),
		'section'         => 'rovenstart_page_settings',
		'default'         => 'hero',
		'choices'         => array(
			'hero'      => esc_html__( 'Hero', 'rovenstart' ),
			'landscape' => esc_html__( 'Landscape', 'rovenstart' ),
			'portrait'  => esc_html__( 'Portrait', 'rovenstart' ),
			'square'    => esc_html__( 'Square', 'rovenstart' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_show_page_header',
				'operator' => '===',
				'value'    => true,
			),
		),
	)
);
