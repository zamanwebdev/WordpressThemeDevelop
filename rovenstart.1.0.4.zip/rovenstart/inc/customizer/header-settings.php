<?php
/**
 * The template for displaying theme Header Customizer Settings
 *
 * @package Rovenstart
 */

// Header Settings section.
new \Kirki\Section(
	'rovenstart_header',
	array(
		'title'    => ROVENSTART_NAME . ': ' . esc_html__( 'Header', 'rovenstart' ),
		'priority' => 154,
	)
);
// Header Layout option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'select',
		'settings' => 'rovenstart_header_layout',
		'label'    => esc_html__( 'Header Layout', 'rovenstart' ),
		'section'  => 'rovenstart_header',
		'default'  => 'logo-top-menu-below',
		'choices'  => array(
			'logo-top-menu-below'    => esc_html__( 'Logo top, menu below', 'rovenstart' ),
			'logo-top-menu-right'    => esc_html__( 'Logo left, menu right', 'rovenstart' ),
			'logo-center-menu-split' => esc_html__( 'Logo center, menu split', 'rovenstart' ),
		),
	)
);
// Sticky header on mobile option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_sticky_header_on_mobile',
		'label'    => esc_html__( 'Sticky header on mobile', 'rovenstart' ),
		'section'  => 'rovenstart_header',
		'default'  => '1',
	)
);
// Sticky header on desktop option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_sticky_header_on_desktop',
		'label'    => esc_html__( 'Sticky header on desktop', 'rovenstart' ),
		'section'  => 'rovenstart_header',
		'default'  => '1',
	)
);
// Display search box option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_show_search_box',
		'label'    => esc_html__( 'Display search box', 'rovenstart' ),
		'section'  => 'rovenstart_header',
		'default'  => '1',
	)
);
// Display dark mode toggler option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_show_darkmode_toggler',
		'label'    => esc_html__( 'Display dark mode toggler', 'rovenstart' ),
		'section'  => 'rovenstart_header',
		'default'  => '1',
	)
);
// Display Mobile Menu Sidebar option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_mobile_show_sidebar',
		'label'    => esc_html__( 'Display Mobile Menu Sidebar', 'rovenstart' ),
		'section'  => 'rovenstart_header',
		'default'  => '1',
	)
);
// Logo source (to use) option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'select',
		'settings' => 'rovenstart_logo_source',
		'label'    => esc_html__( 'What logo to display?', 'rovenstart' ),
		'section'  => 'rovenstart_header',
		'default'  => 'text-logo',
		'choices'  => array(
			'text-logo'  => esc_html__( 'Text Logo', 'rovenstart' ),
			'image-logo' => esc_html__( 'Image Logo', 'rovenstart' ),
		),
	)
);
// Text logo option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'text',
		'settings'        => 'rovenstart_text_logo',
		'label'           => esc_html__( 'Text Logo', 'rovenstart' ),
		'section'         => 'rovenstart_header',
		'default'         => 'rovenstart',
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_logo_source',
				'operator' => '===',
				'value'    => 'text-logo',
			),
		),
	)
);
// Image logo option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'image',
		'settings'        => 'rovenstart_logo_id',
		'label'           => esc_html__( 'Image logo', 'rovenstart' ),
		'section'         => 'rovenstart_header',
		'default'         => '',
		'choices'         => array(
			'save_as' => 'id',
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_logo_source',
				'operator' => '===',
				'value'    => 'image-logo',
			),
		),
	)
);
// Image Logo Retina option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'image',
		'settings'        => 'rovenstart_logo_retina_id',
		'label'           => esc_html__( 'Image Logo Retina', 'rovenstart' ),
		'description'     => esc_html__( 'Use for higher pixel density displays. Make sure this logo is at exactly twice the size ( width x height ) of the default logo for optimal results.', 'rovenstart' ),
		'section'         => 'rovenstart_header',
		'default'         => '',
		'choices'         => array(
			'save_as' => 'id',
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_logo_source',
				'operator' => '===',
				'value'    => 'image-logo',
			),
		),
	)
);
// Image logo Dark mode option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'image',
		'settings'        => 'rovenstart_darkmode_logo_id',
		'label'           => esc_html__( 'Dark Mode Image logo', 'rovenstart' ),
		'section'         => 'rovenstart_header',
		'default'         => '',
		'choices'         => array(
			'save_as' => 'id',
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_logo_source',
				'operator' => '===',
				'value'    => 'image-logo',
			),
		),
	)
);
// Image logo Dark mode option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'image',
		'settings'        => 'rovenstart_darkmode_logo_retina_id',
		'label'           => esc_html__( 'Dark Mode Image Logo Retina', 'rovenstart' ),
		'description'     => esc_html__( 'Use for higher pixel density displays. Make sure this logo is at exactly twice the size ( width x height ) of the default logo for optimal results.', 'rovenstart' ),
		'section'         => 'rovenstart_header',
		'default'         => '',
		'choices'         => array(
			'save_as' => 'id',
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_logo_source',
				'operator' => '===',
				'value'    => 'image-logo',
			),
		),
	)
);
// Max Logo Image Height (mobile) option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'slider',
		'settings'        => 'rovenstart_logo_height_mobile',
		'label'           => esc_html__( 'Max Logo Image Height (mobile)', 'rovenstart' ),
		'section'         => 'rovenstart_header',
		'default'         => 60,
		'choices'         => array(
			'min'  => 15,
			'max'  => 120,
			'step' => 1,
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_logo_source',
				'operator' => '===',
				'value'    => 'image-logo',
			),
		),
	)
);
// Max Logo Image Height (tablet) option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'slider',
		'settings'        => 'rovenstart_logo_height_tablet',
		'label'           => esc_html__( 'Max Logo Image Height (tablet)', 'rovenstart' ),
		'section'         => 'rovenstart_header',
		'default'         => 70,
		'choices'         => array(
			'min'  => 15,
			'max'  => 120,
			'step' => 1,
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_logo_source',
				'operator' => '===',
				'value'    => 'image-logo',
			),
		),
	)
);
// Max Logo Image Height (desktop) option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'slider',
		'settings'        => 'rovenstart_logo_height_desktop',
		'label'           => esc_html__( 'Max Logo Image Height (desktop)', 'rovenstart' ),
		'section'         => 'rovenstart_header',
		'default'         => 90,
		'choices'         => array(
			'min'  => 15,
			'max'  => 120,
			'step' => 1,
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_logo_source',
				'operator' => '===',
				'value'    => 'image-logo',
			),
		),
	)
);
// Max Logo Image Height Sticky Menu (mobile) option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'slider',
		'settings'        => 'rovenstart_logo_sticky_height_mobile',
		'label'           => esc_html__( 'Max Logo Image Height Sticky Menu (mobile)', 'rovenstart' ),
		'section'         => 'rovenstart_header',
		'default'         => 60,
		'choices'         => array(
			'min'  => 15,
			'max'  => 120,
			'step' => 1,
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_logo_source',
				'operator' => '===',
				'value'    => 'image-logo',
			),
		),
	)
);
// Max Logo Image Height (tablet) option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'slider',
		'settings'        => 'rovenstart_logo_sticky_height_tablet',
		'label'           => esc_html__( 'Max Logo Image Height Sticky Menu (tablet)', 'rovenstart' ),
		'section'         => 'rovenstart_header',
		'default'         => 60,
		'choices'         => array(
			'min'  => 15,
			'max'  => 120,
			'step' => 1,
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_logo_source',
				'operator' => '===',
				'value'    => 'image-logo',
			),
		),
	)
);
// Max Logo Image Height (desktop) option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'slider',
		'settings'        => 'rovenstart_logo_sticky_height_desktop',
		'label'           => esc_html__( 'Max Logo Image Height Sticky Menu (desktop)', 'rovenstart' ),
		'section'         => 'rovenstart_header',
		'default'         => 45,
		'choices'         => array(
			'min'  => 15,
			'max'  => 120,
			'step' => 1,
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_logo_source',
				'operator' => '===',
				'value'    => 'image-logo',
			),
		),
	)
);
// Text logo color option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'color',
		'settings' => 'rovenstart_text_logo_color',
		'label'    => esc_html__( 'Text logo color', 'rovenstart' ),
		'section'  => 'rovenstart_header',
		'default'  => '#D50747',
	)
);
// Header Icons color option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'color',
		'settings' => 'rovenstart_header_icons_color',
		'label'    => esc_html__( 'Header Icons color', 'rovenstart' ),
		'section'  => 'rovenstart_header',
		'default'  => '#000000',
	)
);
// Header Icons Hover color option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'color',
		'settings' => 'rovenstart_header_icons_hover_color',
		'label'    => esc_html__( 'Header Icons hover color', 'rovenstart' ),
		'section'  => 'rovenstart_header',
		'default'  => '#D50747',
	)
);
// Header menu hover color option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'color',
		'settings' => 'rovenstart_header_menu_hover_color',
		'label'    => esc_html__( 'Header Menu hover color', 'rovenstart' ),
		'section'  => 'rovenstart_header',
		'default'  => '#D50747',
	)
);
// Header Menu dropdown color option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'color',
		'settings' => 'rovenstart_dropdown_menu_color',
		'label'    => esc_html__( 'Header dropdown menu color', 'rovenstart' ),
		'section'  => 'rovenstart_header',
		'default'  => '#000000',
	)
);
// Header Menu dropdown hover color option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'color',
		'settings' => 'rovenstart_dropdown_menu_hover_color',
		'label'    => esc_html__( 'Header dropdown menu hover color', 'rovenstart' ),
		'section'  => 'rovenstart_header',
		'default'  => '#D50747',
	)
);
// Dark Mode: Text logo color option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'color',
		'settings' => 'rovenstart_darkmode_text_logo_color',
		'label'    => esc_html__( 'Dark Mode: Text logo color', 'rovenstart' ),
		'section'  => 'rovenstart_header',
		'default'  => '#D50747',
	)
);
