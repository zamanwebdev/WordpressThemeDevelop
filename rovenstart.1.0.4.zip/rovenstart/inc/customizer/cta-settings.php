<?php
/**
 * The template for displaying CTA Customizer Settings
 *
 * @package Rovenstart
 */

// CTA section.
new \Kirki\Section(
	'rovenstart_cta',
	array(
		'title'    => ROVENSTART_NAME . ': ' . esc_html__( 'CTA', 'rovenstart' ),
		'priority' => 154,
	)
);
// Display CTA option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_show_cta',
		'label'    => esc_html__( 'Display CTA', 'rovenstart' ),
		'section'  => 'rovenstart_cta',
		'default'  => '1',
	)
);
// CTA Text option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'text',
		'settings'        => 'rovenstart_cta_text',
		'label'           => esc_html__( 'CTA Text', 'rovenstart' ),
		'section'         => 'rovenstart_cta',
		'default'         => esc_html__( 'CTA Text here...', 'rovenstart' ),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_show_cta',
				'operator' => '===',
				'value'    => true,
			),
		),
	)
);
// Background Color CTA option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'color',
		'settings'        => 'rovenstart_bg_color_cta',
		'label'           => esc_html__( 'Background Color CTA', 'rovenstart' ),
		'section'         => 'rovenstart_cta',
		'default'         => '#2E2D4D',
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_show_cta',
				'operator' => '===',
				'value'    => true,
			),
		),
	)
);
// Border Color CTA option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'color',
		'settings'        => 'rovenstart_border_color_cta',
		'label'           => esc_html__( 'Border Color CTA', 'rovenstart' ),
		'section'         => 'rovenstart_cta',
		'default'         => '#2E2D4D',
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_show_cta',
				'operator' => '===',
				'value'    => true,
			),
		),
	)
);
// Text color CTA option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'color',
		'settings'        => 'rovenstart_text_color_cta',
		'label'           => esc_html__( 'Text Color CTA', 'rovenstart' ),
		'section'         => 'rovenstart_cta',
		'default'         => '#ffffff',
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_show_cta',
				'operator' => '===',
				'value'    => true,
			),
		),
	)
);
// Dark Mode: Background Color CTA option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'color',
		'settings'        => 'rovenstart_darkmode_bg_color_cta',
		'label'           => esc_html__( 'Dark Mode: Background Color CTA', 'rovenstart' ),
		'section'         => 'rovenstart_cta',
		'default'         => '#6c5b7b',
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_show_cta',
				'operator' => '===',
				'value'    => true,
			),
		),
	)
);
// Dark Mode: Border Color CTA option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'color',
		'settings'        => 'rovenstart_darkmode_border_color_cta',
		'label'           => esc_html__( 'Dark Mode: Border Color CTA', 'rovenstart' ),
		'section'         => 'rovenstart_cta',
		'default'         => '#6c5b7b',
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_show_cta',
				'operator' => '===',
				'value'    => true,
			),
		),
	)
);
// Dark Mode: Text color CTA option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'color',
		'settings'        => 'rovenstart_darkmode_text_color_cta',
		'label'           => esc_html__( 'Dark Mode: Text Color CTA', 'rovenstart' ),
		'section'         => 'rovenstart_cta',
		'default'         => '#ffffff',
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_show_cta',
				'operator' => '===',
				'value'    => true,
			),
		),
	)
);
