<?php
/**
 * The template for displaying Archive / Category Page Customizer Settings
 *
 * @package Rovenstart
 */

// Archive / Category Page Settings section.
new \Kirki\Section(
	'rovenstart_archive_settings',
	array(
		'title'    => ROVENSTART_NAME . ': ' . esc_html__( 'Archive / Category Page Settings', 'rovenstart' ),
		'priority' => 161,
	)
);
// Exclude featured posts option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'toggle',
		'settings'        => 'rovenstart_archive_no_featured',
		'label'           => esc_html__( 'Exclude featured posts', 'rovenstart' ),
		'description'     => esc_html__( 'If enabled, the featured posts will be excluded from the archive posts list', 'rovenstart' ),
		'section'         => 'rovenstart_archive_settings',
		'default'         => '1',
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_archive_show_featured',
				'operator' => '===',
				'value'    => '1',
			),
		),
	)
);
// Display sidebar option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_archive_show_sidebar',
		'label'    => esc_html__( 'Display sidebar', 'rovenstart' ),
		'section'  => 'rovenstart_archive_settings',
		'default'  => '1',
	)
);
// Display Archive title option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_archive_show_title',
		'label'    => esc_html__( 'Display Archive title', 'rovenstart' ),
		'section'  => 'rovenstart_archive_settings',
		'default'  => '1',
	)
);
// Display description option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_archive_show_description',
		'label'    => esc_html__( 'Display description', 'rovenstart' ),
		'section'  => 'rovenstart_archive_settings',
		'default'  => '1',
	)
);
// Total number of posts option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'slider',
		'settings' => 'rovenstart_archive_posts_nr',
		'label'    => esc_html__( 'Total number of posts to show', 'rovenstart' ),
		'section'  => 'rovenstart_archive_settings',
		'default'  => 6,
		'choices'  => array(
			'min'  => 1,
			'max'  => 90,
			'step' => 1,
		),
	)
);
// Number of grid columns option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'        => 'slider',
		'settings'    => 'rovenstart_archive_grid_columns',
		'label'       => esc_html__( 'Number of grid columns', 'rovenstart' ),
		'description' => esc_html__( 'If you enable the sidebar, a maximum of 2 columns is recommended', 'rovenstart' ),
		'section'     => 'rovenstart_archive_settings',
		'default'     => 2,
		'choices'     => array(
			'min'  => 1,
			'max'  => 3,
			'step' => 1,
		),
	)
);
// Image Aspect Ratio option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'select',
		'settings'        => 'rovenstart_archive_aspect',
		'label'           => esc_html__( 'Image Aspect Ratio', 'rovenstart' ),
		'section'         => 'rovenstart_archive_settings',
		'default'         => 'landscape',
		'choices'         => array(
			'hero'      => esc_html__( 'Hero', 'rovenstart' ),
			'landscape' => esc_html__( 'Landscape', 'rovenstart' ),
			'portrait'  => esc_html__( 'Portrait', 'rovenstart' ),
			'square'    => esc_html__( 'Square', 'rovenstart' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_archive_grid',
				'operator' => '===',
				'value'    => 'grid',
			),
		),
	)
);
// Show author in post meta option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_archive_author',
		'label'    => esc_html__( 'Show author in post meta', 'rovenstart' ),
		'section'  => 'rovenstart_archive_settings',
		'default'  => '1',
	)
);
// Show category in post meta option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_archive_category',
		'label'    => esc_html__( 'Show category in post meta', 'rovenstart' ),
		'section'  => 'rovenstart_archive_settings',
		'default'  => '1',
	)
);
// Show date in post meta option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_archive_date',
		'label'    => esc_html__( 'Show date in post meta', 'rovenstart' ),
		'section'  => 'rovenstart_archive_settings',
		'default'  => '1',
	)
);
// Show number of comments in post meta option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_archive_comments',
		'label'    => esc_html__( 'Show number of comments in post meta', 'rovenstart' ),
		'section'  => 'rovenstart_archive_settings',
		'default'  => '1',
	)
);
// Show post excerpt option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_archive_excerpt',
		'label'    => esc_html__( 'Show post excerpt', 'rovenstart' ),
		'section'  => 'rovenstart_archive_settings',
		'default'  => '1',
	)
);
