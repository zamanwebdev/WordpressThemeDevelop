<?php
/**
 * The template for displaying Theme Customizer Settings
 *
 * @package Rovenstart
 */

// General Theme Settings section.
new \Kirki\Section(
	'rovenstart_theme_settings',
	array(
		'title'    => ROVENSTART_NAME . ': ' . esc_html__( 'General Theme Settings', 'rovenstart' ),
		'priority' => 151,
	)
);
// Sticky Offset option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'        => 'slider',
		'settings'    => 'rovenstart_sticky_offset',
		'label'       => esc_html__( 'Sticky offset (px)', 'rovenstart' ),
		'description' => esc_html__( 'The sticky offset value is only needed so that the sticky header does not cover the sticky sidebar and the floating share', 'rovenstart' ),
		'section'     => 'rovenstart_theme_settings',
		'default'     => 80,
		'choices'     => array(
			'min'  => 0,
			'max'  => 200,
			'step' => 1,
		),
	)
);
// Excerpt length option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'slider',
		'settings' => 'rovenstart_excerpt_length',
		'label'    => esc_html__( 'Excerpt length', 'rovenstart' ),
		'section'  => 'rovenstart_theme_settings',
		'default'  => 25,
		'choices'  => array(
			'min'  => 10,
			'max'  => 100,
			'step' => 5,
		),
	)
);
// Enable sticky sidebar option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_enable_sticky_sidebar',
		'label'    => esc_html__( 'Enable sticky sidebar', 'rovenstart' ),
		'section'  => 'rovenstart_theme_settings',
		'default'  => '1',
	)
);
// Section Title Styling option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'        => 'select',
		'settings'    => 'rovenstart_section_title_style',
		'label'       => esc_html__( 'Section Title Styling', 'rovenstart' ),
		'description' => esc_html__( 'Adds a visual efect to the section titles. (Affects the Featured, Related and Home Latest Posts sections title)', 'rovenstart' ),
		'section'     => 'rovenstart_theme_settings',
		'default'     => 'none',
		'choices'     => array(
			'none'     => esc_html__( 'None', 'rovenstart' ),
			'style-1'  => esc_html__( 'Style 1', 'rovenstart' ),
			'style-2'  => esc_html__( 'Style 2', 'rovenstart' ),
			'style-3'  => esc_html__( 'Style 3', 'rovenstart' ),
			'style-4'  => esc_html__( 'Style 4', 'rovenstart' ),
			'style-5'  => esc_html__( 'Style 5', 'rovenstart' ),
			'style-6'  => esc_html__( 'Style 6', 'rovenstart' ),
			'style-7'  => esc_html__( 'Style 7', 'rovenstart' ),
			'style-8'  => esc_html__( 'Style 8', 'rovenstart' ),
			'style-9'  => esc_html__( 'Style 9', 'rovenstart' ),
			'style-10' => esc_html__( 'Style 10', 'rovenstart' ),
		),
	)
);
// Widget Title Styling option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'        => 'select',
		'settings'    => 'rovenstart_widget_title_style',
		'label'       => esc_html__( 'Widget Title Styling', 'rovenstart' ),
		'description' => esc_html__( 'Adds a visual efect to the Widget section titles. Only applies to legacy widgets and our own custom widgets!', 'rovenstart' ),
		'section'     => 'rovenstart_theme_settings',
		'default'     => 'none',
		'choices'     => array(
			'none'     => esc_html__( 'None', 'rovenstart' ),
			'style-1'  => esc_html__( 'Style 1', 'rovenstart' ),
			'style-2'  => esc_html__( 'Style 2', 'rovenstart' ),
			'style-3'  => esc_html__( 'Style 3', 'rovenstart' ),
			'style-4'  => esc_html__( 'Style 4', 'rovenstart' ),
			'style-5'  => esc_html__( 'Style 5', 'rovenstart' ),
			'style-6'  => esc_html__( 'Style 6', 'rovenstart' ),
			'style-7'  => esc_html__( 'Style 7', 'rovenstart' ),
			'style-8'  => esc_html__( 'Style 8', 'rovenstart' ),
			'style-9'  => esc_html__( 'Style 9', 'rovenstart' ),
			'style-10' => esc_html__( 'Style 10', 'rovenstart' ),
		),
	)
);
// 404 Page default image option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'image',
		'settings'        => 'rovenstart_404_image',
		'label'           => esc_html__( '404 Page default image', 'rovenstart' ),
		'description'     => esc_html__( 'Customize the default 404 page with a background image.', 'rovenstart' ),
		'section'         => 'rovenstart_theme_settings',
		'default'         => '',
		'choices'         => array(
			'save_as' => 'id',
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_404_page',
				'operator' => '===',
				'value'    => '0',
			),
		),
	)
);
// General Theme Settings section.
new \Kirki\Section(
	'rovenstart_theme_optimizations',
	array(
		'title'    => ROVENSTART_NAME . ': ' . esc_html__( 'Advanced Settings', 'rovenstart' ),
		'priority' => 167,
	)
);
// Post Views Counting option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'        => 'checkbox_switch',
		'settings'    => 'rovenstart_view_count_toggle',
		'label'       => esc_html__( 'Post Views Counting', 'rovenstart' ),
		'description' => esc_html__( 'Enabling this option is recommended only if you plan to use the Popular Posts selection in Featured or Home Hero sections.', 'rovenstart' ),
		'section'     => 'rovenstart_theme_optimizations',
		'default'     => 'off',
		'choices'     => array(
			'on'  => esc_html__( 'Enabled', 'rovenstart' ),
			'off' => esc_html__( 'Disabled', 'rovenstart' ),
		),
	)
);
// Post views count type option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'radio_buttonset',
		'settings'        => 'rovenstart_view_count_type',
		'label'           => esc_html__( 'Post Views Count Type', 'rovenstart' ),
		'description'     => esc_html__( 'JavaScript is necessary if you are using cache plugins, else PHP is recommended.', 'rovenstart' ),
		'section'         => 'rovenstart_theme_optimizations',
		'default'         => 'php',
		'choices'         => array(
			'php' => esc_html__( 'PHP only', 'rovenstart' ),
			'js'  => esc_html__( 'JavaScript', 'rovenstart' ),
		),
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_view_count_toggle',
				'operator' => '===',
				'value'    => true,
			),
		),
	)
);
// Theme Lazy Loading switch option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'        => 'checkbox_switch',
		'settings'    => 'rovenstart_lazy_loading',
		'label'       => esc_html__( 'Lazy Load (via theme script)', 'rovenstart' ),
		'description' => esc_html__( 'It is recommended to disable this feature if your site already has lazy load added via other means, such as plugins.', 'rovenstart' ),
		'section'     => 'rovenstart_theme_optimizations',
		'default'     => 'on',
		'choices'     => array(
			'on'  => esc_html__( 'Enabled', 'rovenstart' ),
			'off' => esc_html__( 'Disabled', 'rovenstart' ),
		),
	)
);
