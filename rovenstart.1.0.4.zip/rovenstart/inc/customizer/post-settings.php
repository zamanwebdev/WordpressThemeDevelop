<?php
/**
 * The template for displaying Posts Customizer Settings
 *
 * @package Rovenstart
 */

// Single Post Settings section.
new \Kirki\Section(
	'rovenstart_post_settings',
	array(
		'title'    => ROVENSTART_NAME . ': ' . esc_html__( 'Single Post Settings', 'rovenstart' ),
		'priority' => 163,
	)
);
// Display author bio option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_post_show_author_bio',
		'label'    => esc_html__( 'Display author bio', 'rovenstart' ),
		'section'  => 'rovenstart_post_settings',
		'default'  => '1',
	)
);
// Display related posts option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_post_show_related_posts',
		'label'    => esc_html__( 'Display related posts', 'rovenstart' ),
		'section'  => 'rovenstart_post_settings',
		'default'  => '1',
	)
);
// Display post share buttons option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_post_show_posts_share',
		'label'    => esc_html__( 'Display post share buttons', 'rovenstart' ),
		'section'  => 'rovenstart_post_settings',
		'default'  => '1',
	)
);
// Display scroll progress bar option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_post_show_scroll_progress_bar',
		'label'    => esc_html__( 'Display scroll progress bar', 'rovenstart' ),
		'section'  => 'rovenstart_post_settings',
		'default'  => '1',
	)
);
// Scroll progress bar color option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'color',
		'settings'        => 'rovenstart_post_scroll_progress_bar_color',
		'label'           => esc_html__( 'Scroll progress bar color', 'rovenstart' ),
		'section'         => 'rovenstart_post_settings',
		'default'         => '#D50747',
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_post_show_scroll_progress_bar',
				'operator' => '===',
				'value'    => true,
			),
		),
	)
);
// Dark Mode: scroll progress bar color option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'            => 'color',
		'settings'        => 'rovenstart_darkmode_post_scroll_progress_bar_color',
		'label'           => esc_html__( 'Dark Mode: Scroll progress bar color', 'rovenstart' ),
		'section'         => 'rovenstart_post_settings',
		'default'         => '#2E2D4D',
		'active_callback' => array(
			array(
				'setting'  => 'rovenstart_post_show_scroll_progress_bar',
				'operator' => '===',
				'value'    => true,
			),
		),
	)
);
// Image Aspect Ratio option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'select',
		'settings' => 'rovenstart_post_settings_aspect',
		'label'    => esc_html__( 'Image Aspect Ratio', 'rovenstart' ),
		'section'  => 'rovenstart_post_settings',
		'default'  => 'hero',
		'choices'  => array(
			'hero'      => esc_html__( 'Hero', 'rovenstart' ),
			'landscape' => esc_html__( 'Landscape', 'rovenstart' ),
			'portrait'  => esc_html__( 'Portrait', 'rovenstart' ),
			'square'    => esc_html__( 'Square', 'rovenstart' ),
		),
	)
);
// Single Post Related Posts section.
new \Kirki\Section(
	'rovenstart_post_related_posts',
	array(
		'title'    => ROVENSTART_NAME . ': ' . esc_html__( 'Single Post Related Posts', 'rovenstart' ),
		'priority' => 164,
	)
);
// Section Title option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'        => 'text',
		'settings'    => 'rovenstart_post_related_title',
		'label'       => esc_html__( 'Section Title', 'rovenstart' ),
		'description' => esc_html__( 'Leave empty if you do not want the section to have a title', 'rovenstart' ),
		'section'     => 'rovenstart_post_related_posts',
		'default'     => esc_html__( 'You might also like', 'rovenstart' ),
	)
);
// Image Aspect Ratio option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'select',
		'settings' => 'rovenstart_post_related_aspect',
		'label'    => esc_html__( 'Image Aspect Ratio', 'rovenstart' ),
		'section'  => 'rovenstart_post_related_posts',
		'default'  => 'hero',
		'choices'  => array(
			'hero'      => esc_html__( 'Hero', 'rovenstart' ),
			'landscape' => esc_html__( 'Landscape', 'rovenstart' ),
			'portrait'  => esc_html__( 'Portrait', 'rovenstart' ),
			'square'    => esc_html__( 'Square', 'rovenstart' ),
		),
	)
);
// Show post excerpt option.
Kirki::add_field(
	'rovenstart_theme_mod',
	array(
		'type'     => 'toggle',
		'settings' => 'rovenstart_post_related_excerpt',
		'label'    => esc_html__( 'Show post excerpt', 'rovenstart' ),
		'section'  => 'rovenstart_post_related_posts',
		'default'  => '1',
	)
);
