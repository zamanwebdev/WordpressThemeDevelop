<?php
/**
 * The template for handling the CSS resulted from Kirki Customizer Options
 *
 * @package Rovenstart
 */

if ( ! function_exists( 'rovenstart_customizer_styles' ) ) {
	/**
	 *  This function generates the CSS based on Customizer Options and writes them in the customizer css file.
	 *
	 * @param string $handle - name of the stylesheet used for appending the inline styles.
	 */
	function rovenstart_customizer_styles( $handle ) {

		$customizer_css1 = ':root {';
		$customizer_css2 = '.rs-dark-mode {';
		$customizer_css3 = '@media (min-width: 768px) { :root {';

		if ( true === get_theme_mod( 'rovenstart_show_cta', true ) ) {
			// Prepare the css variables for CTA Customzier.

			$cta_bg_color = esc_attr( get_theme_mod( 'rovenstart_bg_color_cta', '#2E2D4D' ) );
			if ( '#2E2D4D' !== $cta_bg_color ) {
				$customizer_css1 .= "--background-color-cta: {$cta_bg_color};";
			}

			$cta_border_color = esc_attr( get_theme_mod( 'rovenstart_border_color_cta', '#2E2D4D' ) );
			if ( '#2E2D4D' !== $cta_border_color ) {
				$customizer_css1 .= "--border-color-cta: {$cta_border_color};";
			}

			$cta_text_color = esc_attr( get_theme_mod( 'rovenstart_text_color_cta', '#ffffff' ) );
			if ( '#ffffff' !== $cta_text_color ) {
				$customizer_css1 .= "--color-cta: {$cta_text_color};";
			}

			$cta_dmbg_color = esc_attr( get_theme_mod( 'rovenstart_darkmode_bg_color_cta', '#6c5b7b' ) );
			if ( '#6c5b7b' !== $cta_dmbg_color ) {
				$customizer_css2 .= "--background-color-cta: {$cta_dmbg_color};";
			}

			$cta_dmborder_color = esc_attr( get_theme_mod( 'rovenstart_darkmode_border_color_cta', '#6c5b7b' ) );
			if ( '#6c5b7b' !== $cta_dmborder_color ) {
				$customizer_css2 .= "--border-color-cta: {$cta_dmborder_color};";
			}

			$cta_dmtext_color = esc_attr( get_theme_mod( 'rovenstart_darkmode_text_color_cta', '#ffffff' ) );
			if ( '#ffffff' !== $cta_dmtext_color ) {
				$customizer_css2 .= "--color-cta: {$cta_dmtext_color};";
			}
		}

		// Prepare the theme color CSS variables.
		$accent_color1 = esc_attr( get_theme_mod( 'rovenstart_accent_color_1', '#2E2D4D' ) );
		if ( '#2E2D4D' !== $accent_color1 ) {
			$customizer_css1 .= "--color-accent-1: {$accent_color1};";
		}

		$accent_color2 = esc_attr( get_theme_mod( 'rovenstart_accent_color_2', '#D50747' ) );
		if ( '#D50747' !== $accent_color2 ) {
			$customizer_css1 .= "--color-accent-2: {$accent_color2};";
		}

		$link_color = esc_attr( get_theme_mod( 'rovenstart_link_color', '#2E2D4D' ) );
		if ( '#2E2D4D' !== $link_color ) {
			$customizer_css1 .= "--color-link: {$link_color};";
		}

		$link_color_hover = esc_attr( get_theme_mod( 'rovenstart_link_color_hover', '#D50747' ) );
		if ( '#D50747' !== $link_color_hover ) {
			$customizer_css1 .= "--color-link-hover: {$link_color_hover};";
		}

		$link_color_active = esc_attr( get_theme_mod( 'rovenstart_link_color_active', '#D50747' ) );
		if ( '#D50747' !== $link_color_active ) {
			$customizer_css1 .= "--color-link-active: {$link_color_active};";
		}

		$d_accent_color_1 = esc_attr( get_theme_mod( 'rovenstart_darkmode_accent_color_1', '#2E2D4D' ) );
		if ( '#2E2D4D' !== $d_accent_color_1 ) {
			$customizer_css2 .= "--color-accent-1: {$d_accent_color_1};";
		}

		$d_accent_color_2 = esc_attr( get_theme_mod( 'rovenstart_darkmode_accent_color_2', '#D50747' ) );
		if ( '#D50747' !== $d_accent_color_2 ) {
			$customizer_css2 .= "--color-accent-2: {$d_accent_color_2};";
		}

		$d_link_color = esc_attr( get_theme_mod( 'rovenstart_darkmode_link_color', '#ffffff' ) );
		if ( '#ffffff' !== $d_link_color ) {
			$customizer_css2 .= "--color-link: {$d_link_color};";
		}

		$d_link_color_hover = esc_attr( get_theme_mod( 'rovenstart_darkmode_link_color_hover', '#f8f8f8' ) );
		if ( '#f8f8f8' !== $d_link_color_hover ) {
			$customizer_css2 .= "--color-link-hover: {$d_link_color_hover};";
		}

		$d_link_color_active = esc_attr( get_theme_mod( 'rovenstart_darkmode_link_color_active', '#f8f8f8' ) );
		if ( '#f8f8f8' !== $d_link_color_active ) {
			$customizer_css2 .= "--color-link-active: {$d_link_color_active};";
		}

		// Prepare the theme Font CSS variables.
		$font_base_size = esc_attr( get_theme_mod( 'rovenstart_font_base_size', '17px' ) );
		if ( '17px' !== $font_base_size ) {
			$customizer_css1 .= "--font-base-size: {$font_base_size};";
		}

		$font_scale_mobile = esc_attr( get_theme_mod( 'rovenstart_font_scale_mobile', '1.067' ) );
		if ( '1.067' !== $font_scale_mobile ) {
			$customizer_css1 .= "--font-scale: {$font_scale_mobile};";
		}

		$font_scale = esc_attr( get_theme_mod( 'rovenstart_font_scale', '1.125' ) );
		if ( '1.125' !== $font_scale ) {
			$customizer_css3 .= "--font-scale: {$font_scale};";
		}

		// Prepare the theme Settings CSS variables.
		$sticky_offset = esc_attr( get_theme_mod( 'rovenstart_sticky_offset', '80' ) );
		if ( '80' !== $sticky_offset ) {
			$customizer_css1 .= "--sticky-offset: {$sticky_offset}px;";
		}
		// Prepare the header CSS variables.
		$text_logo_color = esc_attr( get_theme_mod( 'rovenstart_text_logo_color', '#D50747' ) );
		if ( '#D50747' !== $text_logo_color ) {
			$customizer_css1 .= "--color-logo: {$text_logo_color};";
		}

		$logo_height = esc_attr( get_theme_mod( 'rovenstart_logo_height_mobile', '60' ) );
		if ( '60' !== $logo_height ) {
			$customizer_css1 .= "--max-height-logo-mobile: {$logo_height}px;";
		}

		$logo_height_tablet = esc_attr( get_theme_mod( 'rovenstart_logo_height_tablet', '70' ) );
		if ( '70' !== $logo_height_tablet ) {
			$customizer_css1 .= "--max-height-logo-tablet: {$logo_height_tablet}px;";
		}

		$logo_height_desktop = esc_attr( get_theme_mod( 'rovenstart_logo_height_desktop', '90' ) );
		if ( '90' !== $logo_height_desktop ) {
			$customizer_css1 .= "--max-height-logo-desktop: {$logo_height_desktop}px;";
		}

		$logo_height_sticky = esc_attr( get_theme_mod( 'rovenstart_logo_sticky_height_mobile', '60' ) );
		if ( '60' !== $logo_height_sticky ) {
			$customizer_css1 .= "--max-height-logo-mobile-sticky: {$logo_height_sticky}px;";
		}

		$logo_height_tablet_sticky = esc_attr( get_theme_mod( 'rovenstart_logo_sticky_height_tablet', '60' ) );
		if ( '60' !== $logo_height_tablet_sticky ) {
			$customizer_css1 .= "--max-height-logo-tablet-sticky: {$logo_height_tablet_sticky}px;";
		}

		$logo_height_desktop_sticky = esc_attr( get_theme_mod( 'rovenstart_logo_sticky_height_desktop', '45' ) );
		if ( '45' !== $logo_height_desktop_sticky ) {
			$customizer_css1 .= "--max-height-logo-desktop-sticky: {$logo_height_desktop_sticky}px;";
		}

		$header_icons_color = esc_attr( get_theme_mod( 'rovenstart_header_icons_color', '#000000' ) );
		if ( '#000000' !== $header_icons_color ) {
			$customizer_css1 .= "--color-header-icons: {$header_icons_color};";
		}

		$header_icons_hover_color = esc_attr( get_theme_mod( 'rovenstart_header_icons_hover_color', '#D50747' ) );
		if ( '#D50747' !== $header_icons_hover_color ) {
			$customizer_css1 .= "--color-header-icons-hover: {$header_icons_hover_color};";
		}

		$header_menu_hover_color = esc_attr( get_theme_mod( 'rovenstart_header_menu_hover_color', '#D50747' ) );
		if ( '#D50747' !== $header_menu_hover_color ) {
			$customizer_css1 .= "--color-menu-hover: {$header_menu_hover_color};";
		}

		$dropdown_menu_color = esc_attr( get_theme_mod( 'rovenstart_dropdown_menu_color', '#000000' ) );
		if ( '#000000' !== $dropdown_menu_color ) {
			$customizer_css1 .= "--color-submenu: {$dropdown_menu_color};";
		}

		$dropdown_menu_hover_color = esc_attr( get_theme_mod( 'rovenstart_dropdown_menu_hover_color', '#D50747' ) );
		if ( '#D50747' !== $dropdown_menu_hover_color ) {
			$customizer_css1 .= "--color-submenu-hover: {$dropdown_menu_hover_color};";
		}

		$d_text_logo_color = esc_attr( get_theme_mod( 'rovenstart_darkmode_text_logo_color', '#D50747' ) );
		if ( '#D50747' !== $d_text_logo_color ) {
			$customizer_css2 .= "--color-logo: {$d_text_logo_color};";
		}

		$post_scroll_color = esc_attr( get_theme_mod( 'rovenstart_post_scroll_progress_bar_color', '#D50747' ) );
		if ( '#D50747' !== $post_scroll_color ) {
			$customizer_css1 .= "--background-color-scroll-progress: {$post_scroll_color};";
		}

		$d_post_scroll_color = esc_attr( get_theme_mod( 'rovenstart_darkmode_post_scroll_progress_bar_color', '#2E2D4D' ) );
		if ( '#2E2D4D' !== $d_post_scroll_color ) {
			$customizer_css2 .= "--background-color-scroll-progress: {$d_post_scroll_color};";
		}

		$customizer_css = '';

		if ( ':root {' !== $customizer_css1 ) {
			$customizer_css = $customizer_css1 . '}';
		}

		if ( '.rs-dark-mode {' !== $customizer_css2 ) {
			$customizer_css .= $customizer_css2 . '}';
		}

		if ( '@media (min-width: 768px) { :root {' !== $customizer_css3 ) {
			$customizer_css .= $customizer_css3 . '}}';
		}

		if ( false !== $handle ) {
			if ( '' !== $customizer_css ) {
				// Add the compiled css variables resulted from Customizer Kirki options.
				wp_add_inline_style( $handle, $customizer_css );
			}
		} else {
			$customizer_file = get_template_directory() . '/assets/admin/css/customizer.css';
			if ( '' !== $customizer_css || ( 0 !== filesize( $customizer_file ) && '' === $customizer_css ) ) {
				global $wp_filesystem;
				// Initialize the WP filesystem.
				if ( empty( $wp_filesystem ) ) {
					require_once ABSPATH . '/wp-admin/includes/file.php'; // phpcs:ignore WPThemeReview.CoreFunctionality.FileInclude.FileIncludeFound
					WP_Filesystem();
				}

				// Write the compiled css variables in the customizer file, used for editor styles.
				$wp_filesystem->put_contents( $customizer_file, $customizer_css );
			}
		}

	}
}
