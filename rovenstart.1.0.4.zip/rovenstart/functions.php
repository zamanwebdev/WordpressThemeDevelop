<?php
/**
 * Rovenstart functions and definitions
 *
 * @package Rovenstart
 */

if ( ! function_exists( 'rovenstart_fs' ) ) {
	/**
	 * Create a helper function for easy SDK access.
	 */
	function rovenstart_fs() {
		global  $rovenstart_fs;

		if ( ! isset( $rovenstart_fs ) ) {
			// Include Freemius SDK.
			require_once dirname( __FILE__ ) . '/freemius/start.php';
			$rovenstart_fs = fs_dynamic_init(
				array(
					'id'             => '11042',
					'slug'           => 'rovenstart',
					'premium_slug'   => 'rovenstart-pro',
					'type'           => 'theme',
					'public_key'     => 'pk_9409cccbee2d42ac1afb52defa934',
					'is_premium'     => false,
					'premium_suffix' => '(Pro)',
					'has_addons'     => false,
					'has_paid_plans' => true,
					'trial'          => array(
						'days'               => 14,
						'is_require_payment' => true,
					),
					'menu'           => array(
						'slug'    => 'rovenstart_welcome',
						'support' => false,
						'parent'  => array(
							'slug' => 'themes.php',
						),
					),
					'is_live'        => true,
				)
			);
		}

		return $rovenstart_fs;
	}

	// Init Freemius.
	rovenstart_fs();
	// Signal that SDK was initiated.
	do_action( 'rovenstart_fs_loaded' );
}

if ( ! function_exists( 'rovenstart_setup' ) ) {
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 */
	function rovenstart_setup() {

		// Makes the theme available for translation.
		load_theme_textdomain( 'rovenstart', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		// Let WordPress manage the document title.
		add_theme_support( 'title-tag' );

		// Enable support for Post Thumbnails on posts and pages.
		add_theme_support( 'post-thumbnails' );

		// Theme navigation menu declaration.
		register_nav_menus(
			array(
				'rovenstart-nav-menu1' => esc_html__( 'Theme Header Navigation Menu', 'rovenstart' ),
				'rovenstart-nav-menu2' => esc_html__( 'Theme Header Navigation Menu Split (left)', 'rovenstart' ),
				'rovenstart-nav-menu3' => esc_html__( 'Theme Header Navigation Menu Split (right)', 'rovenstart' ),
				'rovenstart-nav-menu4' => esc_html__( 'Theme Mobile Navigation Menu', 'rovenstart' ),
			)
		);

		// Crops the uploaded images to certain sizes used for different components and elements.
		if ( function_exists( 'add_image_size' ) ) {
			add_image_size( 'rovenstart-hero-max', 1353, 633, true );
			add_image_size( 'rovenstart-landscape-max', 1353, 992, true );
			add_image_size( 'rovenstart-portrait-max', 1353, 2231, true );
			add_image_size( 'rovenstart-square-max', 1353, 1353, true );
			add_image_size( 'rovenstart-masonry-max', 1353, 0, true );

			add_image_size( 'rovenstart-hero-mid', 1024, 436, true );
			add_image_size( 'rovenstart-landscape-mid', 1024, 683, true );
			add_image_size( 'rovenstart-portrait-mid', 1024, 1536, true );
			add_image_size( 'rovenstart-square-mid', 1024, 1024, true );
			add_image_size( 'rovenstart-masonry-mid', 1024, 0, true );

			add_image_size( 'rovenstart-hero-min', 810, 345, true );
			add_image_size( 'rovenstart-landscape-min', 810, 541, true );
			add_image_size( 'rovenstart-portrait-min', 810, 1216, true );
			add_image_size( 'rovenstart-square-min', 810, 810, true );
			add_image_size( 'rovenstart-masonry-min', 810, 0, true );

			add_image_size( 'rovenstart-size-small', 0, 120, true );
		}

		// Enable support for Post Formats.
		add_theme_support(
			'post-formats',
			array(
				'video',
				'gallery',
				'audio',
			)
		);

		// Use the default core markup for search form, comment form, and comments to output valid HTML5.
		$html5_args = array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		);
		add_theme_support( 'html5', $html5_args );

		// Add support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		// Add support for Full and wide alignment in Gutenberg.
		add_theme_support( 'align-wide' );

		// Add support for block styles.
		add_theme_support( 'wp-block-styles' );

		// Add support for responsive embeds.
		add_theme_support( 'responsive-embeds' );

		// Add support for core custom logo.
		add_theme_support( 'custom-logo' );

		// Add support for Yoast SEO plugin breadcrumbs.
		add_theme_support( 'yoast-seo-breadcrumbs' );

		// Add support for Rank Math SEO plugin breadcrumbs.
		add_theme_support( 'rank-math-breadcrumbs' );

		$infinitescroll_args = array(
			'container' => 'rs-posts-list',
			'footer'    => false,
			'render'    => 'rovenstart_posts_loop',
			'wrapper'   => false,
		);
		// Add support for Jetpack infinitescroll feature.
		add_theme_support( 'infinite-scroll', $infinitescroll_args );
	}
}

add_action( 'after_setup_theme', 'rovenstart_setup' );

/**
 * Load Gutenberg stylesheet.
 */
function rovenstart_add_gutenberg_assets() {
	// Load the theme styles within Gutenberg.
	wp_enqueue_style( 'rovenstart-gutenberg', get_theme_file_uri( '/assets/css/gutenberg-editor-style.min.css' ), false, _ROVENSTART_VERSION );

	if ( class_exists( 'Kirki' ) ) {
		// This function will write the Customizer resulted css variables inline after theme gutenberg style file.
		rovenstart_customizer_styles( 'rovenstart-gutenberg' );
	}
}

add_action( 'enqueue_block_editor_assets', 'rovenstart_add_gutenberg_assets' );

/**
 * Set the content width in pixels.
 * Priority 0 to make it available to lower priority callbacks.
 */
function rovenstart_content_width() {
	$GLOBALS['content_width'] = apply_filters( 'rovenstart_content_width', 1230 );
}
add_action( 'after_setup_theme', 'rovenstart_content_width', 0 );

/**
 * Register theme default fonts.
 * Used only when Kirki plugin is not active or installed, else fonts are loaded via kirki.
 */
function rovenstart_fonts_url() {
	$fonts_url = array();
	/**
	 * Translators: If there are characters in your language that are not
	 * supported by the fonts, translate this to 'off'. Do not translate
	 * into your own language.
	 */
	$first  = esc_html_x( 'on', 'DM Sans font: on or off', 'rovenstart' );
	$second = esc_html_x( 'on', 'Poppins font: on or off', 'rovenstart' );

	if ( 'off' !== $first ) {
		$fonts_url['first'] = 'https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;700&display=swap';
	}

	if ( 'off' !== $second ) {
		$fonts_url['second'] = 'https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;700&display=swap';
	}

	return $fonts_url;
}

if ( ! function_exists( 'rovenstart_scripts' ) ) {
	/**
	 * Enqueue frontend scripts and styles.
	 */
	function rovenstart_scripts() {

		if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
			wp_enqueue_script( 'comment-reply' );
		}

		wp_enqueue_style( 'rovenstart-style', get_template_directory_uri() . '/assets/css/rovenstart.min.css', array(), _ROVENSTART_VERSION );

		if ( false === rovenstart_font_check() ) {
			// Use the default fonts when Kirki plugin is not installed/active.
			$fonts_url = rovenstart_fonts_url();
			if ( isset( $fonts_url['first'] ) ) {
				wp_enqueue_style( 'rovenstart-first-font', esc_url_raw( $fonts_url['first'] ), array(), _ROVENSTART_VERSION );
			}
			if ( isset( $fonts_url['second'] ) ) {
				wp_enqueue_style( 'rovenstart-second-font', esc_url_raw( $fonts_url['second'] ), array(), _ROVENSTART_VERSION );
			}
		}

		if ( class_exists( 'Kirki' ) ) {
			// Customizer inline styles.
			if ( ! function_exists( 'rovenstart_demos_customizer_styles' ) ) {
				rovenstart_customizer_styles( 'rovenstart-style' );
			}
		}

		$count_toggle = get_theme_mod( 'rovenstart_view_count_toggle', false );
		$count_type   = get_theme_mod( 'rovenstart_view_count_type', 'php' );

		if ( true === $count_toggle && 'js' === $count_type && is_singular( 'post' ) ) {
			$script_args = array(
				'ajax_call'  => true,
				'post_id'    => get_the_ID(),
				'nonce'      => wp_create_nonce( 'rovenstart-viewcount-nonce' ),
				'requestURL' => esc_url_raw( admin_url( 'admin-ajax.php' ) ),
			);
		} else {
			$script_args['ajax_call'] = false;
		}

		if ( true === get_theme_mod( 'rovenstart_lazy_loading', true ) ) {
			$script_args['lazy_load'] = true;
		} else {
			$script_args['lazy_load'] = false;
		}

		wp_register_script( 'rovenstart-main', get_template_directory_uri() . '/assets/js/rovenstart.min.js', array( 'jquery' ), _ROVENSTART_VERSION, true );
		wp_localize_script( 'rovenstart-main', 'rovenstart_args', $script_args );
		wp_enqueue_script( 'rovenstart-main' );
	}
}

add_action( 'wp_enqueue_scripts', 'rovenstart_scripts' );

/**
 * This function prepares the url of the font selected from Kirki Customizer or default fonts.
 */
function rovenstart_custom_fonts_url() {
	$fonts_url = array();

	$body_font = get_theme_mod( 'rovenstart_body_typography', array() );

	if ( ! isset( $body_font['font-family'] ) ) {
		$body_font['font-family'] = 'DM Sans';
	}

	if ( ! isset( $body_font['variant'] ) ) {
		$body_font['variant'] = '400';
	}

	$headings_font = get_theme_mod( 'rovenstart_headings_typography', array() );

	if ( ! isset( $headings_font['font-family'] ) ) {
		$headings_font['font-family'] = 'Poppins';
	}

	if ( ! isset( $headings_font['variant'] ) ) {
		$headings_font['variant'] = '700';
	}

	$body_family        = preg_replace( '/\s+/', '+', $body_font['font-family'] );
	$fonts_url['first'] = 'https://fonts.googleapis.com/css2?family=' . $body_family . ':wght@' . $body_font['variant'] . '&display=swap';

	$headings_family     = preg_replace( '/\s+/', '+', $headings_font['font-family'] );
	$fonts_url['second'] = 'https://fonts.googleapis.com/css2?family=' . $headings_family . ':wght@' . $headings_font['variant'] . '&display=swap';

	$font_families = array();

	return $fonts_url;
}

/**
 * Enqueue theme custom editor and customizer styles for admin edit post/page.
 */
function rovenstart_admin_scripts() {

	wp_enqueue_style( 'rovenstart-welcome-style', get_template_directory_uri() . '/assets/admin/css/rovenstart-admin-welcome.min.css', array(), _ROVENSTART_VERSION );
	wp_enqueue_script( 'rovenstart-welcome-functions', get_template_directory_uri() . '/assets/admin/js/rovenstart-admin-welcome.min.js', array( 'jquery' ), _ROVENSTART_VERSION, true );

	global $pagenow;

	if ( 'post.php' === $pagenow || 'post-new.php' === $pagenow ) {
		if ( false === rovenstart_font_check() ) {
			// Use the default fonts when Kirki plugin is not installed/active.
			$fonts_url = rovenstart_fonts_url();
			if ( isset( $fonts_url['first'] ) ) {
				wp_enqueue_style( 'rovenstart-first-font', esc_url_raw( $fonts_url['first'] ), array(), _ROVENSTART_VERSION );
			} else {
				$fonts_url['first'] = null;
			}
			if ( isset( $fonts_url['second'] ) ) {
				wp_enqueue_style( 'rovenstart-second-font', esc_url_raw( $fonts_url['second'] ), array(), _ROVENSTART_VERSION );
			} else {
				$fonts_url['second'] = null;
			}
		}

		if ( ! class_exists( 'Kirki' ) ) {
			// Load the theme custom style file and fonts for the TinyMCE editor.
			add_editor_style( 'assets/css/editor-style.min.css', rovenstart_fonts_url(), esc_url_raw( $fonts_url['first'] ), esc_url_raw( $fonts_url['second'] ) );
		} else {
			// This function will write the Customizer resulted css variables in the customizer file.
			rovenstart_customizer_styles( false );

			$fonts_url = rovenstart_custom_fonts_url();
			if ( ! isset( $fonts_url['first'] ) ) {
				$fonts_url['first'] = null;
			}
			if ( isset( $fonts_url['second'] ) ) {
				$fonts_url['second'] = null;
			}

			// Load the theme fonts, custom style and customizer css variables files for the TinyMCE editor.
			add_editor_style( array( 'assets/css/editor-style.min.css', 'assets/admin/css/customizer.css', esc_url_raw( $fonts_url['first'] ), esc_url_raw( $fonts_url['second'] ) ) );
		}
	} elseif ( 'themes.php' === $pagenow ) {
		wp_enqueue_style( 'rovenstart-rs-admin', get_template_directory_uri() . '/assets/admin/css/rs-admin.css', array(), _ROVENSTART_VERSION );
	} elseif ( 'term.php' === $pagenow ) {
		wp_enqueue_style( 'rovenstart-rs-admin', get_template_directory_uri() . '/assets/admin/css/rs-admin.css', array(), _ROVENSTART_VERSION );
	} elseif ( 'widgets.php' === $pagenow ) {
		wp_enqueue_style( 'rovenstart-rs-admin', get_template_directory_uri() . '/assets/admin/css/rs-admin.css', array(), _ROVENSTART_VERSION );
	}
}

add_action( 'admin_enqueue_scripts', 'rovenstart_admin_scripts' );

if ( ! function_exists( 'rovenstart_excerpt_more' ) ) {
	/**
	 * Replace the default excerpt more […].
	 *
	 * @param string $more - the excerpt more text.
	 */
	function rovenstart_excerpt_more( $more ) {
		if ( is_admin() ) {
			return $more;
		} else {
			return '...';
		}
	}
}

add_filter( 'excerpt_more', 'rovenstart_excerpt_more' );

if ( ! function_exists( 'rovenstart_excerpt_length' ) ) {
	/**
	 * The custom excerpt length set via Kirki Customizer Options.
	 *
	 * @param string $length - excerpt characters count.
	 */
	function rovenstart_excerpt_length( $length ) {
		if ( is_admin() ) {
			return $length;
		} else {
			$custom_length = get_theme_mod( 'rovenstart_excerpt_length', 25 );

			return intval( $custom_length );
		}
	}
}

add_filter( 'excerpt_length', 'rovenstart_excerpt_length', 999 );

/**
 * Theme constants.
 */
require_once get_template_directory() . '/inc/theme-constants.php';

/**
 * Theme Functions which enhance the theme and add widget areas.
 */
require_once get_template_directory() . '/inc/template-functions.php';

// RovenStart Archives widget.
require_once get_template_directory() . '/inc/widgets/class-rs-widget-archives.php';

// RovenStart Categories widget.
require_once get_template_directory() . '/inc/widgets/class-rs-widget-categories.php';

// RovenStart Posts widget.
require_once get_template_directory() . '/inc/widgets/class-rs-widget-posts.php';

// RovenStart Social Networks List Alternative widget.
require_once get_template_directory() . '/inc/widgets/class-rs-widget-social-networks-list-alt.php';

// RovenStart Social Networks widget.
require_once get_template_directory() . '/inc/widgets/class-rs-widget-social-networks.php';

// RovenStart Tag Cloud widget.
require_once get_template_directory() . '/inc/widgets/class-rs-widget-tag-cloud.php';

/**
 * TGMPA source.
 */
require_once get_template_directory() . '/inc/class-tgm-plugin-activation.php';

add_action( 'tgmpa_register', 'rovenstart_register_required_plugins' );
/**
 * Register the plugins for this theme via TGMPA:
 */
function rovenstart_register_required_plugins() {
	$plugins = array(
		// Kirki plugin.
		array(
			'name'     => esc_html__( 'Kirki', 'rovenstart' ),
			'slug'     => 'kirki',
			'required' => false,
		),
		// One Click Demo Import plugin.
		array(
			'name'     => esc_html__( 'One Click Demo Import', 'rovenstart' ),
			'slug'     => 'one-click-demo-import',
			'required' => false,
		),
		// Mailchimp for WP plugin.
		array(
			'name'     => esc_html__( 'Mailchimp for WP', 'rovenstart' ),
			'slug'     => 'mailchimp-for-wp',
			'required' => false,
		),
		// Force Regenerate Thumbnails plugin.
		array(
			'name'     => esc_html__( 'Force Regenerate Thumbnails', 'rovenstart' ),
			'slug'     => 'force-regenerate-thumbnails',
			'required' => false,
		),
		// Instagram Feed plugin.
		array(
			'name'     => esc_html__( 'Instagram Feed', 'rovenstart' ),
			'slug'     => 'instagram-feed',
			'required' => false,
		),
		// instagram-feed plugin.
		array(
			'name'     => esc_html__( 'Contact Form 7', 'rovenstart' ),
			'slug'     => 'contact-form-7',
			'required' => false,
		),
	);

	// Configuration settings for TGMPA.
	$config = array(
		'id'           => 'rovenstart', // Unique ID for hashing notices for multiple instances of TGMPA.
		'default_path' => '', // Default absolute path to bundled plugins.
		'menu'         => 'tgmpa-install-plugins', // Menu slug.
		'has_notices'  => true, // Show admin notices or not.
		'dismissable'  => true, // If false, a user cannot dismiss the nag message.
		'dismiss_msg'  => '', // If 'dismissable' is false, this message will be output at top of nag.
		'is_automatic' => false, // Automatically activate plugins after installation or not.
		'message'      => '', // Message to output right before the plugins table.
	);

	tgmpa( $plugins, $config );
}

/**
 *  Kirki Customizer related files and functions.
 */
if ( class_exists( 'Kirki' ) && ! function_exists( 'rovenstart_kirki_settings' ) ) {

	/**
	 * Register Theme Mods
	 */
	function rovenstart_kirki_settings() {

		Kirki::add_config(
			'rovenstart_theme_mod',
			array(
				'capability'  => 'edit_theme_options',
				'option_type' => 'theme_mod',
			)
		);

		// The files used to generate theme Customizer Options via Kirki.
		require get_template_directory() . '/inc/customizer/archive-categories-settings.php';
		require get_template_directory() . '/inc/customizer/search-settings.php';
		require get_template_directory() . '/inc/customizer/authorpage-settings.php';
		require get_template_directory() . '/inc/customizer/cta-settings.php';
		require get_template_directory() . '/inc/customizer/footer-settings.php';
		require get_template_directory() . '/inc/customizer/general-settings.php';
		require get_template_directory() . '/inc/customizer/header-settings.php';
		require get_template_directory() . '/inc/customizer/homepage-settings.php';
		require get_template_directory() . '/inc/customizer/pages-settings.php';
		require get_template_directory() . '/inc/customizer/post-settings.php';
		require get_template_directory() . '/inc/customizer/theme-settings.php';
		require get_template_directory() . '/inc/customizer/social-media-settings.php';
		// The CSS resulted from Kirki Customizer Options is handled in this file.
		require_once get_template_directory() . '/inc/customizer-values.php';
	}

	add_action( 'after_setup_theme', 'rovenstart_kirki_settings', 20 );

	/**
	 * Disable Kirki statistics gathering.
	 */
	add_filter( 'kirki_telemetry', '__return_false' );
}

/**
 *  Simple check.
 */
function rovenstart_font_check() {
	$check = false;

	return $check;
}

/**
 *  Generates the posts categories array, used for Kirki Customizer Options.
 */
function rovenstart_categories_list() {
	global $pagenow;
	if ( 'customize.php' === $pagenow ) {
		$categories = get_categories( array( 'post_type' => 'post' ) );

		$categ_list = array();

		if ( ! empty( $categories ) ) {
			foreach ( $categories as $category ) {
				$categ_list[ $category->term_id ] = $category->name;
			}
		}

		return $categ_list;
	}
}

/**
 *  Generates the posts tags array, used for Kirki Customizer Options.
 */
function rovenstart_tags_list() {
	global $pagenow;
	if ( 'customize.php' === $pagenow ) {
		$p_tags = get_tags( 'post_tag' );

		$tag_list = array();

		if ( ! empty( $p_tags ) ) {
			foreach ( $p_tags as $p_tag ) {
				$tag_list[ $p_tag->term_id ] = $p_tag->name;
			}
		}

		return $tag_list;
	}
}

/**
 *  Generates the posts array, used for Kirki Customizer Options.
 */
function rovenstart_posts_list() {
	global $pagenow;
	if ( 'customize.php' === $pagenow ) {
		// Get all post IDs for the Kirki post selectors in the Customizer.
		$posts_ids = get_posts(
			array(
				'fields'      => 'ids',
				'numberposts' => -1, // phpcs:ignore WPThemeReview.CoreFunctionality.PostsPerPage.posts_per_page_numberposts
			)
		);

		$posts_list = array();

		if ( ! empty( $posts_ids ) ) {
			foreach ( $posts_ids as $post_id ) {
				$posts_list[ $post_id ] = get_the_title( $post_id );
			}
		}

		return $posts_list;
	}
}

/**
 *  Generates the pages array, used for Kirki Customizer Options.
 */
function rovenstart_pages_list() {
	global $pagenow;
	if ( 'customize.php' === $pagenow ) {
		$page_ids    = get_all_page_ids();
		$pages_array = array( 0 => esc_html__( 'Default 404 Template', 'rovenstart' ) );

		if ( ! empty( $page_ids ) ) {
			foreach ( $page_ids as $page_id ) {
				// do not include the Auto Draft pages.
				if ( 'Auto Draft' !== get_the_title( $page_id ) ) {
					$pages_array[ $page_id ] = esc_html( get_the_title( $page_id ) );
				}
			}
		}

		return $pages_array;
	}
}

/**
 * Generates the post arguments, used for Header Hero Posts, Featured Posts and Latest Posts sections.
 *
 * @param string $type - determines what set of posts to get.
 * @param int    $count - the number of posts to get.
 * @param string $param - determines if the function is used by home header or featured posts.
 * @param string $mode - determines if fields=>ids or ignore_sticky_posts=>true should be added.
 * @param int    $tag - the id of the post tag.
 * @param int    $categ - the id of the post category.
 */
function rovenstart_posts_args( $type, $count, $param, $mode = 'ids', $tag = null, $categ = null ) {

	if ( 'popular-posts' === $type ) {
		$args = array(
			'posts_per_page' => $count,
			'meta_key'       => 'post_views',
			'orderby'        => 'meta_value_num',
			'order'          => 'DESC',
			'numberposts'    => $count,
		);
	} elseif ( 'category-posts' === $type ) {
		if ( 'widget' === $param ) {
			$category = $categ;
		} else {
			$category = get_theme_mod( $param . '_post_categ' );
		}

		$args = array(
			'posts_per_page' => $count,
			'cat'            => $category,
			'numberposts'    => $count,
		);
	} elseif ( 'tag-posts' === $type ) {
		if ( 'widget' === $param ) {
			$tag = $tag;
		} else {
			$tag = get_theme_mod( $param . '_post_tag' );
		}

		$args = array(
			'posts_per_page' => $count,
			'tag_id'         => $tag,
			'numberposts'    => $count,
		);
	} elseif ( 'specific-posts' === $type ) {
		$specific = get_theme_mod( $param . '_post_specific', false );

		if ( false === $specific || empty( $specific ) ) {
			$count = 0;
		} else {
			$count = count( $specific );
		}

		$args = array(
			'posts_per_page' => $count,
			'post__in'       => $specific,
			'numberposts'    => $count,
		);
	} else {
		$args = array(
			'posts_per_page' => $count,
			'numberposts'    => $count,
		);
	}

	if ( 'ids' === $mode ) {
		$args['fields'] = 'ids';
	} elseif ( false === $mode ) {
		$args['ignore_sticky_posts'] = true;
	}

	return $args;
}

/**
 * Generates the list of post ids that should be excluded by the section type which called the function, based on order.
 *
 * @param string $check - determines which type of section called the exclude function.
 */
function rovenstart_exclusion_list( $check ) {
	$sections = get_theme_mod( 'rovenstart_home_layout', array( 'hero', 'featured', 'main' ) );
	$exclude  = array();
	$id_list  = array();

	// Traverse all sections until the one that called the function is met.
	foreach ( $sections as $section ) {
		if ( $check === $section ) {
			break;
		}

		if ( 'hero' === $section ) {
			$type  = get_theme_mod( 'rovenstart_home_header_hero_content', 'recent-posts' );
			$count = get_theme_mod( 'rovenstart_home_header_hero_posts_nr', 3 );
			$args1 = rovenstart_posts_args( $type, $count, 'rovenstart_home_header_hero' );

			// Check if the Header Hero has exclude posts options enabled.
			if ( 'specific-posts' !== get_theme_mod( 'rovenstart_home_header_hero_content', 'recent-posts' ) && true === get_theme_mod( 'rovenstart_home_header_hero_exclude', true ) ) {
				$args1['post__not_in'] = $exclude;
			}

			$id_list = get_posts( $args1 );
			$exclude = array_merge( $exclude, $id_list );
			$exclude = array_keys( array_flip( $exclude ) );
		} elseif ( 'hero1' === $section ) {
			$type  = get_theme_mod( 'rovenstart_home_header_hero1_content', 'recent-posts' );
			$count = get_theme_mod( 'rovenstart_home_header_hero1_posts_nr', 3 );
			$args1 = rovenstart_posts_args( $type, $count, 'rovenstart_home_header_hero1' );

			// Check if the Header Hero has exclude posts options enabled.
			if ( 'specific-posts' !== get_theme_mod( 'rovenstart_home_header_hero1_content', 'recent-posts' ) && true === get_theme_mod( 'rovenstart_home_header_hero1_exclude', true ) ) {
				$args1['post__not_in'] = $exclude;
			}

			$id_list = get_posts( $args1 );
			$exclude = array_merge( $exclude, $id_list );
			$exclude = array_keys( array_flip( $exclude ) );
		} elseif ( 'hero2' === $section ) {
			$type  = get_theme_mod( 'rovenstart_home_header_hero2_content', 'recent-posts' );
			$count = get_theme_mod( 'rovenstart_home_header_hero2_posts_nr', 3 );
			$args1 = rovenstart_posts_args( $type, $count, 'rovenstart_home_header_hero2' );

			// Check if the Header Hero has exclude posts options enabled.
			if ( 'specific-posts' !== get_theme_mod( 'rovenstart_home_header_hero2_content', 'recent-posts' ) && true === get_theme_mod( 'rovenstart_home_header_hero2_exclude', true ) ) {
				$args1['post__not_in'] = $exclude;
			}

			$id_list = get_posts( $args1 );
			$exclude = array_merge( $exclude, $id_list );
			$exclude = array_keys( array_flip( $exclude ) );
		} elseif ( 'main' === $section ) {
			if ( is_front_page() && is_home() ) {
				$count = get_theme_mod( 'rovenstart_home_recent_posts_nr', 3 );
				$args1 = rovenstart_posts_args( 'recent-posts', $count, 'rovenstart_home_recent_posts' );

				// Check if the Featured Posts has exclude posts options enabled.
				if ( true === get_theme_mod( 'rovenstart_home_recent_posts_exclude', true ) ) {
					$args1['post__not_in'] = $exclude;
				}

				$id_list = get_posts( $args1 );
				$exclude = array_merge( $exclude, $id_list );
				$exclude = array_keys( array_flip( $exclude ) );
			}
		} elseif ( 'featured' === $section ) {
			$type  = get_theme_mod( 'rovenstart_home_featured_content', 'recent-posts' );
			$count = get_theme_mod( 'rovenstart_home_featured_nr', 3 );
			$args1 = rovenstart_posts_args( $type, $count, 'rovenstart_home_featured' );

			// Check if the Featured Posts has exclude posts options enabled.
			if ( 'specific-posts' !== get_theme_mod( 'rovenstart_home_featured_content', 'recent-posts' ) && true === get_theme_mod( 'rovenstart_home_featured_posts_exclude', true ) ) {
				$args1['post__not_in'] = $exclude;
			}

			$id_list = get_posts( $args1 );
			$exclude = array_merge( $exclude, $id_list );
			$exclude = array_keys( array_flip( $exclude ) );
		}
	}

	return $exclude;
}

if ( ! function_exists( 'rovenstart_exclude_posts' ) ) {
	/**
	 * Function used for skipping posts in the home and archive loops based on the sections with posts placed above theme,
	 * also sets the number of posts for some main loops based on certain Customizer options.
	 *
	 * @param object $query - the query provided via pre_get_posts action.
	 */
	function rovenstart_exclude_posts( $query ) {

		if ( is_home() && is_front_page() && $query->is_main_query() ) {
			// Home Page and posts main query scenario.

			$sections = get_theme_mod( 'rovenstart_home_layout', array( 'hero', 'featured', 'main' ) );

			if ( in_array( 'main', $sections, true ) ) {
				if ( true === get_theme_mod( 'rovenstart_home_recent_posts_exclude', true ) && 'main' !== $sections[0] ) {
					// Fetch the list of post ids that should be excluded from the loop of this section.
					$exclude = rovenstart_exclusion_list( 'main' );

					if ( ! empty( $exclude ) ) {
						// Exclude posts from the main query based on the final list of ids.
						$query->set( 'post__not_in', $exclude );
					}
				}

				// Set the query posts per page based on the Customizer option.
				$posts_nr = get_theme_mod( 'rovenstart_home_recent_posts_nr', 6 );
				$query->set( 'posts_per_page', intval( $posts_nr ) );
			}
		} elseif ( is_search() && $query->is_main_query() ) {
			// Set the query posts per page based on the Customizer option.
			$posts_nr = get_theme_mod( 'rovenstart_search_posts_nr', 6 );
			$query->set( 'posts_per_page', intval( $posts_nr ) );
		} elseif ( is_author() && $query->is_main_query() ) {
			// Set the query posts per page based on the Customizer option.
			$posts_nr = get_theme_mod( 'rovenstart_author_posts_nr', 6 );
			$query->set( 'posts_per_page', intval( $posts_nr ) );
		} elseif ( ( is_category() || is_tag() || is_date() ) && $query->is_main_query() ) {
			// Archive pages and posts main query scenario.

			// Set the query posts per page based on the Customizer option.
			$posts_nr = get_theme_mod( 'rovenstart_archive_posts_nr', 6 );
			$query->set( 'posts_per_page', intval( $posts_nr ) );
		}
	}
}

if ( ! is_admin() ) {
	add_action( 'pre_get_posts', 'rovenstart_exclude_posts' );
}

/**
 * RovenThemes info section.
 */
function rovenstart_roventhemes_info() {
	?>
	<div id="rs-roventhemes-backlink" class="rs-section">

		<div class="rs-section-content">

			<p class="rs-text-align-center">
				<?php
				printf(
					wp_kses(
						/* translators: 1: link RovenThemes site. */
						__( 'RovenStart made by <a href="%1$s" target="_blank">RovenThemes</a>', 'rovenstart' ),
						array(
							'a' => array(
								'href' => array(),
							),
						)
					),
					'https://roventhemes.com/'
				);
				?>
			</p>

		</div><!-- end .rs-section-content -->	

	</div><!-- end #rs-roventhemes-backlink -->
	<?php
}

/**
 * Add theme Welcome submenu.
 */
function rovenstart_welcome_panel() {
	$title    = esc_html__( 'Welcome Page Free - Admin RovenStart WordPress Theme', 'rovenstart' );
	$function = 'rovenstart_welcome_page_free';
	add_theme_page( $title, esc_html__( 'Rovenstart', 'rovenstart' ), 'manage_options', 'rovenstart_welcome', $function, 32 );
}
add_action( 'admin_menu', 'rovenstart_welcome_panel' );

/**
 * Theme Welcome page for the submenu, free variant.
 */
function rovenstart_welcome_page_free() {
	?>
	<div id="rs-wrap">

		<div class="rs-welcome-page">

			<div class="rs-welcome-box rs-quick-links">

				<div class="row">
					<div class="col-sm-12">

						<img src="<?php echo esc_url( get_template_directory_uri() . '/assets/admin/images/logo.png' ); ?>" alt="">

						<h3><?php esc_html_e( 'Welcome to Roven Start', 'rovenstart' ); ?></h3>

						<p><?php esc_html_e( 'You are using the free version of the RovenStart WordPress theme. If you like it please consider buying the PRO version of the theme and take advantage of numerous extra features such as: ', 'rovenstart' ); ?></p>

						<ul>
							<li><?php esc_html_e( 'Full Color Scheme Editing', 'rovenstart' ); ?></li>
							<li><?php esc_html_e( 'Full Typography Editing', 'rovenstart' ); ?></li>
							<li><?php esc_html_e( 'Multiple Header and Footer Layouts', 'rovenstart' ); ?></li>
							<li><?php esc_html_e( 'Multiple Single Post Layouts', 'rovenstart' ); ?></li>
							<li><?php esc_html_e( 'Extra Social Share Options', 'rovenstart' ); ?></li>
							<li><?php esc_html_e( 'Advertisements Locations', 'rovenstart' ); ?></li>
							<li><?php esc_html_e( 'Premium Support', 'rovenstart' ); ?></li>
							<li><?php esc_html_e( 'Help Center', 'rovenstart' ); ?></li>
							<li><?php esc_html_e( 'Priority Email Support', 'rovenstart' ); ?></li> 
						</ul>

						<p><a href="https://roventhemes.com/theme/roven-start-wordpress-theme/"><?php esc_html_e( 'Find out more about Roven Start Pro', 'rovenstart' ); ?></a></p>

					</div>
				</div><!-- end .row -->	

			</div><!-- end .rs-welcome-box -->

			<div class="row">
				<div class="col-sm-8">

					<div class="rs-welcome-box rs-quick-links">

						<div class="row">
							<div class="col-sm-4">

								<svg fill="#56be40" xmlns="https://www.w3.org/2000/svg" viewBox="0 0 64 64" width="70px" height="70px&quot;">
									<path d="M 32 6 C 17.641 6 6 17.641 6 32 C 6 46.359 17.641 58 32 58 C 46.359 58 58 46.359 58 32 C 58 17.641 46.359 6 32 6 z M 32 9 C 44.703 9 55 19.297 55 32 C 55 44.703 44.703 55 32 55 C 19.297 55 9 44.703 9 32 C 9 19.297 19.297 9 32 9 z M 32 12 C 25.195 12 19.180406 15.422859 15.566406 20.630859 C 15.856406 20.630859 16.134766 20.626953 16.384766 20.626953 C 18.505766 20.626953 21.794922 20.375 21.794922 20.375 C 22.885922 20.312 23.008969 21.938266 21.917969 22.072266 C 21.917969 22.072266 20.804031 22.260266 19.582031 22.322266 L 26.958984 44.695312 L 31.384766 31.121094 L 28.25 22.322266 C 27.159 22.259266 26.097656 22.072266 26.097656 22.072266 C 25.006656 22.009266 25.129703 20.312 26.220703 20.375 C 26.220703 20.375 29.578359 20.626953 31.568359 20.626953 C 33.689359 20.626953 36.978516 20.375 36.978516 20.375 C 38.069516 20.312 38.192562 21.938266 37.101562 22.072266 C 37.101562 22.072266 35.979625 22.260266 34.765625 22.322266 L 42.082031 44.568359 L 44.111328 37.65625 C 45.133328 34.96925 45.648438 32.706641 45.648438 30.931641 C 45.648438 28.370641 44.764281 26.650391 43.988281 25.275391 C 42.966281 23.570391 42.021484 22.078047 42.021484 20.373047 C 42.021484 18.624047 43.205359 17.026297 44.943359 16.779297 C 41.451359 13.805297 36.935 12 32 12 z M 49.857422 23.044922 C 49.879422 23.419922 49.888672 23.805031 49.888672 24.207031 C 49.888672 26.304031 49.504562 28.670047 48.351562 31.623047 L 42.517578 48.978516 C 48.198578 45.446516 52 39.167 52 32 C 52 28.778 51.216422 25.742922 49.857422 23.044922 z M 13.660156 24.042969 C 12.597156 26.483969 12 29.172 12 32 C 12 39.729 16.414656 46.434672 22.847656 49.763672 L 13.660156 24.042969 z M 32.369141 33.822266 L 26.5 51.212891 C 28.25 51.714891 30.091 52 32 52 C 34.264 52 36.431891 51.604203 38.462891 50.908203 L 32.369141 33.822266 z"></path>
								</svg>
								<a href="https://roventhemes.com/wordpress-themes/"><strong><?php esc_html_e( 'WordPress Themes', 'rovenstart' ); ?></strong></a>

							</div>
							<div class="col-sm-4">

								<svg fill="#56be40" version="1.1" xmlns="https://www.w3.org/2000/svg" width="70px" height="70px" viewBox="0 0 24 24">
									<path d="M12 8c-2.2 0-4 1.8-4 4s1.8 4 4 4 4-1.8 4-4c0-2.2-1.8-4-4-4zM12 14c-1.1 0-2-0.9-2-2s0.9-2 2-2 2 0.9 2 2c0 1.1-0.9 2-2 2zM21.9 14.4l-1.8-1.1c0.1-0.4 0.1-0.9 0.1-1.3 0-0.5 0-0.9-0.1-1.3l1.8-1.1c0.4-0.2 0.6-0.7 0.4-1.2-0.5-1.3-1.2-2.5-2.1-3.6-0.3-0.4-0.8-0.5-1.3-0.2l-1.8 1.1c-0.7-0.6-1.5-1-2.3-1.3v-2.2c0-0.5-0.3-0.9-0.8-1-1.3-0.3-2.8-0.3-4.2 0-0.5 0.1-0.8 0.5-0.8 1v2.1c-0.7 0.3-1.5 0.8-2.2 1.4l-1.9-1.1c-0.4-0.2-0.9-0.2-1.2 0.2-0.9 1.1-1.6 2.3-2.1 3.6-0.2 0.5 0 1 0.4 1.2l1.8 1.1c-0.1 0.4-0.1 0.9-0.1 1.3 0 0.5 0 0.9 0.1 1.3l-1.8 1.1c-0.4 0.2-0.6 0.7-0.4 1.2 0.5 1.3 1.2 2.5 2.1 3.6 0.3 0.4 0.8 0.5 1.3 0.2l1.8-1.1c0.7 0.6 1.5 1 2.3 1.3v2.1c0 0.5 0.3 0.9 0.8 1 0.7 0.1 1.4 0.2 2.1 0.2s1.4-0.1 2.1-0.2c0.5-0.1 0.8-0.5 0.8-1v-2.1c0.8-0.3 1.6-0.8 2.3-1.3l1.8 1.1c0.4 0.2 0.9 0.2 1.3-0.2 0.9-1.1 1.6-2.3 2.1-3.6 0.2-0.4 0-0.9-0.5-1.2zM19.3 17.2l-1.7-1c-0.4-0.2-0.9-0.2-1.2 0.2-0.8 0.8-1.7 1.3-2.8 1.6-0.4 0.1-0.7 0.5-0.7 1v2c-0.6 0.1-1.2 0.1-1.8 0v-2c0-0.5-0.3-0.8-0.7-1-1-0.3-2-0.8-2.8-1.6-0.3-0.3-0.8-0.4-1.2-0.2l-1.7 1c-0.3-0.5-0.6-1-0.9-1.5l1.7-1c0.4-0.2 0.6-0.7 0.5-1.1-0.1-0.5-0.2-1.1-0.2-1.6s0.1-1.1 0.2-1.6c0.1-0.4-0.1-0.9-0.5-1.1l-1.7-1c0.2-0.6 0.5-1.1 0.9-1.5l1.7 1c0.4 0.2 0.9 0.1 1.2-0.2 0.8-0.8 1.7-1.3 2.8-1.6 0.4-0.1 0.7-0.5 0.7-1v-2c0.6 0 1.2 0 1.8 0v2c0 0.5 0.3 0.8 0.7 1 1 0.3 2 0.8 2.8 1.6 0.3 0.3 0.8 0.4 1.2 0.2l1.7-1c0.3 0.5 0.6 1 0.9 1.5l-1.7 1c-0.4 0.2-0.6 0.7-0.5 1.1 0.1 0.5 0.2 1.1 0.2 1.6s-0.1 1.1-0.2 1.6c-0.1 0.4 0.1 0.9 0.5 1.1l1.7 1c-0.2 0.6-0.5 1.1-0.9 1.5z"></path>
								</svg>
								<a href="#"><?php esc_html_e( 'WordPress Plugins', 'rovenstart' ); ?></a>

							</div>
							<div class="col-sm-4">

								<svg fill="#56be40" xmlns="https://www.w3.org/2000/svg" viewBox="0 0 50 50" width="70px" height="70px">
									<path d="M 45.273438 2.324219 C 45.085938 2.117188 44.816406 2 44.535156 2 L 5.464844 2 C 5.183594 2 4.914063 2.117188 4.726563 2.324219 C 4.535156 2.53125 4.441406 2.808594 4.46875 3.089844 L 7.988281 42.515625 C 8.023438 42.929688 8.3125 43.273438 8.710938 43.390625 L 24.722656 47.960938 C 24.808594 47.988281 24.902344 48 24.996094 48 C 25.089844 48 25.179688 47.988281 25.269531 47.960938 L 41.292969 43.390625 C 41.691406 43.273438 41.976563 42.929688 42.015625 42.515625 L 45.53125 3.089844 C 45.558594 2.808594 45.464844 2.53125 45.273438 2.324219 Z M 36.847656 15.917969 L 18.035156 15.917969 L 18.484375 21.007813 L 36.394531 21.007813 L 35.050781 36.050781 L 24.992188 39.089844 L 24.894531 39.058594 L 14.953125 36.046875 L 14.410156 29.917969 L 19.28125 29.917969 L 19.492188 32.296875 L 25.050781 33.460938 L 30.507813 32.296875 L 31.089844 25.859375 L 14.046875 25.859375 L 12.722656 11.054688 L 37.28125 11.054688 Z"></path>
								</svg>
								<a href="https://roventhemes.com/html-templates/"><strong><?php esc_html_e( 'HTML5 Templates', 'rovenstart' ); ?></strong></a>

							</div>
						</div><!-- end .row-->	

						<div class="row">
							<div class="col-sm-4">

								<svg fill="#56be40" version="1.1" xmlns="https://www.w3.org/2000/svg" width="70px" height="70px" viewBox="0 0 24 24">
									<path d="M12 21c-0.3 0-0.5-0.1-0.7-0.3l-7.3-7.2c-2.4-2.4-2.4-6.3 0-8.7 2.2-2.2 5.6-2.4 8-0.6 2.4-1.8 5.8-1.6 8 0.6 2.4 2.4 2.4 6.3 0 8.7l-7.2 7.2c-0.3 0.2-0.5 0.3-0.8 0.3zM8.4 5c-1.1 0-2.1 0.4-2.9 1.2-1.6 1.6-1.6 4.2 0 5.8l6.5 6.5 6.5-6.5c1.6-1.6 1.6-4.2 0-5.8s-4.2-1.6-5.8 0c-0.4 0.4-1 0.4-1.4 0-0.8-0.8-1.9-1.2-2.9-1.2z"></path>
								</svg>
								<a href="https://roventhemes.com/icons/"><strong><?php esc_html_e( 'Icon Fonts', 'rovenstart' ); ?></strong></a>

							</div>
							<div class="col-sm-4">

								<svg xmlns="https://www.w3.org/2000/svg" viewBox="0 0 50 50" width="70px" height="70px">
									<path fill="#56be40" d="M10.323,11L0,37h2l3.228-8h10.385l2.667,8h8.164l-9.75-26H10.323z M6.035,27l4.88-12.094L14.946,27 H6.035z M19.721,35l-7.333-22h2.92l8.25,22H19.721z"></path>
									<path fill="#56be40" d="M45.697,20.296c-1.987-1.63-4.98-2.058-8.894-1.276c-0.087,0.017-0.158,0.061-0.234,0.098 c-1.767,0.436-3.701,1.908-5.464,5.435l1.789,0.895c1.812-3.624,3.881-5.058,6.147-4.254c1.444,0.509,2.488,1.799,2.828,3.364 C41.262,25.259,39.317,27,35,27c-2.757,0-5,2.243-5,5c0,2.707,2.167,4.907,4.856,4.985c0.007,0.001,0.013,0.006,0.02,0.007 c0.054,0.007,0.484,0.058,1.131,0.058c1.468,0,4.052-0.262,5.899-1.893c0.033-0.029,0.061-0.063,0.094-0.093V37h1h1h4V25 C48,24.885,47.974,22.162,45.697,20.296z M32,32c0-1.654,1.346-3,3-3v6C33.346,35,32,33.654,32,32z M40.589,33.652 C39.561,34.563,38.138,34.893,37,35v-6.128c2.312-0.291,3.926-1.052,5-1.8V30C42,31.616,41.538,32.811,40.589,33.652z M46,35h-2 v-9.352c0-1.886-0.745-3.617-1.971-4.851c0.949,0.182,1.75,0.518,2.38,1.028C45.957,23.078,45.999,24.929,46,25V35z"></path>
								</svg>
								<a href="https://roventhemes.com/fonts/"><strong><?php esc_html_e( 'Roven Font', 'rovenstart' ); ?></strong></a>

							</div>
							<div class="col-sm-4">

								<svg version="1.1" xmlns="https://www.w3.org/2000/svg" xmlns:xlink="https://www.w3.org/1999/xlink" x="0px" y="0px" width="70px" height="70px" viewBox="0 0 512 512" style="enable-background:new 0 0 512 512;" xml:space="preserve">
									<g>
										<g>
											<g>
												<path fill="#56be40" d="M460.8,32.337H210.189v-2.695C210.189,13.298,196.891,0,180.547,0H94.316C77.972,0,64.674,13.298,64.674,29.642v2.695
													H51.2c-28.231,0-51.2,22.969-51.2,51.2v21.558v301.811c0,28.231,22.969,51.2,51.2,51.2h185.937v24.253
													c0,16.344,13.298,29.642,29.642,29.642h118.568c16.344,0,29.642-13.298,29.642-29.642v-24.253H460.8
													c28.231,0,51.2-22.969,51.2-51.2V105.095V83.537C512,55.306,489.031,32.337,460.8,32.337z M80.842,29.642
													c0-7.43,6.044-13.474,13.474-13.474h86.232c7.43,0,13.474,6.044,13.474,13.474v67.368H80.842V29.642z M16.168,83.537
													c0-19.317,15.715-35.032,35.032-35.032h13.474v48.505H16.168V83.537z M237.137,267.538v120.504h-153.6
													c-7.43,0-13.474-6.044-13.474-13.474V191.326c0-7.43,6.044-13.474,13.474-13.474h207.495v37.891l-40.695,27.13
													C242.071,248.384,237.137,257.604,237.137,267.538z M398.821,482.358c0,7.43-6.044,13.474-13.474,13.474H266.779
													c-7.43,0-13.474-6.044-13.474-13.474v-214.82c0-4.515,2.243-8.706,6-11.211l31.727-21.15v4.655c0,7.396,2.31,14.259,6.238,19.921
													c-0.55,2.254-0.848,4.606-0.848,7.027c0,16.344,13.298,29.642,29.642,29.642s29.642-13.298,29.642-29.642
													s-13.298-29.642-29.642-29.642c-6.984,0-13.408,2.434-18.479,6.49c-0.251-1.226-0.384-2.495-0.384-3.795v-15.433l11.39-7.594
													c2.27-1.513,4.871-2.27,7.473-2.27c2.601,0,5.204,0.757,7.474,2.27l59.284,39.522c3.756,2.505,6,6.696,6,11.211V482.358z
													M326.063,258.695c-3.151,0-6.117-0.786-8.731-2.158c2.353-2.01,5.4-3.232,8.731-3.232c7.43,0,13.474,6.044,13.474,13.474
													s-6.044,13.474-13.474,13.474c-5.297,0-9.877-3.08-12.077-7.536c3.767,1.387,7.834,2.146,12.077,2.146
													c4.466,0,8.084-3.618,8.084-8.084C334.147,262.313,330.529,258.695,326.063,258.695z M401.79,242.873l-59.283-39.522
													c-9.99-6.661-22.898-6.66-32.885,0l-2.421,1.615v-27.113h121.263c7.43,0,13.474,6.044,13.474,13.474v183.242
													c0,7.43-6.044,13.474-13.474,13.474h-13.474V267.538C414.989,257.604,410.055,248.384,401.79,242.873z M309.046,161.684
													c3.034-6.362,9.511-10.779,17.017-10.779s13.981,4.417,17.017,10.779H309.046z M495.832,406.905
													c0,19.317-15.715,35.032-35.032,35.032h-45.811v-37.726h13.474c16.344,0,29.642-13.298,29.642-29.642V191.326
													c0-16.344-13.298-29.642-29.642-29.642h-68.32c-3.661-15.43-17.546-26.947-34.08-26.947s-30.419,11.517-34.08,26.947H83.537
													c-16.344,0-29.642,13.298-29.642,29.642v183.242c0,16.344,13.298,29.642,29.642,29.642h153.6v37.726H51.2
													c-19.317,0-35.032-15.715-35.032-35.032V113.179h479.663V406.905z M495.832,97.011H210.189V48.505H460.8
													c19.317,0,35.032,15.715,35.032,35.032V97.011z"></path>
												<path fill="#ffffff" d="M417.684,64.135c-4.466,0-8.084,3.618-8.084,8.084v1.078c0,4.466,3.619,8.084,8.084,8.084s8.084-3.618,8.084-8.084
													v-1.078C425.768,67.753,422.15,64.135,417.684,64.135z"></path>
												<path fill="#ffffff" d="M385.347,64.135c-4.466,0-8.084,3.618-8.084,8.084v1.078c0,4.466,3.618,8.084,8.084,8.084
													c4.466,0,8.084-3.618,8.084-8.084v-1.078C393.432,67.753,389.813,64.135,385.347,64.135z"></path>
												<path fill="#ffffff" d="M450.021,64.135c-4.466,0-8.084,3.618-8.084,8.084v1.078c0,4.466,3.618,8.084,8.084,8.084
													c4.466,0,8.084-3.618,8.084-8.084v-1.078C458.105,67.753,454.487,64.135,450.021,64.135z"></path>
											</g>
										</g>
									</g>
								</svg>
								<a href="https://roventhemes.com/ad-templates/"><strong><?php esc_html_e( 'Ad Templates', 'rovenstart' ); ?></strong></a>

							</div>
						</div><!-- end .row-->		

					</div><!-- end .rs-welcome-box -->

				</div>
				<div class="col-sm-4">

					<div class="rs-welcome-box">

						<div class="row">
							<div class="col-sm-12">

								<svg fill="#56be40" version="1.1" xmlns="https://www.w3.org/2000/svg" width="70px" height="70px" viewBox="0 0 24 24">
									<path d="M12 1c-6.1 0-11 4.9-11 11s4.9 11 11 11 11-4.9 11-11-4.9-11-11-11zM12 21c-5 0-9-4-9-9s4-9 9-9 9 4 9 9-4 9-9 9zM16 14c0 1.7-1.3 3-3 3v1c0 0.6-0.4 1-1 1s-1-0.4-1-1v-1c-1.2 0-2.2-0.7-2.7-1.8-0.2-0.5 0-1.1 0.5-1.3s1.1 0 1.3 0.5c0.2 0.4 0.5 0.6 0.9 0.6h2c0.6 0 1-0.4 1-1s-0.4-1-1-1h-2c-1.7 0-3-1.3-3-3s1.3-3 3-3v-1c0-0.6 0.4-1 1-1s1 0.4 1 1v1c0.8 0 1.6 0.3 2.1 0.9 0.4 0.4 0.4 1 0 1.4s-1 0.4-1.4 0c-0.2-0.2-0.4-0.3-0.7-0.3h-2c-0.6 0-1 0.4-1 1s0.4 1 1 1h2c1.7 0 3 1.3 3 3z"></path>
								</svg>

								<h3><?php esc_html_e( 'Want to start earning money? Join the Roven Themes affiliate program and earn up to *80% commission!', 'rovenstart' ); ?></h3>

								<a href="https://roventhemes.com/affiliate-program/" class="rs-btn" target="_blank"><?php esc_html_e( 'Details', 'rovenstart' ); ?></a>

							</div>
						</div><!-- end .row -->

					</div><!-- end .rs-welcome-box -->

				</div>
			</div><!-- end .row -->

		</div><!-- end .rs-welcome-page -->



	</div><!-- end #rs-wrap -->
	<?php
}
