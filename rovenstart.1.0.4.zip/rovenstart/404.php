<?php
/**
 * The template for displaying 404 pages (not found)
 *
 * @package Rovenstart
 */

get_header();

// 404 page card image.
$image_id  = get_theme_mod( 'rovenstart_404_image', false );
$image_src = false;
if ( false !== $image_id ) {
	$image_data = wp_get_attachment_image_src( $image_id, 'rovenstart-hero-max' );
	if ( false !== $image_data ) {
		$image_src = $image_data[0];
	}
}
?>
<div id="rs-content" class="rs-section">
	<div class="rs-section-content">
		<div id="rs-main-content">

			<div class="rs-card-7 rs-card-has-thumbnail rs-card-aspect-ratio-hero">

				<?php if ( false !== $image_src ) { ?>
					<div class="rs-card-background">

						<span><img src="<?php echo esc_url( $image_src ); ?>" alt=""></span>

					</div>
				<?php } ?>

				<div class="rs-card-content">

					<h3 class="rs-card-title"><?php esc_html_e( 'Error 404 - Page not found', 'rovenstart' ); ?></h3><!-- end .rs-card-title -->

					<p><?php esc_html_e( "The page you are looking for doesn't exist or has been moved.", 'rovenstart' ); ?></p>

				</div><!-- end .rs-card-content -->

			</div><!-- end .rs-card-7 -->

		</div>
	</div>
</div>
<?php
get_footer();
