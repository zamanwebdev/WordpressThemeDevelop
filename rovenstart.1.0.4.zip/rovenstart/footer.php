<?php
/**
 * The template for displaying the footer
 *
 * @package Rovenstart
 */

if ( true === get_theme_mod( 'rovenstart_show_footer', true ) ) {
	// Start Middle Footer Area.

	$footer_cols = get_theme_mod( 'rovenstart_footer_cols', 'cols-1' );

	$section_class = '';

	if ( true === get_theme_mod( 'rovenstart_footer_fullwidth', true ) ) {
		$section_class = ' rs-full-width';
	}
	?>
	<div id="rs-footer" class="rs-section">

		<div class="rs-section-content<?php echo esc_attr( $section_class ); ?>">

			<div class="rs-grid <?php echo esc_attr( $footer_cols ); ?>">

				<div class="rs-grid-item">
					<?php
					if ( is_active_sidebar( 'rovenstart-footer-1' ) ) {
						dynamic_sidebar( 'rovenstart-footer-1' );
					}
					?>
				</div>

				<?php
				if ( 'cols-1' !== $footer_cols ) {
					// Middle Footer second column.
					?>
					<div class="rs-grid-item">
						<?php
						if ( is_active_sidebar( 'rovenstart-footer-2' ) ) {
							dynamic_sidebar( 'rovenstart-footer-2' );
						}
						?>
					</div>
					<?php
				}

				if ( 'cols-3' === $footer_cols ) {
					// Middle Footer third column.
					?>
					<div class="rs-grid-item">
						<?php
						if ( is_active_sidebar( 'rovenstart-footer-3' ) ) {
							dynamic_sidebar( 'rovenstart-footer-3' );
						}
						?>
					</div>
				<?php } ?>
			</div><!-- end .rs-grid -->

		</div><!-- end .rs-section-content -->

	</div><!-- end #rs-footer -->
	<?php
}

if ( true === get_theme_mod( 'rovenstart_show_footer_bottom', true ) ) {
	// Start Bottom Footer Area.

	$footer_bottom_cols = get_theme_mod( 'rovenstart_footer_bottom_cols', 'cols-2' );

	$section_class = '';
	if ( true === get_theme_mod( 'rovenstart_footer_bottom_border', false ) ) {
		$section_class = ' rs-border-top';
	}
	if ( true === get_theme_mod( 'rovenstart_footer_bottom_fullwidth' ) ) {
		$section_class .= ' rs-full-width';
	}
	?>
	<div id="rs-footer-bottom" class="rs-section">

		<div class="rs-section-content<?php echo esc_attr( $section_class ); ?>">

			<div class="rs-grid <?php echo esc_attr( $footer_bottom_cols ); ?>">

				<div class="rs-grid-item">
					<?php
					if ( is_active_sidebar( 'rovenstart-footer-bottom1' ) ) {
						dynamic_sidebar( 'rovenstart-footer-bottom1' );
					}
					?>
				</div>

				<?php
				if ( 'cols-1' !== $footer_bottom_cols ) {
					// Bottom Footer second column.
					?>
					<div class="rs-grid-item">
						<?php
						if ( is_active_sidebar( 'rovenstart-footer-bottom2' ) ) {
							dynamic_sidebar( 'rovenstart-footer-bottom2' );
						}
						?>
					</div>
					<?php
				}

				if ( 'cols-3' === $footer_bottom_cols ) {
					// Bottom Footer third column.
					?>
					<div class="rs-grid-item">
						<?php
						if ( is_active_sidebar( 'rovenstart-footer-bottom3' ) ) {
							dynamic_sidebar( 'rovenstart-footer-bottom3' );
						}
						?>
					</div>
				<?php } ?>
			</div><!-- end .rs-grid -->

		</div><!-- end .rs-section-content -->

	</div><!-- end #rs-footer-bottom -->
	<?php
}

rovenstart_roventhemes_info();
?>
</div><!-- end #rs-wrap -->

<div id="rs-site-overlay"></div>

<?php
// Mobile Menu template.
get_template_part( 'template-parts/menus/mobile', 'menu' );

wp_footer();
?>
</body>
</html>
