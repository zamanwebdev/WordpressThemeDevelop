<?php
/**
 * The template for displaying posts
 *
 * @package Rovenstart
 */

get_header();

if ( have_posts() ) {
	$archive_title       = get_theme_mod( 'rovenstart_archive_show_title', true );
	$archive_description = get_theme_mod( 'rovenstart_archive_show_description', true );

	if ( true === $archive_title || true === $archive_description ) {
		// Archive Title and Description section.
		?>
		<div id="rs-archive-category-header" class="rs-section">

			<div class="rs-section-title">

				<div class="rs-content-no-sidebar-width rs-color-mute">
					<?php
					if ( true === $archive_title ) {
						the_archive_title( '<h1>', '</h1>' );
					}

					if ( true === $archive_description ) {
						the_archive_description( '<p>', '</p>' );
					}
					?>
				</div>

			</div><!-- end .rs-section-title -->

		</div><!-- end #rs-archive-category-header -->
		<?php
	}

	// Archive/Category page Customizer arguments.
	$nr_cols   = intval( get_theme_mod( 'rovenstart_archive_grid_columns', 2 ) );
	$grid_type = 'grid';

	// Archive/Category posts Customizer arguments.
	$style_type      = 'style4';
	$category_enable = get_theme_mod( 'rovenstart_archive_category', true );
	$thumbnail_type  = get_theme_mod( 'rovenstart_archive_aspect', 'landscape' );
	$excerpt_enable  = get_theme_mod( 'rovenstart_archive_excerpt', true );

	$sidebar    = get_theme_mod( 'rovenstart_archive_show_sidebar', true );
	$grid_width = intval( get_theme_mod( 'rovenstart_max_width_content', 1230 ) );

	// Determine the most suitable image size for the selected image aspect based on the number of columns and grid width.
	if ( 1 === $nr_cols ) {
		if ( true === $sidebar && 1400 >= $grid_width ) {
			$thumbnail_size = '-mid';
		} else {
			$thumbnail_size = '-max';
		}
	} elseif ( 2 === $nr_cols ) {
		if ( true !== $sidebar && 1400 < $grid_width ) {
			$thumbnail_size = '-mid';
		} else {
			$thumbnail_size = '-min';
		}
	} else {
		$thumbnail_size = '-min';
	}

	if ( 'masonry' === $grid_type ) {
		$thumbnail_type = 'masonry';
	}

	// Prepare post template arguments.
	if ( 'style1' === $style_type || 'style2' === $style_type ) {
		$args = array(
			'category_enable' => $category_enable,
			'thumbnail_type'  => ' rs-card-aspect-ratio-' . $thumbnail_type,
			'thumbnail_size'  => $thumbnail_type,
			'thumbnail_limit' => $thumbnail_size,
			'excerpt_enable'  => $excerpt_enable,
		);
	} else {
		// Post style 3, 4, 5, 6 and 7 specific arguments.
		$icons_enable    = false;
		$author_enable   = get_theme_mod( 'rovenstart_archive_author', true );
		$date_enable     = get_theme_mod( 'rovenstart_archive_date', true );
		$comments_enable = get_theme_mod( 'rovenstart_archive_comments', true );

		$args = array(
			'category_enable' => $category_enable,
			'thumbnail_type'  => ' rs-card-aspect-ratio-' . $thumbnail_type,
			'thumbnail_size'  => $thumbnail_type,
			'thumbnail_limit' => $thumbnail_size,
			'icons_enable'    => $icons_enable,
			'author_enable'   => $author_enable,
			'date_enable'     => $date_enable,
			'comments_enable' => $comments_enable,
			'excerpt_enable'  => $excerpt_enable,
		);
	}
	?>
	<div id="rs-content" class="rs-section">

		<div class="rs-section-content">

			<div id="rs-main-content">

				<?php
				if ( 'masonry' === $grid_type ) {
					// Posts masonry layout.
					?>
					<div id="rs-posts-list" class="rs-masonry-grid cols-<?php echo $nr_cols; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">

						<?php while ( have_posts() ) { ?>
							<div class="rs-masonry-grid-item">
								<?php
								the_post();
								// Post template based on style.
								get_template_part( 'template-parts/post-styles/post', $style_type, $args );
								?>
							</div>
						<?php } ?>

					</div><!-- end .rs-masonry-grid -->
					<?php
				} else {
					// Posts grid layout.
					?>
					<div id="rs-posts-list" class="rs-grid cols-<?php echo $nr_cols; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>">

						<?php while ( have_posts() ) { ?>
							<div class="rs-grid-item">
								<?php
								the_post();
								// Post template based on style.
								get_template_part( 'template-parts/post-styles/post', $style_type, $args );
								?>
							</div>
						<?php } ?>

					</div><!-- end .rs-grid -->
					<?php
				}

				// Uses WordPress pagination with some arguments.
				rovenstart_pagination();
				?>

			</div><!-- end #rs-main-content -->

			<?php
			if ( ( is_category() || is_tag() || is_date() ) && true === $sidebar ) {
				get_sidebar( 'archive' );
			}
			?>

		</div><!-- end .rs-section-content -->

	</div><!-- end #rs-content -->
	<?php
} else {
	// There is no content, use content-none template.
	get_template_part( 'template-parts/content', 'none' );
}

get_footer();
