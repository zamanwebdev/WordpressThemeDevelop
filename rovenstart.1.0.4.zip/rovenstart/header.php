<?php
/**
 * The header for the theme
 *
 * @package Rovenstart
 */

?>

<!doctype html>
<html <?php language_attributes(); ?>>
	<head>
		<meta charset="<?php bloginfo( 'charset' ); ?>">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<?php wp_head(); ?>
	</head>

	<body <?php body_class(); ?>>

		<div id="rs-wrap">
			<a class="rs-skip-link screen-reader-text" href="#rs-main-content"><?php esc_html_e( 'Skip to content', 'rovenstart' ); ?></a>
			<?php
			wp_body_open();

			if ( true === get_theme_mod( 'rovenstart_show_cta', true ) && class_exists( 'Kirki' ) ) {
				// Theme CTA section.
				?>
				<div id="rs-cta" class="rs-section">

					<div class="rs-section-content">

						<p class="rs-text-align-center">
							<?php
							echo esc_html( get_theme_mod( 'rovenstart_cta_text', esc_html__( 'CTA Text here...', 'rovenstart' ) ) );
							?>
						</p>

					</div><!-- end .rs-section-content -->

				</div><!-- end #rs-cta -->
				<?php
			}

			// Determine the header menu template ( based on logo placement ).
			$header_layout = get_theme_mod( 'rovenstart_header_layout', 'logo-top-menu-below' );
			if ( 'logo-center-menu-split' === $header_layout ) {
				get_template_part( 'template-parts/menus/header', 'menu3' );
			} elseif ( 'logo-top-menu-right' === $header_layout ) {
				get_template_part( 'template-parts/menus/header', 'menu2' );
			} else {
				get_template_part( 'template-parts/menus/header', 'menu1' );
			}

			// Area typically used for adding the extra content under header.
			do_action( 'rovenstart_below_nav_menu' );

			// Rankmath and YoastSEO breadrcrumbs section.
			$breadcrumbs_rankmath = function_exists( 'rank_math_the_breadcrumbs' );
			$breadcrumbs_yoast    = function_exists( 'yoast_breadcrumb' );
			if ( ! is_home() && ! is_front_page() && ( $breadcrumbs_rankmath || $breadcrumbs_yoast ) ) {
				?>
				<div id="rs-breadcrumbs" class="rs-section">

					<div class="rs-section-content">
						<?php
						if ( $breadcrumbs_rankmath ) {
							rank_math_the_breadcrumbs();
						} else {
							?>
							<nav aria-label="breadcrumbs" class="yoast-breadcrumb">
								<?php yoast_breadcrumb(); ?>
							</nav>
						<?php } ?>
					</div><!-- end .rs-section-content -->

				</div><!-- end #rs-breadcrumbs -->
				<?php
			}
